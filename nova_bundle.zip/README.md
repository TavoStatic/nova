# Project NOVA

Minimal notes to run and operate Nova locally.

Quick start

1. Ensure a Python virtual environment exists at `C:\Nova\.venv` and required packages are installed:

```powershell
C:\Nova\.venv\Scripts\python.exe -m pip install -r C:\Nova\requirements.txt
```

2. Start the guard (recommended):

```powershell
C:\Nova\.venv\Scripts\python.exe C:\Nova\nova_guard.py
```

3. Stop Nova (deterministic):

```powershell
C:\Nova\.venv\Scripts\python.exe C:\Nova\stop_guard.py
```

Health check

```powershell
C:\Nova\.venv\Scripts\python.exe C:\Nova\health.py
```

Files of interest
- `nova_core.py` — main assistant loop (STT, LLM, TTS, tools)
- `nova_guard.py` — deterministic supervisor (heartbeat + statefile)
- `policy.json` — controls allowed root, tools, models, memory
- `runtime/` — runtime files (heartbeat, core_state.json, guard.stop, core.fail)

If you want me to package this into a single ZIP bundle for backup or deploy, tell me and I'll create it.
