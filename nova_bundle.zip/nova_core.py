# Nova Core (stable) - Voice + Typed chat, tools, local knowledge packs, safe web fetch, safe self-patching
# Target: Windows + Ollama + Faster-Whisper + Piper TTS
#
# Design goals:
# - Deterministic safety: never hallucinate tool output or machine actions.
# - Mixed input: press ENTER for voice, or type a message/command.
# - Piper TTS runs as a subprocess per utterance (reliable).
# - Optional knowledge packs (B-mode, lightweight lexical search).
# - Optional self-patching (zip overlay + snapshot + rollback + compile test).
# - Optional web fetch tool (allowlist + max bytes) that NEVER crashes core.

from __future__ import annotations

import argparse
import io
import json
import os
import queue
import re
import socket
import subprocess
import threading
import time
import zipfile
import hashlib
import mimetypes
from pathlib import Path
from typing import Optional, Tuple
from urllib.parse import urlparse
from capabilities import explain_missing, describe_capabilities, analyze_task
from task_engine import analyze_request
from env_inspector import inspect_environment, format_report
import requests
import psutil

# -------------------------
# Voice deps are optional
# -------------------------
VOICE_OK = True
VOICE_IMPORT_ERR = ""
try:
    import sounddevice as sd
    import scipy.io.wavfile as wav
    from faster_whisper import WhisperModel
except Exception as e:
    VOICE_OK = False
    VOICE_IMPORT_ERR = str(e)
    sd = None
    wav = None
    WhisperModel = None




# =========================
# Config / Policy
# =========================
from pathlib import Path
import sys

# Robust BASE_DIR detection
if getattr(sys, "frozen", False):
    # Running as compiled executable
    BASE_DIR = Path(sys.executable).resolve().parent
else:
    # Running as normal Python script
    BASE_DIR = Path(__file__).resolve().parent

RUNTIME_DIR = BASE_DIR / "runtime"
LOG_DIR = BASE_DIR / "logs"
POLICY_PATH = BASE_DIR / "policy.json"
PYTHON = str(BASE_DIR / ".venv" / "Scripts" / "python.exe")
OLLAMA_BASE = "http://127.0.0.1:11434"

SAMPLE_RATE = 16000
CHANNELS = 1

# UX tuning
RECORD_SECONDS = 3
OLLAMA_BOOT_RETRIES = 15
OLLAMA_REQ_TIMEOUT = 1800

# Knowledge packs (B-mode)
KNOWLEDGE_ROOT = BASE_DIR / "knowledge"
PACKS_DIR = KNOWLEDGE_ROOT / "packs"
ACTIVE_PACK_FILE = KNOWLEDGE_ROOT / "active_pack.txt"
KB_MAX_FILES = 3
KB_MAX_CHARS = 2000

# Web cache folder
WEB_CACHE_DIR = KNOWLEDGE_ROOT / "web"

# Self patching
UPDATES_DIR = BASE_DIR / "updates"
SNAPSHOTS_DIR = UPDATES_DIR / "snapshots"
PATCH_LOG = UPDATES_DIR / "patch.log"


def ok(msg): print(f"[OK]   {msg}", flush=True)
def warn(msg): print(f"[WARN] {msg}", flush=True)
def bad(msg): print(f"[FAIL] {msg}", flush=True)


def load_policy() -> dict:
    data = json.loads(POLICY_PATH.read_text(encoding="utf-8"))
    data["allowed_root"] = str(Path(data.get("allowed_root", str(BASE_DIR))).resolve())
    data.setdefault("tools_enabled", {})
    data.setdefault("models", {})
    data.setdefault("memory", {"enabled": False, "mode": "B", "top_k": 5, "min_score": 0.25, "exclude_sources": []})
    data.setdefault("web", {"enabled": False, "allow_domains": [], "max_bytes": 20_000_000})
    return data


def policy_models():
    p = load_policy()
    return p.get("models") or {}


def policy_memory():
    p = load_policy()
    return p.get("memory") or {}


def policy_tools_enabled():
    p = load_policy()
    return p.get("tools_enabled") or {}


def policy_web():
    p = load_policy()
    return (p.get("web") or {})


def web_enabled() -> bool:
    p = load_policy()
    return bool((p.get("tools_enabled") or {}).get("web")) and bool((p.get("web") or {}).get("enabled"))


def _host_allowed(host: str, allow_domains: list[str]) -> bool:
    host = (host or "").lower()
    for d in allow_domains:
        d = (d or "").lower().strip()
        if not d:
            continue
        if host == d or host.endswith("." + d):
            return True
    return False


def web_fetch(url: str, save_dir: Path) -> dict:
    """
    Fetch a URL (http/https only) if host is allowlisted.
    Saves to save_dir with deterministic filename.
    Never raises; always returns {"ok": bool, ...}.
    """
    if not web_enabled():
        return {"ok": False, "error": "Web tool disabled by policy."}

    cfg = policy_web()
    allow_domains = cfg.get("allow_domains") or []
    max_bytes = int(cfg.get("max_bytes") or 20_000_000)

    u = urlparse(url.strip())
    if u.scheme not in ("http", "https"):
        return {"ok": False, "error": "Only http/https URLs are allowed."}
    host = u.hostname or ""
    if not _host_allowed(host, allow_domains):
        return {"ok": False, "error": f"Domain not allowed: {host}"}

    save_dir.mkdir(parents=True, exist_ok=True)

    h = hashlib.sha256(url.encode("utf-8")).hexdigest()[:16]
    ts = time.strftime("%Y%m%d_%H%M%S")
    base = f"{ts}_{host}_{h}"

    try:
        r = requests.get(url, stream=True, timeout=60, headers={"User-Agent": "Nova/1.0"})
    except requests.exceptions.RequestException as e:
        return {"ok": False, "error": f"Request failed: {e}"}

    try:
        r.raise_for_status()
        ctype = (r.headers.get("Content-Type") or "").split(";")[0].strip().lower()

        if ctype == "application/pdf":
            ext = ".pdf"
        elif ctype in ("text/html", "application/xhtml+xml"):
            ext = ".html"
        elif ctype.startswith("text/"):
            ext = ".txt"
        else:
            ext = mimetypes.guess_extension(ctype) or ".bin"

        out_path = save_dir / (base + ext)

        total = 0
        with open(out_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=65536):
                if not chunk:
                    continue
                total += len(chunk)
                if total > max_bytes:
                    out_path.unlink(missing_ok=True)
                    return {"ok": False, "error": f"File too large (>{max_bytes} bytes)."}
                f.write(chunk)

        return {"ok": True, "url": url, "path": str(out_path), "content_type": ctype, "bytes": total}

    except requests.exceptions.RequestException as e:
        return {"ok": False, "error": f"HTTP error: {e}"}
    except Exception as e:
        return {"ok": False, "error": f"Unexpected error: {e}"}
    finally:
        try:
            r.close()
        except Exception:
            pass


def allowed_root() -> Path:
    p = load_policy()
    return Path(p["allowed_root"]).resolve()


def chat_model() -> str:
    m = policy_models()
    return m.get("chat", "llama3.1:8b")


def whisper_size() -> str:
    m = policy_models()
    return m.get("stt_size", "small")


# =========================
# Guard/Core liveness contract
# =========================
DEFAULT_HEARTBEAT = RUNTIME_DIR / "core.heartbeat"
DEFAULT_STATEFILE = RUNTIME_DIR / "core_state.json"


def atomic_write_json(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def touch(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(str(time.time()), encoding="utf-8")


def write_core_identity(statefile: Path):
    pid = os.getpid()
    ct = psutil.Process(pid).create_time()
    atomic_write_json(statefile, {
        "pid": int(pid),
        "create_time": float(ct),
        "ts": time.time(),
        "note": "canonical (written by core)"
    })


def start_heartbeat(heartbeat_file: Path, interval_sec: float = 1.0):
    stop_evt = threading.Event()

    def _loop():
        while not stop_evt.is_set():
            try:
                touch(heartbeat_file)
            except Exception:
                pass
            stop_evt.wait(interval_sec)

    t = threading.Thread(target=_loop, name="core-heartbeat", daemon=True)
    t.start()
    return stop_evt


# =========================
# Subprocess TTS (Piper oneshot)
# =========================
class SubprocessTTS:
    """Piper oneshot wrapper: python tts_piper.py "text"""

    def __init__(self, python_exe: str, oneshot_script: Path, timeout_sec: float = 25.0):
        self.python_exe = python_exe
        self.oneshot_script = oneshot_script
        self.timeout_sec = float(timeout_sec)
        self.q = queue.Queue()
        self.stop_evt = threading.Event()
        self.t = threading.Thread(target=self._run, name="tts-worker", daemon=True)

    def start(self):
        self.t.start()

    def stop(self):
        self.stop_evt.set()
        self.q.put(None)

    def say(self, text: str):
        if text:
            self.q.put(str(text))

    def _run(self):
        while not self.stop_evt.is_set():
            item = self.q.get()
            if item is None:
                break

            try:
                creationflags = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW
                p = subprocess.Popen(
                    [self.python_exe, str(self.oneshot_script), item],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE,
                    creationflags=creationflags,
                )
                try:
                    _, err = p.communicate(timeout=self.timeout_sec)
                except subprocess.TimeoutExpired:
                    p.kill()
                    warn("TTS timed out; killed piper subprocess.")
                    continue

                if p.returncode != 0:
                    msg = (err or b"").decode("utf-8", errors="ignore").strip()
                    warn(f"TTS failed rc={p.returncode}: {msg}")

            except Exception as e:
                warn(f"TTS error: {e}")


def speak_chunked(tts: SubprocessTTS, text: str, max_len: int = 220):
    text = (text or "").strip()
    if not text:
        return
    parts = re.split(r'(?<=[.!?])\s+', text)
    buf = ""
    for p in parts:
        if len(buf) + len(p) + 1 <= max_len:
            buf = (buf + " " + p).strip()
        else:
            if buf:
                tts.say(buf)
            buf = p.strip()
    if buf:
        tts.say(buf)


# =========================
# Memory hooks (optional)
# =========================
def mem_enabled() -> bool:
    return bool(policy_memory().get("enabled", False))


def mem_top_k() -> int:
    try:
        return int(policy_memory().get("top_k", 5))
    except Exception:
        return 5


def mem_min_score() -> float:
    try:
        return float(policy_memory().get("min_score", 0.25))
    except Exception:
        return 0.25


def mem_exclude_sources() -> list[str]:
    xs = policy_memory().get("exclude_sources") or []
    return [str(x) for x in xs if x]


def mem_add(kind: str, source: str, text: str):
    if not mem_enabled():
        return
    try:
        subprocess.run(
            [PYTHON, str(BASE_DIR / "memory.py"), "add",
             "--kind", kind, "--source", source, "--text", text],
            capture_output=True, text=True, timeout=1800
        )
    except Exception:
        pass


def mem_recall(query: str) -> str:
    if not mem_enabled():
        return ""
    try:
        cmd = [
            PYTHON, str(BASE_DIR / "memory.py"), "recall",
            "--query", query,
            "--topk", str(mem_top_k()),
            "--minscore", str(mem_min_score()),
        ]
        for s in mem_exclude_sources():
            cmd += ["--exclude-source", s]

        r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
        out = (r.stdout or "").strip()
        if not out or "No memories" in out:
            return ""

        bullets = []
        parts = re.split(r"\n--- score=.*?---\n", "\n" + out + "\n")
        for p in parts:
            p = (p or "").strip()
            if not p:
                continue
            one = re.sub(r"\s+", " ", p).strip()
            bullets.append(f"- {one[:260]}")

        return "\n".join(bullets)[:2000] if bullets else ""
    except Exception:
        return ""


# =========================
# Guard rails (files)
# =========================
def is_within_allowed(p: Path) -> bool:
    try:
        p.resolve().relative_to(allowed_root())
        return True
    except Exception:
        return False


def safe_path(user_path: str) -> Path:
    p = Path(user_path)
    if not p.is_absolute():
        p = (allowed_root() / p)
    p = p.resolve()
    if not is_within_allowed(p):
        raise PermissionError(f"Denied: outside allowed root: {allowed_root()}")
    return p


# =========================
# Ollama helpers
# =========================
def tcp_listening(host="127.0.0.1", port=11434, timeout=1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def ollama_api_up(timeout=2.0) -> bool:
    try:
        r = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=timeout)
        return r.status_code == 200
    except Exception:
        return False


def start_ollama_serve_detached() -> bool:
    try:
        DETACHED = 0x00000008
        NEW_GROUP = 0x00000200
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=DETACHED | NEW_GROUP,
        )
        return True
    except Exception:
        return False


def kill_ollama() -> None:
    subprocess.run(["taskkill", "/F", "/IM", "ollama.exe"], capture_output=True, text=True)


def ensure_ollama_boot():
    if not tcp_listening():
        warn("Ollama not listening on 11434. Starting ollama serve...")
        start_ollama_serve_detached()

    if tcp_listening() and not ollama_api_up():
        warn("Ollama port open but API not responding. Restarting...")
        kill_ollama()
        time.sleep(1.2)
        start_ollama_serve_detached()

    for _ in range(OLLAMA_BOOT_RETRIES):
        if ollama_api_up():
            ok("Ollama API up")
            return True
        time.sleep(1)

    bad("Ollama API still down.")
    return False


def ensure_ollama():
    if not tcp_listening():
        start_ollama_serve_detached()
    if tcp_listening() and not ollama_api_up():
        kill_ollama()
        time.sleep(1.0)
        start_ollama_serve_detached()
    for _ in range(10):
        if ollama_api_up():
            return
        time.sleep(0.5)


# =========================
# Knowledge packs (B-mode)
# =========================
def _tokenize(q: str):
    q = (q or "").lower()
    toks = re.findall(r"[a-z0-9]{3,}", q)
    if "peims" in q and "peims" not in toks:
        toks.append("peims")
    return list(dict.fromkeys(toks))[:25]


def kb_active_pack() -> Optional[str]:
    try:
        if ACTIVE_PACK_FILE.exists():
            name = ACTIVE_PACK_FILE.read_text(encoding="utf-8").strip()
            return name or None
    except Exception:
        pass
    return None


def kb_set_active(name: Optional[str]) -> str:
    KNOWLEDGE_ROOT.mkdir(parents=True, exist_ok=True)
    if not name:
        if ACTIVE_PACK_FILE.exists():
            ACTIVE_PACK_FILE.unlink(missing_ok=True)
        return "Knowledge pack disabled."
    (PACKS_DIR / name).mkdir(parents=True, exist_ok=True)
    ACTIVE_PACK_FILE.write_text(name, encoding="utf-8")
    return f"Active knowledge pack: {name}"


def kb_list_packs() -> str:
    PACKS_DIR.mkdir(parents=True, exist_ok=True)
    packs = [p.name for p in PACKS_DIR.iterdir() if p.is_dir()]
    packs.sort(key=str.lower)
    active = kb_active_pack()
    lines = []
    for p in packs:
        mark = "*" if active and p.lower() == active.lower() else " "
        lines.append(f"{mark} {p}")
    if not lines:
        return "No knowledge packs yet. (You can add one with: kb add <zip_path> <pack_name>)"
    return "Knowledge packs:\n" + "\n".join(lines)


def kb_add_zip(zip_path: str, pack_name: str) -> str:
    zpath = safe_path(zip_path) if not Path(zip_path).is_absolute() else Path(zip_path)
    if not zpath.exists() or not zpath.is_file():
        return f"Not a file: {zpath}"

    dest = PACKS_DIR / pack_name
    dest.mkdir(parents=True, exist_ok=True)

    exts = {".txt", ".md"}
    extracted = 0
    with zipfile.ZipFile(zpath, "r") as z:
        for member in z.infolist():
            if member.is_dir():
                continue
            name = Path(member.filename).name
            if Path(name).suffix.lower() not in exts:
                continue
            out = dest / name
            out.write_bytes(z.read(member))
            extracted += 1

    if extracted == 0:
        return "No .txt/.md files found in zip. (For now, keep packs as txt/md; we can add PDF parsing later.)"
    return f"Added {extracted} file(s) to knowledge pack: {pack_name}"


def kb_search(query: str, max_files: int = KB_MAX_FILES, max_chars: int = KB_MAX_CHARS) -> str:
    pack = kb_active_pack()
    if not pack:
        return ""
    root = PACKS_DIR / pack
    if not root.exists():
        return ""

    toks = _tokenize(query)
    if not toks:
        return ""

    candidates = []
    exts = {".txt", ".md"}

    for p in root.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in exts:
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        low = text.lower()
        score = 0
        for t in toks:
            score += low.count(t)

        if score > 0:
            candidates.append((score, p, text))

    if not candidates:
        return ""

    candidates.sort(key=lambda x: x[0], reverse=True)
    picked = candidates[:max_files]

    blocks = []
    used = 0
    for score, path, text in picked:
        low = text.lower()
        idx = None
        for t in toks:
            j = low.find(t)
            if j != -1:
                idx = j
                break
        if idx is None:
            idx = 0

        start = max(0, idx - 250)
        end = min(len(text), idx + 950)
        snippet = text[start:end].strip().replace("\r\n", "\n")

        chunk = f"[FILE] {path.name} (score={score})\n{snippet}\n"
        if used + len(chunk) > max_chars:
            break
        blocks.append(chunk)
        used += len(chunk)

    if not blocks:
        return ""
    return f"REFERENCE (knowledge pack: {pack}):\n\n" + "\n---\n".join(blocks)


# =========================
# Self patching (zip overlay + snapshot + rollback)
# =========================
def _log_patch(msg: str):
    UPDATES_DIR.mkdir(parents=True, exist_ok=True)
    SNAPSHOTS_DIR.mkdir(parents=True, exist_ok=True)
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} | {msg}\n"
    PATCH_LOG.write_text(PATCH_LOG.read_text(encoding="utf-8") + line if PATCH_LOG.exists() else line, encoding="utf-8")


def _snapshot_current() -> Path:
    SNAPSHOTS_DIR.mkdir(parents=True, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    snap = SNAPSHOTS_DIR / f"snapshot_{ts}.zip"
    skip_dirs = {".venv", "runtime", "logs", "models", "updates", "__pycache__", "knowledge"}
    with zipfile.ZipFile(snap, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in BASE_DIR.rglob("*"):
            if p.is_dir():
                continue
            rel = p.relative_to(BASE_DIR)
            if rel.parts and rel.parts[0] in skip_dirs:
                continue
            if "__pycache__" in rel.parts:
                continue
            z.write(p, arcname=str(rel))
    _log_patch(f"SNAPSHOT {snap.name}")
    return snap


def _overlay_zip(zip_path: Path) -> int:
    allowed_ext = {".py", ".json", ".md", ".txt", ".ps1", ".cmd"}
    blocked_prefix = {".venv/", "runtime/", "logs/", "models/"}

    count = 0
    with zipfile.ZipFile(zip_path, "r") as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            name = info.filename.replace("\\", "/").lstrip("/")
            if any(name.startswith(bp) for bp in blocked_prefix):
                continue
            ext = Path(name).suffix.lower()
            if ext not in allowed_ext:
                continue
            out = BASE_DIR / name
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(z.read(info))
            count += 1

    return count


def _py_compile_check() -> Tuple[bool, str]:
    try:
        r = subprocess.run(
            [PYTHON, "-m", "compileall", str(BASE_DIR)],
            capture_output=True, text=True, timeout=1800
        )
        out = (r.stdout or "") + ("\n" + r.stderr if r.stderr else "")
        ok_ = (r.returncode == 0)
        return ok_, out.strip()
    except Exception as e:
        return False, str(e)


def patch_apply(zip_path: str) -> str:
    z = safe_path(zip_path) if not Path(zip_path).is_absolute() else Path(zip_path)
    if not z.exists() or not z.is_file():
        return f"Not a file: {z}"

    snap = _snapshot_current()
    _log_patch(f"APPLY {z.name}")

    n = _overlay_zip(z)
    if n == 0:
        _log_patch("APPLY no files overlayed")
        return "Patch zip contained no eligible files to apply."

    ok_compile, out = _py_compile_check()
    if not ok_compile:
        _log_patch("COMPILE_FAIL -> rollback")
        patch_rollback(str(snap))
        return "Patch applied, but compile check failed. Rolled back.\n\nCompile output:\n" + out[-3500:]

    _log_patch(f"APPLY_OK files={n}")
    return f"Patch applied: {n} file(s). Compile check OK. Snapshot: {snap.name}"


def patch_rollback(snapshot_zip: Optional[str] = None) -> str:
    SNAPSHOTS_DIR.mkdir(parents=True, exist_ok=True)
    snaps = sorted(SNAPSHOTS_DIR.glob("snapshot_*.zip"), key=lambda p: p.name, reverse=True)
    if snapshot_zip:
        snap = Path(snapshot_zip)
        if not snap.is_absolute():
            snap = SNAPSHOTS_DIR / snapshot_zip
    else:
        snap = snaps[0] if snaps else None

    if not snap or not snap.exists():
        return "No snapshot found to rollback."

    _log_patch(f"ROLLBACK {snap.name}")

    with zipfile.ZipFile(snap, "r") as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            out = BASE_DIR / info.filename
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(z.read(info))

    ok_compile, out = _py_compile_check()
    if not ok_compile:
        return "Rollback completed, but compile check still failing.\n\nCompile output:\n" + out[-3500:]
    return f"Rollback completed from snapshot: {snap.name}"


# =========================
# Deterministic answers & hallucination filters
# =========================
def hard_answer(user_text: str) -> Optional[str]:
    t = (user_text or "").strip().lower()

    if t in {"can you code", "can you code?", "do you code", "do you code?"}:
        return ("Yes. I can write code, debug it, and explain it. "
                "I just can’t scan your machine or execute system actions unless you trigger an explicit tool command.")

    if "scan my machine" in t or "scan my computer" in t or "run a scan" in t or "nmap" in t:
        return ("No. I can’t scan your machine or run tools like nmap by myself. "
                "Tell me what you want checked and I’ll give you safe commands to run, then paste the output and I’ll interpret it.")

    return None


def sanitize_llm_reply(reply: str) -> str:
    r = (reply or "").strip()
    low = r.lower()

    suspicious = any(x in low for x in [
        "starting nmap", "nmap scan report", "c:\\>nmap", "host is up",
        "port     state service", "i'm running a system scan", "scan report for",
        "command prompt", "powershell>",
    ])

    if suspicious:
        return ("I didn’t run any scan or command output. "
                "If you want, tell me what you want to check and I’ll give you safe commands to run, "
                "then paste the output and I’ll interpret it.")
    return r


# =========================
# Ollama chat
# =========================
def ollama_chat(text: str) -> str:
    """
    Deterministic chat wrapper: strict non-hallucination rules and low temperature.
    This function avoids injecting memory and enforces a constrained system prompt.
    """
    # Ensure the Ollama service is available (boot-time should have called ensure_ollama_boot)
    try:
        ensure_ollama()
    except Exception:
        # proceed; requests will surface an error which we retry below
        pass

    # Build a strict system message that prevents fabricated actions
    system_msg = (
        "You are Nova running locally on Windows.\n"
        "Rules:\n"
        "- Never claim you performed actions on the PC (open, unzip, delete, move, install, browse, click, run commands) unless a tool was actually executed and its real output is available.\n"
        "- Never invent links, file paths, filenames, or results. If unsure, say you are unsure.\n"
        "- If the user is vague, ask exactly ONE clarifying question.\n"
        "- Keep answers short, concrete, and verifiable.\n"
    )

    payload = {
        "model": chat_model(),
        "stream": False,
        "options": {"temperature": 0.2, "top_p": 0.9, "repeat_penalty": 1.1},
        "messages": [
            {"role": "system", "content": system_msg},
            {"role": "user", "content": text},
        ],
    }

    # Primary call with one deterministic retry after a service restart
    try:
        r = requests.post(f"{OLLAMA_BASE}/api/chat", json=payload, timeout=OLLAMA_REQ_TIMEOUT)
        r.raise_for_status()
        return r.json()["message"]["content"].strip()
    except Exception:
        warn("Ollama chat failed; attempting one restart and retry.")
        try:
            kill_ollama()
            time.sleep(1.2)
            start_ollama_serve_detached()
            time.sleep(1.2)
            r = requests.post(f"{OLLAMA_BASE}/api/chat", json=payload, timeout=OLLAMA_REQ_TIMEOUT)
            r.raise_for_status()
            return r.json()["message"]["content"].strip()
        except Exception as e:
            warn(f"Ollama chat final attempt failed: {e}")
            return "(error: LLM service unavailable)"


# =========================
# Voice (STT)
# =========================
def record_seconds(seconds=3):
    if not VOICE_OK or sd is None:
        raise RuntimeError(f"Voice is disabled (import error: {VOICE_IMPORT_ERR})")
    print(f"Nova: recording for {seconds} seconds... (talk now)", flush=True)
    audio = sd.rec(
        int(seconds * SAMPLE_RATE),
        samplerate=SAMPLE_RATE,
        channels=CHANNELS,
        dtype="int16",
    )
    sd.wait()
    return audio


def transcribe(model, audio_int16):
    if not VOICE_OK or wav is None:
        raise RuntimeError(f"Voice is disabled (import error: {VOICE_IMPORT_ERR})")
    buf = io.BytesIO()
    wav.write(buf, SAMPLE_RATE, audio_int16)
    buf.seek(0)
    segments, _ = model.transcribe(buf)
    return " ".join(seg.text.strip() for seg in segments).strip()


# =========================
# Tools
# =========================
def run_tool_py(script: str, args=None) -> str:
    args = args or []
    p = subprocess.run([PYTHON, script] + args, capture_output=True, text=True)
    out = (p.stdout or "")
    if p.stderr:
        out += ("\n" + p.stderr)
    return out.strip()


def tool_screen():
    if not policy_tools_enabled().get("screen", True):
        return "Screen tool disabled by policy."
    return run_tool_py(str(BASE_DIR / "look_crop.py"))


def tool_camera(prompt: str):
    if not policy_tools_enabled().get("camera", True):
        return "Camera tool disabled by policy."
    return run_tool_py(str(BASE_DIR / "camera.py"), [prompt])


def tool_ls(subfolder=""):
    if not policy_tools_enabled().get("files", True):
        return "File tools disabled by policy."
    target = allowed_root() if not subfolder else safe_path(subfolder)
    if not target.exists() or not target.is_dir():
        return f"Not a folder: {target}"
    lines = []
    for p in sorted(target.iterdir(), key=lambda x: (x.is_file(), x.name.lower())):
        lines.append(("DIR  " if p.is_dir() else "FILE ") + p.name)
    return "\n".join(lines)


def tool_read(path: str):
    if not policy_tools_enabled().get("files", True):
        return "File tools disabled by policy."
    p = safe_path(path)
    if not p.exists() or not p.is_file():
        return f"Not a file: {p}"
    return p.read_text(encoding="utf-8", errors="replace")


def tool_find(keyword: str, subfolder=""):
    if not policy_tools_enabled().get("files", True):
        return "File tools disabled by policy."
    start = allowed_root() if not subfolder else safe_path(subfolder)
    if not start.exists() or not start.is_dir():
        return f"Not a folder: {start}"

    exts = {".txt", ".md", ".log", ".json", ".xml", ".csv", ".ini", ".conf",
            ".php", ".js", ".ts", ".css", ".html", ".htm", ".py", ".sql"}
    hits = []
    kw = keyword.lower()

    for root, _, files in os.walk(start):
        for name in files:
            p = Path(root) / name
            if p.suffix.lower() not in exts:
                continue
            try:
                content = p.read_text(encoding="utf-8", errors="ignore").lower()
            except Exception:
                continue
            if kw in content:
                hits.append(str(p))

    if not hits:
        return "No matches found."
    return "Matches:\n" + "\n".join(hits[:200]) + (f"\n...and {len(hits)-200} more" if len(hits) > 200 else "")


def tool_web(url: str):
    # capability awareness check
    missing = explain_missing("web_fetch", ["web_access"])
    if missing:
        return missing
    
    if not policy_tools_enabled().get("web", False):
        return "Web tool disabled by policy."
    out = web_fetch(url, WEB_CACHE_DIR)

    if not out.get("ok"):
        return f"[FAIL] {out.get('error', 'unknown error')}"
    return f"[OK] Saved: {out['path']} ({out['content_type']}, {out['bytes']} bytes)"


def handle_keywords(text: str):
    low = text.lower().strip()

    if low in {"screen", "look at my screen"}:
        return ("tool", tool_screen())

    if low.startswith("camera"):
        prompt = text[len("camera"):].strip() or "what do you see"
        return ("tool", tool_camera(prompt))

    if low.startswith("web "):
        url = text.split(maxsplit=1)[1].strip()
        return ("tool", tool_web(url))

    if low.startswith("ls"):
        parts = text.split(maxsplit=1)
        sub = parts[1] if len(parts) > 1 else ""
        return ("tool", tool_ls(sub))

    if low.startswith("read "):
        path = text.split(maxsplit=1)[1]
        return ("tool", tool_read(path))

    if low.startswith("find "):
        parts = text.split(maxsplit=2)
        keyword = parts[1] if len(parts) > 1 else ""
        folder = parts[2] if len(parts) > 2 else ""
        return ("tool", tool_find(keyword, folder))

    if low in {"health", "status"}:
        hp = BASE_DIR / "health.py"
        if hp.exists():
            return ("tool", run_tool_py(str(hp), ["check"]))
        return ("tool", "health.py not found.")

    return None


# =========================
# Commands (typed) for kb / patch
# =========================
def handle_commands(user_text: str) -> Optional[str]:
    t = (user_text or "").strip()
    low = t.lower()

    if low in {"what can you do", "capabilities", "show capabilities"}:
        return describe_capabilities()

    if low == "kb" or low == "kb help":
        return ("KB commands:\n"
                "  kb list\n"
                "  kb use <pack>\n"
                "  kb off\n"
                "  kb add <zip_path> <pack_name>\n")

    if low == "kb list":
        return kb_list_packs()

    if low.startswith("kb use "):
        name = t.split(maxsplit=2)[2].strip()
        return kb_set_active(name)

    if low == "kb off":
        return kb_set_active(None)

    if low.startswith("kb add "):
        parts = t.split(maxsplit=3)
        if len(parts) < 4:
            return "Usage: kb add <zip_path> <pack_name>"
        return kb_add_zip(parts[2], parts[3])

    if low == "patch" or low == "patch help":
        return ("Patch commands:\n"
                "  patch apply <zip_path>\n"
                "  patch rollback   (roll back to last snapshot)\n")

    if low.startswith("patch apply "):
        p = t.split(maxsplit=2)[2].strip()
        return patch_apply(p)

    if low == "patch rollback":
        return patch_rollback()
    
    if low == "inspect":
        data = inspect_environment()
        return format_report(data)

    return None


# =========================
# Main loop
# =========================
def run_loop(tts):
    whisper = None
    if VOICE_OK and WhisperModel is not None:
        print("Nova Core: loading Whisper (CPU mode)...", flush=True)
        whisper = WhisperModel(whisper_size(), device="cpu", compute_type="int8")
    else:
        warn(f"Voice mode disabled; typed chat still works. (Reason: {VOICE_IMPORT_ERR})")

    print("\nNova Core is ready.", flush=True)
    print("Commands: screen | camera <prompt> | web <url> | ls [folder] | read <file> | find <kw> [folder] | health | capabilities", flush=True)
    print("Press ENTER for voice. Or type a message/command and press ENTER. Type 'q' to quit.\n", flush=True)

    while True:
        raw = input("> ").strip()

        if raw.lower() == "q":
            break

        if raw:
            user_text = raw
            print(f"You (typed): {user_text}", flush=True)
        else:
            if not whisper:
                print("Nova: voice is disabled on this machine right now. Type your message instead.\n", flush=True)
                continue
            audio = record_seconds(RECORD_SECONDS)
            print("Nova: transcribing...", flush=True)
            user_text = transcribe(whisper, audio)
            if not user_text:
                print("Nova: (heard nothing)\n", flush=True)
                continue
            print(f"You: {user_text}", flush=True)

        cmd_out = handle_commands(user_text)
        if cmd_out:
            print(f"Nova: {cmd_out}\n", flush=True)
            speak_chunked(tts, cmd_out)
            continue

        routed = handle_keywords(user_text)
        if routed:
            _, out = routed
            print(f"Nova (tool output):\n{out}\n", flush=True)
            tts.say("Done.")
            continue

        ha = hard_answer(user_text)
        if ha:
            print(f"Nova: {ha}\n", flush=True)
            speak_chunked(tts, ha)
            continue

        print("Nova: thinking...", flush=True)

        task = analyze_task(user_text)
        if not task["allow_llm"]:
            print(f"Nova: {task['message']}\n")
            speak_chunked(tts, task['message'])
            continue

        reply = ollama_chat(user_text)
        reply = sanitize_llm_reply(reply)

        if mem_enabled():
            mem_add("chat_user", "typed", user_text)
            mem_add("chat_assistant", "typed", reply)

        print(f"Nova: {reply}\n", flush=True)
        speak_chunked(tts, reply)

# =========================
# Entrypoint
# =========================
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", nargs="?", default="run", choices=["run"])
    ap.add_argument("--heartbeat", default=str(DEFAULT_HEARTBEAT))
    ap.add_argument("--statefile", default=str(DEFAULT_STATEFILE))
    args = ap.parse_args()

    hb = Path(args.heartbeat)
    st = Path(args.statefile)

    write_core_identity(st)
    hb_stop = start_heartbeat(hb, interval_sec=1.0)

    tts = SubprocessTTS(PYTHON, BASE_DIR / "tts_piper.py", timeout_sec=25.0)
    tts.start()
    tts.say("Nova online.")

    ensure_ollama_boot()

    try:
        run_loop(tts)
    finally:
        hb_stop.set()
        tts.stop()


if __name__ == "__main__":
    main()
