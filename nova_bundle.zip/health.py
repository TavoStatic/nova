#!/usr/bin/env python3
"""Simple health check for Project NOVA.

Checks:
- runtime/core.heartbeat freshness
- runtime/core_state.json PID liveness
- Ollama API availability

Exit code 0 on success, 1 on any failure. Prints a JSON summary.
"""
import json
import sys
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
RUNTIME = BASE / "runtime"
HEARTBEAT = RUNTIME / "core.heartbeat"
STATE = RUNTIME / "core_state.json"
OLLAMA = "http://127.0.0.1:11434"

import psutil
import requests

def check_heartbeat(max_age=10):
    if not HEARTBEAT.exists():
        return False, "missing"
    age = time.time() - HEARTBEAT.stat().st_mtime
    return (age <= max_age), f"age={int(age)}s"

def check_state():
    if not STATE.exists():
        return False, "missing"
    try:
        data = json.loads(STATE.read_text(encoding="utf-8"))
        pid = int(data.get("pid", 0) or 0)
        if pid <= 0:
            return False, "invalid-pid"
        alive = psutil.pid_exists(pid)
        return alive, f"pid={pid}"
    except Exception as e:
        return False, f"error:{e}"

def check_ollama(timeout=1.0):
    try:
        r = requests.get(OLLAMA + "/api/tags", timeout=timeout)
        return r.status_code == 200, f"status={r.status_code}"
    except Exception as e:
        return False, f"error:{e}"

def main():
    hb_ok, hb_msg = check_heartbeat()
    st_ok, st_msg = check_state()
    ol_ok, ol_msg = check_ollama()

    ok = hb_ok and st_ok and ol_ok
    out = {
        "heartbeat": {"ok": hb_ok, "info": hb_msg},
        "core_state": {"ok": st_ok, "info": st_msg},
        "ollama": {"ok": ol_ok, "info": ol_msg},
        "ok": ok,
    }
    print(json.dumps(out, indent=2))
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
import argparse
import json
import socket
import subprocess
import time
from typing import Tuple

import requests

OLLAMA_BASE = "http://127.0.0.1:11434"
REQUIRED_MODELS = ["llama3.1:8b", "qwen2.5vl:7b"]  # adjust if you want

def ok(msg): print(f"[OK]   {msg}")
def warn(msg): print(f"[WARN] {msg}")
def bad(msg): print(f"[FAIL] {msg}")

def tcp_listening(host="127.0.0.1", port=11434, timeout=1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False

def ollama_api_up(timeout=2.0) -> bool:
    try:
        r = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=timeout)
        return r.status_code == 200
    except Exception:
        return False

def ollama_tags() -> Tuple[bool, list]:
    try:
        r = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=5)
        r.raise_for_status()
        data = r.json()
        models = [m.get("name", "") for m in data.get("models", [])]
        return True, models
    except Exception:
        return False, []

def start_ollama_serve_detached() -> bool:
    try:
        DETACHED = 0x00000008
        NEW_GROUP = 0x00000200
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=DETACHED | NEW_GROUP,
        )
        return True
    except Exception:
        return False

def kill_ollama() -> bool:
    try:
        subprocess.run(["taskkill", "/F", "/IM", "ollama.exe"], capture_output=True, text=True)
        return True
    except Exception:
        return False

def check_gpu():
    try:
        r = subprocess.run(["nvidia-smi"], capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            ok("nvidia-smi OK (GPU visible)")
        else:
            warn("nvidia-smi failed (GPU may be unavailable or driver missing)")
    except Exception:
        warn("nvidia-smi not available")

def check_mic():
    try:
        import sounddevice as sd
        devices = sd.query_devices()
        inputs = [d for d in devices if d.get("max_input_channels", 0) > 0]
        if inputs:
            ok(f"Microphone devices found: {len(inputs)}")
        else:
            warn("No microphone input devices found")
    except Exception as e:
        warn(f"Microphone check failed: {e}")

def check_camera():
    try:
        import cv2
        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        if cap.isOpened():
            ok("Camera index 0 opens OK")
        else:
            warn("Camera index 0 failed to open")
        cap.release()
    except Exception as e:
        warn(f"Camera check failed: {e}")

def check_python_packages():
    needed = [
        "requests", "pyttsx3", "faster_whisper", "sounddevice", "scipy", "cv2", "PIL"
    ]
    missing = []
    for p in needed:
        try:
            __import__(p)
        except Exception:
            missing.append(p)
    if not missing:
        ok("Python packages OK")
    else:
        bad(f"Missing Python packages: {', '.join(missing)}")

def repair_ollama():
    # If TCP isn't listening, try starting serve
    if not tcp_listening():
        warn("Port 11434 not listening. Starting ollama serve...")
        if not start_ollama_serve_detached():
            bad("Failed to start ollama serve")
            return False

    # If listening but API not responding, restart
    if tcp_listening() and not ollama_api_up():
        warn("Port is listening but Ollama API not responding. Restarting ollama...")
        kill_ollama()
        time.sleep(1.5)
        if not start_ollama_serve_detached():
            bad("Failed to restart ollama serve")
            return False

    # Wait for API
    for _ in range(15):
        if ollama_api_up(timeout=2.0):
            ok("Ollama API is up")
            return True
        time.sleep(1)

    bad("Ollama API still not responding after repair attempts")
    return False

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", nargs="?", default="check", choices=["check", "repair"])
    args = ap.parse_args()

    print("\n=== Nova Health Check ===\n")

    check_python_packages()
    check_gpu()
    check_mic()
    check_camera()

    # Ollama checks
    if tcp_listening():
        ok("Port 11434 is listening")
    else:
        bad("Port 11434 is NOT listening (Ollama not serving)")

    if ollama_api_up():
        ok("Ollama API responding (/api/tags)")
        ok_tags, models = ollama_tags()
        if ok_tags:
            ok(f"Ollama models found: {len(models)}")
            missing = [m for m in REQUIRED_MODELS if m not in models]
            if missing:
                warn("Missing required models: " + ", ".join(missing))
                warn("Fix: ollama pull " + " ; ".join(missing))
            else:
                ok("Required models present")
        else:
            warn("Could not fetch model list")
    else:
        bad("Ollama API NOT responding")

    if args.mode == "repair":
        print("\n=== Repair Mode ===\n")
        repair_ollama()

    print("\n=== Done ===\n")

if __name__ == "__main__":
    main()