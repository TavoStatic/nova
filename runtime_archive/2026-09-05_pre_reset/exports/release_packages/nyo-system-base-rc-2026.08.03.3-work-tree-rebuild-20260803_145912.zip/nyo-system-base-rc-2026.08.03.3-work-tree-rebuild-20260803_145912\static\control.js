document.body.classList.add('js-ready');

const keyInput = document.getElementById('key');
const statusKv = document.getElementById('statusKv');
const healthBadge = document.getElementById('healthBadge');
const feedbackBar = document.getElementById('feedbackBar');
const runtimeNoteBar = document.getElementById('runtimeNoteBar');
const policyBox = document.getElementById('policyBox');
const actionBox = document.getElementById('actionBox');
const actionBoxClone = document.getElementById('actionBoxClone');
const guardBox = document.getElementById('guardBox');
const sessionFilterSelect = document.getElementById('sessionFilterSelect');
const sessionModeMeta = document.getElementById('sessionModeMeta');
const sessionSelect = document.getElementById('sessionSelect');
const sessionBox = document.getElementById('sessionBox');
const sessionProbeBox = document.getElementById('sessionProbeBox');
const testRunSelect = document.getElementById('testRunSelect');
const testRunBox = document.getElementById('testRunBox');
const testRunProbeBox = document.getElementById('testRunProbeBox');
const testRunBadges = document.getElementById('testRunBadges');
const testSessionDefinitionSelect = document.getElementById('testSessionDefinitionSelect');
const testRunDriftGrid = document.getElementById('testRunDriftGrid');
const workTreeSelect = document.getElementById('workTreeSelect');
const workTreeGlobalCounts = document.getElementById('workTreeGlobalCounts');
const workTreeSelectedCounts = document.getElementById('workTreeSelectedCounts');
const workTreeLiveSummary = document.getElementById('workTreeLiveSummary');
const workTreeSelectedSummary = document.getElementById('workTreeSelectedSummary');
const workTreeEmptyState = document.getElementById('workTreeEmptyState');
const workTreeSvg = document.getElementById('workTreeSvg');
const workTreeBranchInfo = document.getElementById('workTreeBranchInfoBody') || document.getElementById('workTreeBranchInfo');
const workTreeProgressPanel = document.getElementById('workTreeProgressPanel');
const workTreeBranchActions = document.getElementById('workTreeBranchActions');
const workTreeActionFeedback = document.getElementById('workTreeActionFeedback');
const btnWorkTreeRunNext = document.getElementById('btnWorkTreeRunNext');
const btnPatchQueueRunNext = document.getElementById('btnPatchQueueRunNext');
const btnPulseStatus = document.getElementById('btnPulseStatus');
const pipelineSelect = document.getElementById('pipelineSelect');
const pipelineListSummary = document.getElementById('pipelineListSummary');
const pipelineCards = document.getElementById('pipelineCards');
const pipelineStatusGrid = document.getElementById('pipelineStatusGrid');
const backpackSelect = document.getElementById('backpackSelect');
const backpackListSummary = document.getElementById('backpackListSummary');
const backpackCards = document.getElementById('backpackCards');
const backpackStatusGrid = document.getElementById('backpackStatusGrid');
const backpackModelNote = document.getElementById('backpackModelNote');
const backpackActionResult = document.getElementById('backpackActionResult');
const backpackGrantsBox = document.getElementById('backpackGrantsBox');
const backpackProbeLea = document.getElementById('backpackProbeLea');
const backpackReportSummary = document.getElementById('backpackReportSummary');
const backpackReportTable = document.getElementById('backpackReportTable');
const backpackReportLimit = document.getElementById('backpackReportLimit');
const backpackEmptyState = document.getElementById('backpackEmptyState');
const backpackDetailBody = document.getElementById('backpackDetailBody');
const backpackBusyBar = document.getElementById('backpackBusyBar');
const backpackBusyText = document.getElementById('backpackBusyText');
const backpackEnabledBadge = document.getElementById('backpackEnabledBadge');
const bpFieldConnectionId = document.getElementById('bpFieldConnectionId');
const bpFieldBaseUrl = document.getElementById('bpFieldBaseUrl');
const bpFieldClientId = document.getElementById('bpFieldClientId');
const bpFieldClientSecret = document.getElementById('bpFieldClientSecret');
const bpFieldLea = document.getElementById('bpFieldLea');
const bpFieldScope = document.getElementById('bpFieldScope');
const bpFieldAllowedLeas = document.getElementById('bpFieldAllowedLeas');
const bpFieldAccessTier = document.getElementById('bpFieldAccessTier');
const pipelineSchemaSummary = document.getElementById('pipelineSchemaSummary');
const pipelineNoteType = document.getElementById('pipelineNoteType');
const pipelineNoteInput = document.getElementById('pipelineNoteInput');
const pipelineIntakeBox = document.getElementById('pipelineIntakeBox');
const pipelineCreateId = document.getElementById('pipelineCreateId');
const pipelineCreateName = document.getElementById('pipelineCreateName');
const pipelineEditName = document.getElementById('pipelineEditName');
const pipelineEditDescription = document.getElementById('pipelineEditDescription');
const pipelineEditScope = document.getElementById('pipelineEditScope');
const pipelinePopulationKey = document.getElementById('pipelinePopulationKey');
const pipelinePopulationLabel = document.getElementById('pipelinePopulationLabel');
const pipelinePopulationProgram = document.getElementById('pipelinePopulationProgram');
const pipelinePopulationField = document.getElementById('pipelinePopulationField');
const pipelinePopulationNotes = document.getElementById('pipelinePopulationNotes');
const pipelinePopulationSection = document.getElementById('pipelinePopulationSection');
const pipelineEdfiSection = document.getElementById('pipelineEdfiSection');
const pipelineEdfiSyncGrid = document.getElementById('pipelineEdfiSyncGrid');
const pipelineQuerySection = document.getElementById('pipelineQuerySection');
const pipelineQueryOperation = document.getElementById('pipelineQueryOperation');
const pipelineQueryDescription = document.getElementById('pipelineQueryDescription');
const pipelineQueryParams = document.getElementById('pipelineQueryParams');
const pipelineQueryRowLimit = document.getElementById('pipelineQueryRowLimit');
const pipelineQueryTable = document.getElementById('pipelineQueryTable');
const pipelineQueryResult = document.getElementById('pipelineQueryResult');
let pipelineQueryCatalogCache = {};
let pipelineQueryParamValuesCache = {};
const taskManagerSelect = document.getElementById('taskManagerSelect');
const taskManagerPreview = document.getElementById('taskManagerPreview');
const taskManagerName = document.getElementById('taskManagerName');
const taskManagerTaskId = document.getElementById('taskManagerTaskId');
const taskManagerCategory = document.getElementById('taskManagerCategory');
const taskManagerObjective = document.getElementById('taskManagerObjective');
const taskManagerPrompt = document.getElementById('taskManagerPrompt');
const taskManagerFollowup = document.getElementById('taskManagerFollowup');
const taskManagerNotes = document.getElementById('taskManagerNotes');
const operatorSessionIdInput = document.getElementById('operatorSessionId');
const operatorMacroSelect = document.getElementById('operatorMacroSelect');
const operatorPromptInput = document.getElementById('operatorPromptInput');
const operatorPromptReply = document.getElementById('operatorPromptReply');
const btnSidebarToggle = document.getElementById('btnSidebarToggle');
const btnInspectorToggle = document.getElementById('btnInspectorToggle');
const btnOperatorToggleAudio = document.getElementById('btnOperatorToggleAudio');
const btnOperatorMic = document.getElementById('btnOperatorMic');
const backendCommandSelect = document.getElementById('backendCommandSelect');
const backendCommandArgs = document.getElementById('backendCommandArgs');
const backendCommandOutput = document.getElementById('backendCommandOutput');
const operatorOutboxSelect = document.getElementById('operatorOutboxSelect');
const operatorOutboxResolution = document.getElementById('operatorOutboxResolution');
const operatorOutboxResponse = document.getElementById('operatorOutboxResponse');
const operatorOutboxBox = document.getElementById('operatorOutboxBox');
const operatorOutboxBadge = document.getElementById('operatorOutboxBadge');
const memoryScopeSelect = document.getElementById('memoryScope');
const memoryScopeBox = document.getElementById('memoryScopeBox');
const serverSideModeSelect = document.getElementById('serverSideMode');
const serverSideFrontdoorSelect = document.getElementById('serverSideFrontdoor');
const serverSideBaseUrlInput = document.getElementById('serverSideBaseUrl');
const serverSideDockerSelect = document.getElementById('serverSideDockerEnabled');
const serverSideBox = document.getElementById('serverSideBox');
const searchEndpointInput = document.getElementById('searchEndpoint');
const searchProviderPriorityInput = document.getElementById('searchProviderPriority');
const searchEndpointBox = document.getElementById('searchEndpointBox');
const chatUserSelect = document.getElementById('chatUserSelect');
const chatUserNameInput = document.getElementById('chatUserName');
const chatUserPassInput = document.getElementById('chatUserPass');
const chatAuthBox = document.getElementById('chatAuthBox');
const temporalStatusGrid = document.getElementById('temporalStatusGrid');
const temporalStatusBox = document.getElementById('temporalStatusBox');
const plannerInspector = document.getElementById('plannerInspector');
const ledgerInspector = document.getElementById('ledgerInspector');
const supervisorInspector = document.getElementById('supervisorInspector');
const sessionStateInspector = document.getElementById('sessionStateInspector');
const overrideBadges = document.getElementById('overrideBadges');
const patchStatusBadge = document.getElementById('patchStatusBadge');
const patchStatusNarrative = document.getElementById('patchStatusNarrative');
const patchPreviewSelect = document.getElementById('patchPreviewSelect');
const patchPreviewNote = document.getElementById('patchPreviewNote');
const patchSummaryGrid = document.getElementById('patchSummaryGrid');
const patchPreviewGrid = document.getElementById('patchPreviewGrid');
const patchLogBox = document.getElementById('patchLogBox');
const patchPreviewSummary = document.getElementById('patchPreviewSummary');
const patchPreviewBox = document.getElementById('patchPreviewBox');
const patchActionReadiness = document.getElementById('patchActionReadiness');
const healthSummary = document.getElementById('healthSummary');
const runtimeSummary = document.getElementById('runtimeSummary');
const runtimeRawBox = document.getElementById('runtimeRawBox');
const runtimeTimeline = document.getElementById('runtimeTimeline');
const runtimeFailures = document.getElementById('runtimeFailures');
const runtimeArtifacts = document.getElementById('runtimeArtifacts');
const artifactDetailMeta = document.getElementById('artifactDetailMeta');
const artifactDetailBox = document.getElementById('artifactDetailBox');
const releaseStatusGrid = document.getElementById('releaseStatusGrid');
const releaseNarrative = document.getElementById('releaseNarrative');
const releaseLedgerGrid = document.getElementById('releaseLedgerGrid');
const restartAnalytics = document.getElementById('restartAnalytics');
const telemetrySummary = document.getElementById('telemetrySummary');
const telemetryPressure = document.getElementById('telemetryPressure');
const runtimeActionReadiness = document.getElementById('runtimeActionReadiness');
const supervisorSummaryMain = document.getElementById('supervisorSummaryMain');
const guardRawBox = document.getElementById('guardRawBox');
const heroHealthSummary = document.getElementById('heroHealthSummary');
const heroRouteSummary = document.getElementById('heroRouteSummary');
const heroOpsSummary = document.getElementById('heroOpsSummary');
const heroHealthMeta = document.getElementById('heroHealthMeta');
const heroRouteMeta = document.getElementById('heroRouteMeta');
const heroOpsMeta = document.getElementById('heroOpsMeta');
const subconsciousStatusBox = document.getElementById('subconsciousStatusBox');
const subconsciousLiveList = document.getElementById('subconsciousLiveList');
const subconsciousPriorityList = document.getElementById('subconsciousPriorityList');
const generatedQueueBox = document.getElementById('generatedQueueBox');
const generatedQueueCount = document.getElementById('generatedQueueCount');
const overviewFocusStrip = document.getElementById('overviewFocusStrip');
const overviewStallRecovery = document.getElementById('overviewStallRecovery');
const overviewStallRecoverySummary = document.getElementById('overviewStallRecoverySummary');
const overviewStallRecoveryBadge = document.getElementById('overviewStallRecoveryBadge');
const overviewStallRecoveryBox = document.getElementById('overviewStallRecoveryBox');
const btnWorkTreeOpenOperatorDeck = document.getElementById('btnWorkTreeOpenOperatorDeck');
const btnWorkTreeDismissOutbox = document.getElementById('btnWorkTreeDismissOutbox');
const btnWorkTreeRunQueueNext = document.getElementById('btnWorkTreeRunQueueNext');
const centerMissionBrief = document.getElementById('centerMissionBrief');
const liveTrackingSummary = document.getElementById('liveTrackingSummary');
const liveTrackingSignal = document.getElementById('liveTrackingSignal');
const liveTrackingMeta = document.getElementById('liveTrackingMeta');
const liveTrackingStatusBadge = document.getElementById('liveTrackingStatusBadge');
const liveTrackingConsentNote = document.getElementById('liveTrackingConsentNote');
const btnLocationTrackStart = document.getElementById('btnLocationTrackStart');
const btnLocationTrackAutoArm = document.getElementById('btnLocationTrackAutoArm');
const btnLocationTrackStop = document.getElementById('btnLocationTrackStop');
const btnLocationTrackClear = document.getElementById('btnLocationTrackClear');
const metricsCanvas = document.getElementById('metricsCanvas');
const ctx = metricsCanvas ? metricsCanvas.getContext('2d') : null;
const telemetryGraphToolbar = document.getElementById('telemetryGraphToolbar');
const telemetryGraphFootnote = document.getElementById('telemetryGraphFootnote');
const telemetryGraphButtons = Array.from(document.querySelectorAll('[data-telemetry-graph]'));
const temporalNavLink = document.getElementById('temporalNavLink');
const navButtons = Array.from(document.querySelectorAll('[data-view-target]'));
const mainViews = Array.from(document.querySelectorAll('.main-view'));
const centerTabBar = document.querySelector('.center-tab-bar');
const centerTabButtons = Array.from(document.querySelectorAll('[data-center-tab]'));
const centerTabPanels = Array.from(document.querySelectorAll('[data-center-panel]'));
const layerTabShells = Array.from(document.querySelectorAll('.layer-tab-shell'));
const inspectorTabBar = document.querySelector('.inspector-tab-bar');
const inspectorTabButtons = Array.from(document.querySelectorAll('[data-inspector-tab]'));
const inspectorTabPanels = Array.from(document.querySelectorAll('[data-inspector-panel]'));

let sessionsCache = [];
let testRunsCache = [];
let testSessionDefinitions = [];
let latestStatus = null;
let latestPolicy = null;
let latestMetrics = null;
let workTreesCache = [];
let pipelinesCache = [];
let backpacksCache = [];
let selectedBackpackId = '';
let backpackDetailCache = null;
let selectedPipelineId = '';
let pipelineDetailCache = null;
let selectedWorkTreeId = '';
let selectedWorkTreeNodeId = '';
let workTreeViewMode = 'all';
let refreshInFlight = null;
let refreshQueued = false;
const runtimeInspectCache = new Map();
let runtimeInspectSeq = 0;
let selectedArtifactName = '';
let currentArtifactDetail = null;
let operatorPromptBusy = false;
let operatorVoiceOutputEnabled = localStorage.getItem('nova_operator_voice_output') === 'on';
let operatorRecognition = null;
let operatorRecognitionActive = false;
const OperatorSpeechRecognitionCtor = window.SpeechRecognition || window.webkitSpeechRecognition || null;
let operatorMacroValueCache = {};
let operatorOutboxEvents = [];
let telemetryGraphMode = 'combined';
let locationTrackingWatchId = null;
let locationTrackingLastObserved = null;
let locationTrackingLastSent = null;
let locationTrackingLastHopMeters = 0;
let locationTrackingLastError = '';
let locationTrackingSendInFlight = null;
let liveTrackingAutoArmAttempted = false;

const LIVE_TRACKING_AUTO_ARM_KEY = 'nova_live_tracking_auto_arm';
let liveTrackingAutoArmEnabled = localStorage.getItem(LIVE_TRACKING_AUTO_ARM_KEY) === 'on';

const LOCATION_SYNC_MIN_INTERVAL_MS = 10000;
const LOCATION_SYNC_MIN_DISTANCE_M = 15;

function filteredSessions() {
    const filter = sessionFilterSelect ? String(sessionFilterSelect.value || 'all').trim().toLowerCase() : 'all';
    if (filter === 'operator') {
        return sessionsCache.filter((item) => String(item.owner || '').trim().toLowerCase() === 'operator' || String(item.session_id || '').startsWith('operator-'));
    }
    if (filter === 'non-operator') {
        return sessionsCache.filter((item) => !(String(item.owner || '').trim().toLowerCase() === 'operator' || String(item.session_id || '').startsWith('operator-')));
    }
    return sessionsCache;
}

function generatedPriorityRank(priority) {
    const urgency = String(priority && priority.urgency ? priority.urgency : '').trim().toLowerCase();
    return ({high: 0, medium: 1, low: 2, deferred: 3})[urgency] ?? 4;
}

function orderedGeneratedPriorities(item) {
    const priorities = Array.isArray(item && item.training_priorities) ? item.training_priorities.filter((entry) => entry && typeof entry === 'object') : [];
    return priorities.slice().sort((left, right) => {
        const leftRank = generatedPriorityRank(left);
        const rightRank = generatedPriorityRank(right);
        if (leftRank !== rightRank) return leftRank - rightRank;
        const leftRobustness = Number(left && left.robustness != null ? left.robustness : 0);
        const rightRobustness = Number(right && right.robustness != null ? right.robustness : 0);
        if (leftRobustness !== rightRobustness) return rightRobustness - leftRobustness;
        return String(left && left.signal ? left.signal : '').localeCompare(String(right && right.signal ? right.signal : ''));
    });
}

function formatSeamLabel(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    return raw.split('_').filter(Boolean).join(' ');
}

function subconsciousSeamBadgeMeta(value) {
    const seam = String(value || '').trim().toLowerCase();
    if (!seam) return null;
    if (seam.includes('session_fact_recall')) {
        return {text: 'Session Fact Recall', className: 'status-pill status-pill-warn subconscious-seam-badge'};
    }
    if (seam.includes('weather_continuation')) {
        return {text: 'Weather Continuation', className: 'status-pill status-pill-blue subconscious-seam-badge'};
    }
    if (seam.includes('retrieval_followup')) {
        return {text: 'Retrieval Follow-up', className: 'status-pill status-pill-good subconscious-seam-badge'};
    }
    if (seam.includes('memory_capture')) {
        return {text: 'Memory Capture', className: 'status-pill status-pill-danger subconscious-seam-badge'};
    }
    if (seam.includes('patch_routing')) {
        return {text: 'Patch Routing', className: 'status-pill status-pill-neutral subconscious-seam-badge'};
    }
    if (seam.includes('fulfillment')) {
        return {text: 'Fulfillment', className: 'status-pill status-pill-good subconscious-seam-badge'};
    }
    if (seam.includes('supervisor')) {
        return {text: 'Supervisor Boundary', className: 'status-pill status-pill-blue subconscious-seam-badge'};
    }
    return {text: formatSeamLabel(seam), className: 'status-pill status-pill-neutral subconscious-seam-badge'};
}

function summarizeGeneratedPriority(item) {
    const ordered = orderedGeneratedPriorities(item);
    if (!ordered.length) return '';
    const lead = ordered[0] || {};
    const urgency = String(lead.urgency || 'n/a').toLowerCase();
    const signal = String(lead.signal || 'priority').trim();
    const seam = formatSeamLabel(lead.seam || item.family_id || '');
    const score = Number(lead.robustness != null ? lead.robustness : 0);
    const shortScore = Number.isFinite(score) ? score.toFixed(2) : 'n/a';
    return `${urgency} ${signal}${seam ? ' @ ' + seam : ''} (${shortScore})`;
}

function buildGeneratedPriorityTitle(item) {
    const ordered = orderedGeneratedPriorities(item);
    if (!ordered.length) return '';
    return ordered.slice(0, 3).map((entry) => {
        const urgency = String(entry.urgency || 'n/a').toLowerCase();
        const signal = String(entry.signal || 'priority').trim();
        const seam = formatSeamLabel(entry.seam || item.family_id || '');
        const testName = String(entry.suggested_test_name || '').trim();
        const score = Number(entry.robustness != null ? entry.robustness : 0);
        return `${urgency} | ${signal}${seam ? ' | ' + seam : ''}${testName ? ' | ' + testName : ''} | robustness=${Number.isFinite(score) ? score.toFixed(2) : 'n/a'}`;
    }).join('\n');
}

async function resolveOperatorMacroValues(macro) {
    const macroId = String(macro && macro.macro_id ? macro.macro_id : '').trim();
    if (!macroId) return {};
    const placeholders = Array.isArray(macro && macro.placeholders) ? macro.placeholders.filter((item) => item && typeof item === 'object') : [];
    if (!placeholders.length) return {};
    const cached = operatorMacroValueCache[macroId] && typeof operatorMacroValueCache[macroId] === 'object' ? operatorMacroValueCache[macroId] : {};
    const values = {...cached};
    for (const placeholder of placeholders) {
        const name = String(placeholder.name || '').trim();
        if (!name) continue;
        const label = String(placeholder.label || name).trim();
        const current = String(values[name] || placeholder.default || '').trim();
        // Some embedded browser runtimes disallow prompt dialogs; prefer cached/default values.
        const resolved = current || String(placeholder.default || '').trim();
        if (Boolean(placeholder.required) && !resolved) {
            setAction(`Macro placeholder required: ${label}`);
            return null;
        }
        values[name] = resolved;
    }
    operatorMacroValueCache[macroId] = values;
    return values;
}


    function telemetryRecentPoints(points) {
        return Array.isArray(points) ? points.slice(-60) : [];
    }

    function telemetryRates(points) {
        const recent = telemetryRecentPoints(points);
        const requests = [];
        const errors = [];
        const errorRatio = [];
        for (let index = 0; index < recent.length; index += 1) {
            if (index === 0) {
                requests.push(0);
                errors.push(0);
                errorRatio.push(0);
                continue;
            }
            const current = recent[index] || {};
            const previous = recent[index - 1] || {};
            const dt = Math.max(1, Number(current.ts || 0) - Number(previous.ts || 0));
            const dr = Math.max(0, Number(current.requests_total || 0) - Number(previous.requests_total || 0));
            const de = Math.max(0, Number(current.errors_total || 0) - Number(previous.errors_total || 0));
            requests.push((dr * 60) / dt);
            errors.push((de * 60) / dt);
            errorRatio.push(dr > 0 ? (de / dr) * 100 : 0);
        }
        return {recent, requests, errors, errorRatio};
    }

    function telemetryRolling(values, windowSize, reducer) {
        const out = [];
        for (let index = 0; index < values.length; index += 1) {
            const start = Math.max(0, index - windowSize + 1);
            const slice = values.slice(start, index + 1);
            out.push(reducer(slice));
        }
        return out;
    }

    function setTelemetryGraphMode(mode) {
        const target = String(mode || '').trim() || 'combined';
        telemetryGraphMode = target;
        telemetryGraphButtons.forEach((button) => {
            const active = (button.getAttribute('data-telemetry-graph') || '') === target;
            button.classList.toggle('active', active);
            button.setAttribute('aria-selected', active ? 'true' : 'false');
            button.setAttribute('tabindex', active ? '0' : '-1');
        });
        renderTelemetryGraph(latestMetrics, latestStatus);
    }

    window.setTelemetryGraphMode = setTelemetryGraphMode;

    function drawTelemetryGrid(width, height, pad, rows = 4) {
        const innerHeight = height - pad * 2;
        ctx.strokeStyle = '#1f2d45';
        ctx.lineWidth = 1;
        for (let index = 0; index <= rows; index += 1) {
            const gy = pad + (innerHeight / rows) * index;
            ctx.beginPath();
            ctx.moveTo(pad, gy);
            ctx.lineTo(width - pad, gy);
            ctx.stroke();
        }
    }

    function plotTelemetrySeries(values, color, x, y, fill = false) {
        if (!values.length) return;
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        values.forEach((value, index) => {
            const px = x(index);
            const py = y(value);
            if (index === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        });
        ctx.stroke();
        if (fill) {
            const lastX = x(values.length - 1);
            const baseline = y(0);
            ctx.lineTo(lastX, baseline);
            ctx.lineTo(x(0), baseline);
            ctx.closePath();
            ctx.fillStyle = color.replace('rgb', 'rgba').replace(')', ', 0.12)').replace('#f59e0b', 'rgba(245, 158, 11, 0.12)');
            ctx.fill();
        }
    }

    function drawDependencyLanes(recent, width, height, pad) {
        const laneHeight = 30;
        const laneGap = 18;
        const startY = pad + 18;
        const labelX = pad;
        const chartLeft = pad + 98;
        const chartWidth = width - chartLeft - pad;
        const boxWidth = chartWidth / Math.max(1, recent.length);
        const lanes = [
            {label: 'Ollama API', key: 'ollama_api_up'},
            {label: 'SearXNG', key: 'searxng_ok'}
        ];
        ctx.font = '12px Consolas';
        lanes.forEach((lane, laneIndex) => {
            const y = startY + laneIndex * (laneHeight + laneGap);
            ctx.fillStyle = '#8ea0bb';
            ctx.fillText(lane.label, labelX, y + 18);
            recent.forEach((point, index) => {
                const value = point ? point[lane.key] : null;
                const ok = value === true;
                const warn = value !== true && value != null;
                ctx.fillStyle = ok ? 'rgba(34, 197, 94, 0.72)' : (warn ? 'rgba(245, 158, 11, 0.68)' : 'rgba(239, 68, 68, 0.68)');
                ctx.fillRect(chartLeft + index * boxWidth, y, Math.max(2, boxWidth - 1), laneHeight);
            });
        });
    }

    function renderTelemetryGraph(metrics, status) {
        if (!ctx || !metricsCanvas) return;
        const width = metricsCanvas.width;
        const height = metricsCanvas.height;
        ctx.clearRect(0, 0, width, height);
        ctx.fillStyle = '#07101d';
        ctx.fillRect(0, 0, width, height);

        const points = Array.isArray(metrics && metrics.points) ? metrics.points : [];
        const {recent, requests, errors, errorRatio} = telemetryRates(points);
        if (recent.length < 2) {
            ctx.fillStyle = '#8ea0bb';
            ctx.font = '14px Segoe UI';
            ctx.fillText('Telemetry will appear after a few refresh cycles.', 16, 28);
            if (telemetryGraphFootnote) {
                telemetryGraphFootnote.textContent = 'Telemetry stream is still warming up.';
            }
            return;
        }

        const pad = 28;
        const innerWidth = width - pad * 2;
        const innerHeight = height - pad * 2;
        const x = (index) => pad + (index / Math.max(1, recent.length - 1)) * innerWidth;
        let footnote = 'Green: heartbeat age | Blue: requests/min | Red: errors/min';

        if (telemetryGraphMode === 'dependencies') {
            drawDependencyLanes(recent, width, height, pad);
            const last = recent[recent.length - 1] || {};
            footnote = `Dependency lanes | Ollama ${last.ollama_api_up ? 'up' : 'down'} | SearXNG ${last.searxng_ok ? 'ready' : 'degraded'}`;
        } else {
            drawTelemetryGrid(width, height, pad);
            if (telemetryGraphMode === 'combined') {
                const hb = recent.map((point) => Number(point.heartbeat_age_sec || 0));
                const ymax = Math.max(5, ...hb, ...requests, ...errors);
                const y = (value) => pad + innerHeight - (Math.max(0, value) / ymax) * innerHeight;
                plotTelemetrySeries(hb, '#22c55e', x, y);
                plotTelemetrySeries(requests, '#38bdf8', x, y);
                plotTelemetrySeries(errors, '#ef4444', x, y);
                footnote = 'Green: heartbeat age | Blue: requests/min | Red: errors/min';
            } else if (telemetryGraphMode === 'error-ratio') {
                const ymax = Math.max(1, ...errorRatio, 5);
                const y = (value) => pad + innerHeight - (Math.max(0, value) / ymax) * innerHeight;
                plotTelemetrySeries(errorRatio, '#f59e0b', x, y);
                footnote = `Amber: error ratio | now ${errorRatio[errorRatio.length - 1].toFixed(2)}% | peak ${Math.max(...errorRatio).toFixed(2)}%`;
            } else if (telemetryGraphMode === 'heartbeat') {
                const heartbeat = recent.map((point) => Number(point.heartbeat_age_sec || 0));
                const heartbeatAvg = telemetryRolling(heartbeat, 5, (values) => values.reduce((sum, value) => sum + value, 0) / Math.max(1, values.length));
                const heartbeatPeak = telemetryRolling(heartbeat, 8, (values) => Math.max(...values));
                const ymax = Math.max(2, ...heartbeat, ...heartbeatAvg, ...heartbeatPeak);
                const y = (value) => pad + innerHeight - (Math.max(0, value) / ymax) * innerHeight;
                plotTelemetrySeries(heartbeatPeak, '#f59e0b', x, y);
                plotTelemetrySeries(heartbeatAvg, '#38bdf8', x, y);
                plotTelemetrySeries(heartbeat, '#22c55e', x, y);
                footnote = `Green: current heartbeat | Blue: rolling average | Amber: peak envelope | health ${status && status.health_score != null ? `${Number(status.health_score)}/100` : 'n/a'}`;
            }
        }

        if (telemetryGraphFootnote) {
            telemetryGraphFootnote.textContent = footnote;
        }
    }
function renderOperatorMacroPrompt(macro, values, note = '') {
    let prompt = String((macro && (macro.prompt_template || macro.prompt)) || '').trim();
    const resolved = values && typeof values === 'object' ? values : {};
    Object.keys(resolved).forEach((name) => {
        const value = String(resolved[name] || '');
        prompt = prompt.split(`{${name}}`).join(value);
    });
    const cleanNote = String(note || '').trim();
    if (cleanNote) {
        prompt = `${prompt}\n\nOperator note: ${cleanNote}`;
    }
    return prompt.trim();
}

function escapeHtml(text) {
    return String(text == null ? '' : text).replace(/[&<>"']/g, (match) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[match]));
}

function formatDeviceCoords(lat, lon) {
    const latitude = Number(lat);
    const longitude = Number(lon);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return 'unknown';
    return `${latitude.toFixed(5)},${longitude.toFixed(5)}`;
}

function formatMetric(value, suffix = '', digits = 1) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return 'n/a';
    return `${numeric.toFixed(digits)}${suffix}`;
}

function formatAgeSeconds(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return 'n/a';
    if (numeric < 60) return `${numeric.toFixed(1)}s`;
    const minutes = Math.floor(numeric / 60);
    const seconds = Math.round(numeric % 60);
    return `${minutes}m ${seconds}s`;
}

function formatCapturedTime(epochSeconds) {
    const numeric = Number(epochSeconds);
    if (!Number.isFinite(numeric) || numeric <= 0) return 'n/a';
    return new Date(numeric * 1000).toLocaleTimeString();
}

function haversineMeters(left, right) {
    if (!left || !right) return 0;
    const lat1 = Number(left.lat);
    const lon1 = Number(left.lon);
    const lat2 = Number(right.lat);
    const lon2 = Number(right.lon);
    if (![lat1, lon1, lat2, lon2].every(Number.isFinite)) return 0;
    const toRad = (value) => value * (Math.PI / 180);
    const earthRadius = 6371000;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
    return earthRadius * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function liveTrackingBrowserSupported() {
    return Boolean(navigator.geolocation && typeof navigator.geolocation.watchPosition === 'function');
}

function normalizeObservedPosition(position) {
    const coords = position && position.coords ? position.coords : null;
    if (!coords) return null;
    const latitude = Number(coords.latitude);
    const longitude = Number(coords.longitude);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return null;
    return {
        lat: latitude,
        lon: longitude,
        accuracy_m: Number.isFinite(Number(coords.accuracy)) ? Number(coords.accuracy) : null,
        altitude_m: Number.isFinite(Number(coords.altitude)) ? Number(coords.altitude) : null,
        speed_mps: Number.isFinite(Number(coords.speed)) ? Number(coords.speed) : null,
        heading_deg: Number.isFinite(Number(coords.heading)) ? Number(coords.heading) : null,
        captured_ts: Number.isFinite(Number(position.timestamp)) ? Number(position.timestamp) / 1000 : Date.now() / 1000,
    };
}

function shouldSyncObservedPosition(observation) {
    if (!observation) return false;
    if (!locationTrackingLastSent) return true;
    const elapsedMs = Math.max(0, (Number(observation.captured_ts) - Number(locationTrackingLastSent.captured_ts)) * 1000);
    const movedMeters = haversineMeters(observation, locationTrackingLastSent);
    return elapsedMs >= LOCATION_SYNC_MIN_INTERVAL_MS || movedMeters >= LOCATION_SYNC_MIN_DISTANCE_M;
}

function setLiveTrackingAutoArmEnabled(enabled) {
    liveTrackingAutoArmEnabled = Boolean(enabled);
    localStorage.setItem(LIVE_TRACKING_AUTO_ARM_KEY, liveTrackingAutoArmEnabled ? 'on' : 'off');
}

function setLiveTrackingButtons() {
    const supported = liveTrackingBrowserSupported();
    if (btnLocationTrackStart) btnLocationTrackStart.disabled = !supported || locationTrackingWatchId !== null;
    if (btnLocationTrackAutoArm) {
        btnLocationTrackAutoArm.disabled = !supported && !liveTrackingAutoArmEnabled;
        btnLocationTrackAutoArm.className = liveTrackingAutoArmEnabled ? 'btn btn-sm btn-operator-primary' : 'btn btn-sm btn-operator-alt';
        btnLocationTrackAutoArm.textContent = liveTrackingAutoArmEnabled ? 'Auto-Arm On' : 'Auto-Arm Off';
        btnLocationTrackAutoArm.setAttribute('aria-pressed', liveTrackingAutoArmEnabled ? 'true' : 'false');
    }
    if (btnLocationTrackStop) btnLocationTrackStop.disabled = locationTrackingWatchId === null;
    if (btnLocationTrackClear) btnLocationTrackClear.disabled = false;
}

function renderLiveTrackingMetaCards(rows) {
    if (!liveTrackingMeta) return;
    if (!Array.isArray(rows) || !rows.length) {
        liveTrackingMeta.innerHTML = [
            '<div class="runtime-card">',
            '<div class="runtime-card-header">',
            '<div class="runtime-card-label">Signal Details</div>',
            '</div>',
            '<div class="runtime-card-details">',
            '<div class="runtime-detail-row"><div class="runtime-detail-value">Pending</div></div>',
            '<div class="runtime-detail-row"><div class="runtime-detail-key">Location signal details pending.</div></div>',
            '</div>',
            '</div>'
        ].join('');
        return;
    }
    liveTrackingMeta.innerHTML = rows.map((row) => [
        '<div class="runtime-card">',
        '<div class="runtime-card-header">',
        `<div class="runtime-card-label">${escapeHtml(row.label || 'Detail')}</div>`,
        '</div>',
        '<div class="runtime-card-details">',
        `<div class="runtime-detail-row"><div class="runtime-detail-value">${escapeHtml(row.value || 'n/a')}</div></div>`,
        row.note ? `<div class="runtime-detail-row"><div class="runtime-detail-key">${escapeHtml(row.note)}</div></div>` : '',
        '</div>',
        '</div>'
    ].join('')).join('');
}

function renderLiveTracking(status) {
    const live = status && status.live_tracking && typeof status.live_tracking === 'object' ? status.live_tracking : {};
    const backendProvider = live && live.backend_provider && typeof live.backend_provider === 'object' ? live.backend_provider : {};
    const available = Boolean(live.available);
    const stale = Boolean(live.stale);
    const browserActive = locationTrackingWatchId !== null;
    const fallbackCoords = locationTrackingLastObserved ? formatDeviceCoords(locationTrackingLastObserved.lat, locationTrackingLastObserved.lon) : 'Awaiting first device fix.';
    const coordsText = available ? String(live.coords_text || formatDeviceCoords(live.lat, live.lon)) : fallbackCoords;
    const badgeTone = available ? (stale ? 'warn' : 'good') : (browserActive ? 'blue' : 'neutral');
    const badgeText = available ? (stale ? 'Stale Fix' : 'Live Fix') : (browserActive ? 'Listening' : 'Idle');
    const accuracyText = live.accuracy_m != null
        ? `${Math.round(Number(live.accuracy_m))}m accuracy`
        : (locationTrackingLastObserved && locationTrackingLastObserved.accuracy_m != null ? `${Math.round(Number(locationTrackingLastObserved.accuracy_m))}m accuracy` : 'Accuracy pending');
    const watchState = browserActive ? 'browser watcher active' : (liveTrackingBrowserSupported() ? 'browser watcher paused' : 'browser geolocation unavailable');
    const backendProviderText = String(backendProvider.message || '').trim() || 'Windows geolocation fallback status unknown.';
    const consentText = liveTrackingAutoArmEnabled
        ? 'Auto-arm is on for this browser. Reloading the console will try to re-enable tracking after status refresh.'
        : 'Auto-arm is off. Tracking starts only when you enable it or explicitly arm it for this browser.';
    const signalLines = [
        available ? `Runtime fix: ${coordsText}` : `Browser fix: ${coordsText}`,
        `Watch state: ${watchState}`,
        `Last hop: ${locationTrackingLastHopMeters > 0 ? `${Math.round(locationTrackingLastHopMeters)}m` : 'no movement recorded yet'}`,
    ];
    if (available) {
        signalLines.push(`Source: ${String(live.source || 'unknown')}`);
    }
    if (locationTrackingLastError) {
        signalLines.push(`Last error: ${locationTrackingLastError}`);
    }

    if (liveTrackingStatusBadge) {
        liveTrackingStatusBadge.className = `status-pill status-pill-${badgeTone}`;
        liveTrackingStatusBadge.textContent = badgeText;
    }
    if (liveTrackingSummary) {
        liveTrackingSummary.textContent = available
            ? `${coordsText} | ${accuracyText}`
            : (browserActive ? `${coordsText} | waiting for runtime sync` : 'Tracking idle. Enable browser geolocation to stream the current device fix.');
    }
    if (liveTrackingSignal) {
        liveTrackingSignal.textContent = signalLines.join('\n');
    }
    if (liveTrackingConsentNote) {
        liveTrackingConsentNote.textContent = consentText;
    }

    renderLiveTrackingMetaCards([
        {
            label: 'Signal Age',
            value: available ? formatAgeSeconds(live.age_sec) : 'n/a',
            note: available ? `captured ${formatCapturedTime(live.captured_ts)}` : 'no runtime fix yet',
        },
        {
            label: 'Accuracy / Speed',
            value: `${accuracyText} | ${live.speed_mps != null ? formatMetric(live.speed_mps, ' m/s', 2) : 'speed n/a'}`,
            note: live.heading_deg != null ? `heading ${formatMetric(live.heading_deg, ' deg', 1)}` : 'heading pending',
        },
        {
            label: 'Source / Permission',
            value: `${available ? String(live.source || 'unknown') : 'browser watch'} | ${live.permission_state || (browserActive ? 'granted' : 'n/a')}`,
            note: stale ? 'runtime snapshot is stale' : watchState,
        },
        {
            label: 'Consent / Fallback',
            value: liveTrackingAutoArmEnabled ? 'auto-arm armed in browser' : 'manual start only',
            note: backendProviderText,
        }
    ]);

    setLiveTrackingButtons();
}

async function syncLiveTrackingObservation(observation) {
    if (!observation || locationTrackingSendInFlight) return;
    locationTrackingSendInFlight = postAction('device_location_update', {
        lat: observation.lat,
        lon: observation.lon,
        accuracy_m: observation.accuracy_m,
        altitude_m: observation.altitude_m,
        speed_mps: observation.speed_mps,
        heading_deg: observation.heading_deg,
        captured_ts: observation.captured_ts,
        source: 'browser_watch',
        permission_state: 'granted'
    });
    try {
        const payload = await locationTrackingSendInFlight;
        locationTrackingLastSent = {...observation};
        if (!latestStatus || typeof latestStatus !== 'object') latestStatus = {};
        latestStatus.live_tracking = payload.live_tracking || {};
        locationTrackingLastError = '';
        renderLiveTracking(latestStatus);
    } catch (error) {
        locationTrackingLastError = String(error && error.message ? error.message : error || 'location sync failed');
        renderLiveTracking(latestStatus);
        setAction('Live tracking sync failed: ' + locationTrackingLastError);
    } finally {
        locationTrackingSendInFlight = null;
    }
}

function handleLiveTrackingSuccess(position) {
    const observation = normalizeObservedPosition(position);
    if (!observation) {
        locationTrackingLastError = 'browser returned invalid coordinates';
        renderLiveTracking(latestStatus);
        return;
    }
    locationTrackingLastHopMeters = locationTrackingLastObserved ? haversineMeters(locationTrackingLastObserved, observation) : 0;
    locationTrackingLastObserved = observation;
    locationTrackingLastError = '';
    renderLiveTracking(latestStatus);
    if (shouldSyncObservedPosition(observation)) {
        syncLiveTrackingObservation(observation);
    }
}

function handleLiveTrackingError(error) {
    const code = Number(error && error.code);
    const message = code === 1
        ? 'permission denied'
        : (code === 2 ? 'position unavailable' : (code === 3 ? 'location request timed out' : String(error && error.message ? error.message : 'geolocation failed')));
    locationTrackingLastError = message;
    renderLiveTracking(latestStatus);
    setAction('Live tracking failed: ' + message);
}

function startLiveTracking(options = {}) {
    const autoArm = Boolean(options && options.autoArm);
    const quiet = Boolean(options && options.quiet);
    if (!liveTrackingBrowserSupported()) {
        if (!quiet) setAction('Browser geolocation is not available in this control session.');
        renderLiveTracking(latestStatus);
        return false;
    }
    if (locationTrackingWatchId !== null) {
        renderLiveTracking(latestStatus);
        return true;
    }
    locationTrackingLastError = '';
    locationTrackingWatchId = navigator.geolocation.watchPosition(handleLiveTrackingSuccess, handleLiveTrackingError, {
        enableHighAccuracy: true,
        maximumAge: 5000,
        timeout: 15000,
    });
    renderLiveTracking(latestStatus);
    if (!quiet) {
        setAction(autoArm
            ? 'Live tracking auto-armed from saved browser consent.'
            : 'Live tracking enabled. Browser geolocation will stream current device fixes into the runtime.');
    }
    return true;
}

function stopLiveTracking() {
    if (locationTrackingWatchId !== null && navigator.geolocation && typeof navigator.geolocation.clearWatch === 'function') {
        navigator.geolocation.clearWatch(locationTrackingWatchId);
    }
    locationTrackingWatchId = null;
    renderLiveTracking(latestStatus);
    setAction('Live tracking paused. The last runtime snapshot remains until cleared or it expires.');
}

async function clearLiveTracking() {
    const payload = await postAction('device_location_clear');
    locationTrackingLastObserved = null;
    locationTrackingLastSent = null;
    locationTrackingLastHopMeters = 0;
    locationTrackingLastError = '';
    if (!latestStatus || typeof latestStatus !== 'object') latestStatus = {};
    latestStatus.live_tracking = payload.live_tracking || {};
    renderLiveTracking(latestStatus);
    setAction('Live tracking runtime snapshot cleared.');
}

function maybeAutoArmLiveTracking() {
    if (liveTrackingAutoArmAttempted || !liveTrackingAutoArmEnabled) {
        return;
    }
    liveTrackingAutoArmAttempted = true;
    startLiveTracking({autoArm: true, quiet: true});
}

function toggleLiveTrackingAutoArm() {
    if (liveTrackingAutoArmEnabled) {
        setLiveTrackingAutoArmEnabled(false);
        renderLiveTracking(latestStatus);
        setAction('Live tracking auto-arm disabled for this browser. Future page loads will stay manual unless you re-enable it.');
        return;
    }
    const confirmed = window.confirm('Allow NYO System Control to auto-arm live tracking each time this browser opens the control console? The browser will still control location permission, and Nova keeps only a short-lived runtime snapshot.');
    if (!confirmed) {
        setAction('Live tracking auto-arm remains off.');
        return;
    }
    setLiveTrackingAutoArmEnabled(true);
    liveTrackingAutoArmAttempted = true;
    const started = startLiveTracking({autoArm: true, quiet: true});
    renderLiveTracking(latestStatus);
    setAction(started
        ? 'Live tracking auto-arm enabled for this browser and tracking started now.'
        : 'Live tracking auto-arm enabled for this browser.');
}

function parsePatchPreviewReport(text) {
    const lines = String(text || '').split(/\r?\n/);
    const out = {
        zip: '',
        status: '',
        patchRevision: '',
        minBaseRevision: '',
        currentRevision: '',
        changed: [],
        added: [],
        skipped: [],
    };
    let section = '';
    for (const line of lines) {
        const raw = String(line || '');
        const trimmed = raw.trim();
        if (!trimmed) {
            section = '';
            continue;
        }
        if (trimmed === 'Changed files:') { section = 'changed'; continue; }
        if (trimmed === 'Added files:') { section = 'added'; continue; }
        if (trimmed === 'Skipped files:') { section = 'skipped'; continue; }
        if (trimmed.startsWith('Diff summary:')) { section = ''; continue; }

        const zipMatch = trimmed.match(/^Zip:\s*(.+)$/i);
        if (zipMatch) { out.zip = zipMatch[1].trim(); continue; }
        const statusMatch = trimmed.match(/^Status:\s*(.+)$/i);
        if (statusMatch) { out.status = statusMatch[1].trim(); continue; }
        const revMatch = trimmed.match(/^Patch revision:\s*(.+)$/i);
        if (revMatch) { out.patchRevision = revMatch[1].trim(); continue; }
        const baseMatch = trimmed.match(/^Min base revision:\s*(.+)$/i);
        if (baseMatch) { out.minBaseRevision = baseMatch[1].trim(); continue; }
        const currentMatch = trimmed.match(/^Current revision:\s*(.+)$/i);
        if (currentMatch) { out.currentRevision = currentMatch[1].trim(); continue; }

        if (section && trimmed.startsWith('- ')) {
            const value = trimmed.slice(2).trim();
            if (value) out[section].push(value);
        }
    }
    return out;
}

function renderPatchPreviewSummary(text, previewName = '') {
    if (!patchPreviewSummary) return;
    const parsed = parsePatchPreviewReport(text);
    const changed = Array.isArray(parsed.changed) ? parsed.changed : [];
    const added = Array.isArray(parsed.added) ? parsed.added : [];
    const skipped = Array.isArray(parsed.skipped) ? parsed.skipped : [];
    if (!String(text || '').trim()) {
        patchPreviewSummary.innerHTML = '<div class="inspector-item"><div class="inspector-key">Preview Summary</div><div class="inspector-value">Load a preview to see what Nova is adding before approving it.</div></div>';
        return;
    }

    const allTouched = [...added, ...changed];
    const impactCounts = new Map();
    allTouched.forEach((item) => {
        const key = classifyPatchFileImpact(item);
        impactCounts.set(key, (impactCounts.get(key) || 0) + 1);
    });
    const topImpacts = [...impactCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([name, count]) => `${count} ${name}`);
    const statusLow = String(parsed.status || '').toLowerCase();
    let approvalMessage = 'This preview is ready for operator decision.';
    if (statusLow.startsWith('eligible')) {
        approvalMessage = 'Nova can apply this after you approve it.';
    } else if (statusLow.startsWith('rejected')) {
        approvalMessage = 'Do not approve yet: governance marked this preview as blocked.';
    }

    const changedPreview = changed.slice(0, 4).map((item) => `<li>${escapeHtml(item)}</li>`).join('');
    const addedPreview = added.slice(0, 4).map((item) => `<li>${escapeHtml(item)}</li>`).join('');

    patchPreviewSummary.innerHTML = [
        '<div class="patch-summary-highlight">',
        '<div class="patch-summary-title">What Nova Is Adding</div>',
        `<div class="patch-summary-body">${escapeHtml(approvalMessage)} ${escapeHtml(topImpacts.length ? 'Main impact areas: ' + topImpacts.join(', ') + '.' : 'No changed or added files were detected.')}</div>`,
        '</div>',
        '<div class="inspector-item">',
        '<div class="inspector-key">Preview</div>',
        `<div class="inspector-value">${escapeHtml(previewName || parsed.zip || 'selected preview')}</div>`,
        '</div>',
        '<div class="inspector-item">',
        '<div class="inspector-key">Approval Gate</div>',
        `<div class="inspector-value">Status=${escapeHtml(parsed.status || 'unknown')} | Patch rev=${escapeHtml(parsed.patchRevision || 'unknown')} | Base=${escapeHtml(parsed.minBaseRevision || 'n/a')} | Current=${escapeHtml(parsed.currentRevision || 'n/a')}</div>`,
        '</div>',
        '<div class="inspector-item">',
        '<div class="inspector-key">Change Counts</div>',
        `<div class="inspector-value">Added=${added.length} | Changed=${changed.length} | Skipped=${skipped.length}</div>`,
        '</div>',
        changedPreview ? `<div class="inspector-item"><div class="inspector-key">Top Changed Files</div><div class="inspector-value"><ul>${changedPreview}</ul></div></div>` : '',
        addedPreview ? `<div class="inspector-item"><div class="inspector-key">Top Added Files</div><div class="inspector-value"><ul>${addedPreview}</ul></div></div>` : '',
    ].join('');
}

function setActiveView(name) {
    navButtons.forEach((button) => {
        const active = (button.getAttribute('data-view-target') || '') === name;
        button.classList.toggle('active', active);
    });
    mainViews.forEach((view) => {
        const visible = (view.getAttribute('data-view') || '') === name;
        view.classList.toggle('d-none', !visible);
    });
    syncTemporalNavLinkActive();
}

function syncTemporalNavLinkActive() {
    if (!temporalNavLink) {
        return;
    }
    const hash = String(window.location.hash || '').trim();
    const operationsVisible = mainViews.some((view) => (view.getAttribute('data-view') || '') === 'operations' && !view.classList.contains('d-none'));
    const operationsShell = document.querySelector('.layer-tab-shell[data-layer-tabs="operations"]');
    const governanceButton = operationsShell ? operationsShell.querySelector('[data-layer-tab="governance"]') : null;
    const governanceActive = Boolean(governanceButton && governanceButton.getAttribute('aria-selected') === 'true');
    const active = hash === '#temporalPolicyControls' && operationsVisible && governanceActive;
    temporalNavLink.classList.toggle('active', active);
    if (active) {
        temporalNavLink.setAttribute('aria-current', 'page');
    } else {
        temporalNavLink.removeAttribute('aria-current');
    }
}

function visibleViewName(name) {
    const target = String(name || '').trim();
    return mainViews.some((view) => (view.getAttribute('data-view') || '') === target) ? target : 'overview';
}

function syncScheduledTreeView(activeView) {
    if (visibleViewName(activeView) === 'scheduled-tree') {
        renderSelectedWorkTreeView();
    }
}

function setCenterTab(name) {
    const target = String(name || '').trim();
    const targetButton = centerTabButtons.find((button) => (button.getAttribute('data-center-tab') || '') === target);
    if (!targetButton) {
        return;
    }
    const centerTabPanelWrap = document.querySelector('.center-tab-panels');
    centerTabButtons.forEach((button) => {
        const active = (button.getAttribute('data-center-tab') || '') === target;
        button.classList.toggle('active', active);
        button.setAttribute('aria-selected', active ? 'true' : 'false');
        button.tabIndex = active ? 0 : -1;
    });
    if (centerTabPanelWrap) {
        centerTabPanelWrap.classList.remove('is-empty');
    }
    centerTabPanels.forEach((panel) => {
        const visible = (panel.getAttribute('data-center-panel') || '') === target;
        panel.classList.toggle('d-none', !visible);
    });
}

function clearCenterTabs() {
    const centerTabPanelWrap = document.querySelector('.center-tab-panels');
    centerTabButtons.forEach((button, index) => {
        button.classList.remove('active');
        button.setAttribute('aria-selected', 'false');
        button.tabIndex = index === 0 ? 0 : -1;
    });
    centerTabPanels.forEach((panel) => {
        panel.classList.add('d-none');
    });
    if (centerTabPanelWrap) {
        centerTabPanelWrap.classList.add('is-empty');
    }
}

function resolveInspectorTabButton(target) {
    if (!inspectorTabBar || !target || typeof target.closest !== 'function') {
        return null;
    }
    const button = target.closest('[data-inspector-tab]');
    if (!button || !inspectorTabBar.contains(button)) {
        return null;
    }
    return button;
}

function setInspectorTab(name) {
    const target = String(name || '').trim();
    const targetButton = inspectorTabButtons.find((button) => (button.getAttribute('data-inspector-tab') || '') === target);
    const inspectorTabShell = document.querySelector('.inspector-tab-shell');
    if (!targetButton) {
        return;
    }
    inspectorTabButtons.forEach((button) => {
        const active = (button.getAttribute('data-inspector-tab') || '') === target;
        button.classList.toggle('active', active);
        button.setAttribute('aria-selected', active ? 'true' : 'false');
        button.tabIndex = active ? 0 : -1;
    });
    inspectorTabPanels.forEach((panel) => {
        panel.hidden = (panel.getAttribute('data-inspector-panel') || '') !== target;
    });
    if (inspectorTabShell) {
        inspectorTabShell.setAttribute('data-active-inspector', target);
    }
}

function focusInspectorTabByOffset(currentButton, offset) {
    if (!currentButton || !inspectorTabButtons.length) {
        return;
    }
    const currentIndex = inspectorTabButtons.indexOf(currentButton);
    if (currentIndex < 0) {
        return;
    }
    const nextIndex = (currentIndex + offset + inspectorTabButtons.length) % inspectorTabButtons.length;
    const nextButton = inspectorTabButtons[nextIndex];
    if (!nextButton) {
        return;
    }
    setInspectorTab(nextButton.getAttribute('data-inspector-tab') || 'planner');
    nextButton.focus();
}

function resolveCenterTabButton(target) {
    if (!centerTabBar || !target || typeof target.closest !== 'function') {
        return null;
    }
    const button = target.closest('[data-center-tab]');
    if (!button || !centerTabBar.contains(button)) {
        return null;
    }
    return button;
}

function focusCenterTabByOffset(currentButton, offset) {
    if (!currentButton || !centerTabButtons.length) {
        return;
    }
    const currentIndex = centerTabButtons.indexOf(currentButton);
    if (currentIndex < 0) {
        return;
    }
    const nextIndex = (currentIndex + offset + centerTabButtons.length) % centerTabButtons.length;
    const nextButton = centerTabButtons[nextIndex];
    if (!nextButton) {
        return;
    }
    setCenterTab(nextButton.getAttribute('data-center-tab') || 'system-matrix');
    nextButton.focus();
}

function getLayerTabContext(shell) {
    if (!shell) {
        return null;
    }
    return {
        shell,
        bar: shell.querySelector('.layer-tab-bar'),
        buttons: Array.from(shell.querySelectorAll('[data-layer-tab]')),
        panels: Array.from(shell.querySelectorAll('[data-layer-panel]')),
    };
}

function resolveLayerTabButton(shell, target) {
    const context = getLayerTabContext(shell);
    if (!context || !context.bar || !target || typeof target.closest !== 'function') {
        return null;
    }
    const button = target.closest('[data-layer-tab]');
    if (!button || !context.bar.contains(button)) {
        return null;
    }
    return button;
}

function setLayerTab(shell, name) {
    const context = getLayerTabContext(shell);
    const target = String(name || '').trim();
    if (!context || !context.buttons.length) {
        return;
    }
    const targetButton = context.buttons.find((button) => (button.getAttribute('data-layer-tab') || '') === target);
    if (!targetButton) {
        return;
    }
    context.buttons.forEach((button) => {
        const active = (button.getAttribute('data-layer-tab') || '') === target;
        button.classList.toggle('active', active);
        button.setAttribute('aria-selected', active ? 'true' : 'false');
        button.tabIndex = active ? 0 : -1;
    });
    context.panels.forEach((panel) => {
        panel.hidden = (panel.getAttribute('data-layer-panel') || '') !== target;
    });
    syncTemporalNavLinkActive();
}

function focusLayerTabByOffset(shell, currentButton, offset) {
    const context = getLayerTabContext(shell);
    if (!context || !currentButton || !context.buttons.length) {
        return;
    }
    const currentIndex = context.buttons.indexOf(currentButton);
    if (currentIndex < 0) {
        return;
    }
    const nextIndex = (currentIndex + offset + context.buttons.length) % context.buttons.length;
    const nextButton = context.buttons[nextIndex];
    if (!nextButton) {
        return;
    }
    setLayerTab(shell, nextButton.getAttribute('data-layer-tab') || '');
    nextButton.focus();
}

if (keyInput) {
    keyInput.value = localStorage.getItem('nova_control_key') || '';
    keyInput.addEventListener('change', () => {
        localStorage.setItem('nova_control_key', keyInput.value.trim());
    });
}

if (operatorSessionIdInput) {
    operatorSessionIdInput.value = localStorage.getItem('nova_operator_session_id') || '';
    operatorSessionIdInput.addEventListener('change', () => {
        localStorage.setItem('nova_operator_session_id', operatorSessionIdInput.value.trim());
    });
}

function controlHeaders() {
    const key = keyInput ? keyInput.value.trim() : '';
    const headers = {'Content-Type': 'application/json'};
    if (key) headers['X-Nova-Control-Key'] = key;
    return headers;
}

function setFeedback(text, level = 'muted') {
    if (!feedbackBar) return;
    feedbackBar.className = 'system-note-value system-note-' + (['good', 'warn', 'danger', 'info', 'muted'].includes(level) ? level : 'muted');
    feedbackBar.textContent = text;
}

function setAction(text) {
    const safeText = String(text == null ? '' : text).trim() || 'Action complete.';
    if (actionBox) actionBox.textContent = safeText;
    if (actionBoxClone) actionBoxClone.textContent = safeText;
    const firstLine = safeText.split('\n')[0].trim() || 'Action complete.';
    setFeedback(firstLine, /failed|error|denied|forbidden/i.test(firstLine) ? 'danger' : 'good');
}

function focusOperatorSession(sessionId) {
    const sid = String(sessionId || '').trim();
    if (!sid) return;
    if (operatorSessionIdInput) operatorSessionIdInput.value = sid;
    localStorage.setItem('nova_operator_session_id', sid);
    if (sessionFilterSelect && String(sessionFilterSelect.value || 'all') === 'non-operator' && sid.startsWith('operator-')) {
        sessionFilterSelect.value = 'operator';
        renderSessions();
    }
    if (sessionSelect && sessionsCache.some((session) => session.session_id === sid)) {
        sessionSelect.value = sid;
        renderSessionPreview();
    }
}

function renderOperatorReply(payload) {
    if (!operatorPromptReply) return;
    if (!payload) {
        operatorPromptReply.textContent = 'Operator channel idle.';
        return;
    }
    const session = payload.session || {};
    operatorPromptReply.textContent = [
        `Session: ${payload.session_id || session.session_id || 'n/a'}`,
        `Owner: ${payload.user_id || session.owner || 'operator'}`,
        `Turns: ${session.turn_count != null ? session.turn_count : 'n/a'}`,
        '',
        'Reply:',
        payload.reply || payload.message || 'No reply returned.',
    ].join('\n');

    if (payload.reply) {
        speakOperatorReply(payload.reply);
    }
}

function selectedOperatorOutboxEvent() {
    const selectedId = operatorOutboxSelect ? String(operatorOutboxSelect.value || '').trim() : '';
    return operatorOutboxEvents.find((event) => String(event && event.id || '') === selectedId) || null;
}

function operatorOutboxEventLabel(event) {
    const status = String(event && event.status ? event.status : 'new').trim();
    const title = String(event && event.title ? event.title : 'operator notice').trim();
    const eventId = String(event && event.id ? event.id : '').trim();
    const shortId = eventId.length > 18 ? eventId.slice(-18) : eventId;
    return `${status} | ${title}${shortId ? ` | ${shortId}` : ''}`;
}

function operatorOutboxTargetLines(event) {
    const payload = event && event.payload && typeof event.payload === 'object' ? event.payload : {};
    const task = payload.task && typeof payload.task === 'object' ? payload.task : {};
    const nextStep = payload.next_step && typeof payload.next_step === 'object' ? payload.next_step : {};
    return [
        `Tree: ${payload.tree_title || payload.tree_id || 'n/a'}`,
        `Branch: ${payload.branch_title || nextStep.branch_title || payload.branch_id || nextStep.branch_id || 'n/a'}`,
        `Task: ${payload.task_title || task.title || nextStep.task_title || payload.task_id || task.task_id || nextStep.task_id || 'n/a'}`,
        `Request: ${payload.request_kind || 'n/a'}`,
        `Blocked reason: ${payload.blocked_reason || 'n/a'}`,
    ];
}

function renderOperatorOutbox(status) {
    const summary = status && status.operator_outbox && typeof status.operator_outbox === 'object'
        ? status.operator_outbox
        : {};
    const allEvents = Array.isArray(summary.events)
        ? summary.events.filter((event) => event && typeof event === 'object')
        : [];
    const serverOpenEvents = Array.isArray(summary.open_events)
        ? summary.open_events.filter((event) => event && typeof event === 'object')
        : [];
    const openEvents = (serverOpenEvents.length ? serverOpenEvents : allEvents)
        .filter((event) => !['resolved', 'dismissed', 'stale'].includes(String(event.status || '').trim().toLowerCase()));
    const selectable = openEvents.length ? openEvents : (serverOpenEvents.length ? serverOpenEvents : allEvents);
    const previous = operatorOutboxSelect ? String(operatorOutboxSelect.value || '').trim() : '';
    operatorOutboxEvents = selectable;

    const openCount = Number(summary.open_count || 0);
    const totalCount = Number(summary.total_count || allEvents.length || 0);
    if (operatorOutboxBadge) {
        operatorOutboxBadge.className = openCount > 0 ? 'status-pill status-pill-warn' : 'status-pill status-pill-good';
        operatorOutboxBadge.textContent = `${Number.isFinite(openCount) ? openCount : 0} open / ${Number.isFinite(totalCount) ? totalCount : 0} total`;
    }

    if (operatorOutboxSelect) {
        operatorOutboxSelect.innerHTML = '';
        if (!selectable.length) {
            const option = document.createElement('option');
            option.value = '';
            option.textContent = '(operator outbox clear)';
            operatorOutboxSelect.appendChild(option);
        } else {
            selectable.forEach((event) => {
                const option = document.createElement('option');
                option.value = String(event.id || '');
                option.textContent = operatorOutboxEventLabel(event);
                operatorOutboxSelect.appendChild(option);
            });
            const latestOpenId = String(status && status.operator_outbox_latest_open_id ? status.operator_outbox_latest_open_id : '').trim();
            const nextId = previous && selectable.some((event) => String(event.id || '') === previous)
                ? previous
                : (latestOpenId && selectable.some((event) => String(event.id || '') === latestOpenId) ? latestOpenId : String(selectable[selectable.length - 1].id || ''));
            operatorOutboxSelect.value = nextId;
        }
    }

    if (!operatorOutboxBox) return;
    const selected = selectedOperatorOutboxEvent();
    if (!selected) {
        operatorOutboxBox.textContent = 'Operator outbox clear.';
        return;
    }
    const responses = Array.isArray(selected.responses) ? selected.responses : [];
    const latestResponse = responses.length ? responses[responses.length - 1] : null;
    const lines = [
        `ID: ${selected.id || 'n/a'}`,
        `Status: ${selected.status || 'new'}`,
        `Source: ${selected.source || 'n/a'} | Severity: ${selected.severity || 'n/a'}`,
        `Updated: ${selected.updated_ts || selected.ts || 'n/a'}`,
        '',
        `Title: ${selected.title || 'n/a'}`,
        String(selected.message || '').trim() || 'No message recorded.',
        '',
        ...operatorOutboxTargetLines(selected),
        '',
        `Responses: ${responses.length}`,
    ];
    if (latestResponse) {
        lines.push(
            `Latest response: ${latestResponse.ts || 'n/a'} | ${latestResponse.responder || 'operator'} | ${latestResponse.resolution || 'evidence_only'}`,
            String(latestResponse.message || '').trim() || 'No response text recorded.'
        );
    }
    operatorOutboxBox.textContent = lines.join('\n');
}

async function setOperatorOutboxStatus(statusText) {
    const event = selectedOperatorOutboxEvent();
    if (!event) {
        setAction('Select an operator outbox notice first.');
        return;
    }
    const payload = await postAction('operator_outbox_status', {
        event_id: String(event.id || ''),
        status: statusText,
    });
    setAction(payload.message || `operator_outbox_status ${statusText}`);
    await refresh();
}

async function respondOperatorOutbox(forcedResolution = '') {
    const event = selectedOperatorOutboxEvent();
    if (!event) {
        setAction('Select an operator outbox notice first.');
        return;
    }
    const resolution = String(forcedResolution || (operatorOutboxResolution ? operatorOutboxResolution.value : '') || 'evidence_only').trim();
    let message = operatorOutboxResponse ? operatorOutboxResponse.value.trim() : '';
    if (!message && resolution === 'dismissed') message = 'Dismissed by operator.';
    if (!message) {
        setAction('Enter an operator response first.');
        return;
    }
    const payload = await postAction('operator_outbox_respond', {
        event_id: String(event.id || ''),
        message,
        resolution,
        responder: 'operator',
    });
    if (operatorOutboxResponse) operatorOutboxResponse.value = '';
    const workTree = payload.work_tree && typeof payload.work_tree === 'object' ? payload.work_tree : {};
    const evidenceId = String(workTree.evidence_id || '').trim();
    setAction(`${payload.message || 'operator_outbox_response_ok'}${evidenceId ? `\nEvidence: ${evidenceId}` : ''}`);
    await refresh();
}

function syncOperatorAudioButton() {
    if (!btnOperatorToggleAudio) return;
    setActionButtonLabel(btnOperatorToggleAudio, operatorVoiceOutputEnabled ? 'Voice On' : 'Voice Off');
    btnOperatorToggleAudio.classList.toggle('btn-operator-primary', operatorVoiceOutputEnabled);
    btnOperatorToggleAudio.classList.toggle('btn-operator-alt', !operatorVoiceOutputEnabled);
}

function syncOperatorMicButton() {
    if (!btnOperatorMic) return;
    if (!OperatorSpeechRecognitionCtor) {
        setActionButtonLabel(btnOperatorMic, 'Mic Unavailable');
        btnOperatorMic.disabled = true;
        return;
    }
    btnOperatorMic.disabled = false;
    setActionButtonLabel(btnOperatorMic, operatorRecognitionActive ? 'Listening...' : 'Mic Ready');
    btnOperatorMic.classList.toggle('btn-operator-primary', operatorRecognitionActive);
    btnOperatorMic.classList.toggle('btn-operator-alt', !operatorRecognitionActive);
}

function inferButtonIcon(button, labelText) {
    const id = String(button && button.id || '').toLowerCase();
    const label = String(labelText || '').toLowerCase();
    const haystack = `${id} ${label}`;

    if (haystack.includes('refresh')) return 'bi-arrow-clockwise';
    if (haystack.includes('show')) return 'bi-eye';
    if (haystack.includes('approve')) return 'bi-check2-circle';
    if (haystack.includes('reject')) return 'bi-x-circle';
    if (haystack.includes('delete') || haystack.includes('remove')) return 'bi-trash3';
    if (haystack.includes('logout')) return 'bi-box-arrow-right';
    if (haystack.includes('start')) return 'bi-play-circle';
    if (haystack.includes('stop')) return 'bi-stop-circle';
    if (haystack.includes('restart')) return 'bi-arrow-clockwise';
    if (haystack.includes('status')) return 'bi-activity';
    if (haystack.includes('allow')) return 'bi-plus-circle';
    if (haystack.includes('save') || haystack.includes('upsert')) return 'bi-floppy';
    if (haystack.includes('load')) return 'bi-folder2-open';
    if (haystack.includes('run')) return 'bi-play-circle';
    if (haystack.includes('inspect')) return 'bi-search';
    if (haystack.includes('copy')) return 'bi-copy';
    if (haystack.includes('open')) return 'bi-box-arrow-up-right';
    if (haystack.includes('send')) return 'bi-send';
    if (haystack.includes('export')) return 'bi-download';
    if (haystack.includes('tail')) return 'bi-terminal';
    if (haystack.includes('audit')) return 'bi-clipboard-data';
    if (haystack.includes('mode') || haystack.includes('scope') || haystack.includes('provider')) return 'bi-sliders2';
    if (haystack.includes('toggle')) return 'bi-toggles2';
    if (haystack.includes('voice')) return 'bi-volume-up';
    if (haystack.includes('mic') || haystack.includes('listening')) return 'bi-mic';
    if (haystack.includes('new session')) return 'bi-plus-square';
    if (haystack.includes('session')) return 'bi-chat-square-text';
    if (haystack.includes('command')) return 'bi-terminal';
    return 'bi-dot';
}

function setActionButtonLabel(button, labelText) {
    if (!button) return;
    const label = String(labelText || '').trim();
    button.dataset.label = label;
    const iconClass = button.dataset.iconClass || inferButtonIcon(button, label);
    button.dataset.iconClass = iconClass;
    button.classList.add('control-action-button');
    button.innerHTML = [
        `<i class="bi ${escapeHtml(iconClass)} control-action-icon" aria-hidden="true"></i>`,
        `<span class="control-action-label">${escapeHtml(label)}</span>`
    ].join('');
}

function decorateActionButtons(root = document) {
    const buttons = root.querySelectorAll('button.btn.btn-sm, button.subconscious-action-button, button.artifact-inspect-button, button.artifact-copy-button');
    buttons.forEach((button) => {
        if (button.classList.contains('console-toggle-button') || button.classList.contains('user-hub-icon-button')) return;
        if (button.classList.contains('subconscious-action-button')) {
            button.classList.add('control-action-button');
            return;
        }
        const existingLabel = String(button.dataset.label || button.textContent || '').trim();
        setActionButtonLabel(button, existingLabel);
    });
}

function speakOperatorReply(text) {
    if (!operatorVoiceOutputEnabled || !window.speechSynthesis) return;
    const spoken = String(text || '').trim();
    if (!spoken) return;
    try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(spoken);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        window.speechSynthesis.speak(utterance);
    } catch (_) {
        // Keep operator controls usable if browser speech APIs fail.
    }
}

function initOperatorSpeechRecognition() {
    if (!OperatorSpeechRecognitionCtor || operatorRecognition) return;
    operatorRecognition = new OperatorSpeechRecognitionCtor();
    operatorRecognition.lang = 'en-US';
    operatorRecognition.interimResults = false;
    operatorRecognition.maxAlternatives = 1;
    operatorRecognition.onstart = () => {
        operatorRecognitionActive = true;
        syncOperatorMicButton();
    };
    operatorRecognition.onend = () => {
        operatorRecognitionActive = false;
        syncOperatorMicButton();
    };
    operatorRecognition.onerror = () => {
        operatorRecognitionActive = false;
        syncOperatorMicButton();
    };
    operatorRecognition.onresult = async (event) => {
        const transcript = String(event.results?.[0]?.[0]?.transcript || '').trim();
        if (!transcript || !operatorPromptInput) return;
        operatorPromptInput.value = transcript;
        await sendOperatorPrompt();
    };
}

async function sendOperatorPrompt() {
    if (operatorPromptBusy) return;
    const macroId = operatorMacroSelect ? operatorMacroSelect.value.trim() : '';
    let message = operatorPromptInput ? operatorPromptInput.value.trim() : '';
    if (!message && !macroId) {
        setAction('Enter an operator prompt or select a macro first.');
        return;
    }
    operatorPromptBusy = true;
    try {
        let macroValues = {};
        if (macroId) {
            const macro = selectedOperatorMacro();
            const resolved = await resolveOperatorMacroValues(macro);
            if (resolved === null) return;
            macroValues = resolved;
        }
        const payload = await postAction('operator_prompt', {
            session_id: operatorSessionIdInput ? operatorSessionIdInput.value.trim() : '',
            source: 'manual',
            macro: macroId,
            macro_values: macroValues,
            message,
        });
        sessionsCache = Array.isArray(payload.sessions) ? payload.sessions : sessionsCache;
        renderSessions();
        focusOperatorSession(payload.session_id || '');
        renderOperatorReply(payload);
        if (operatorPromptInput) operatorPromptInput.value = '';
        setAction(payload.reply || payload.message || 'Operator prompt completed.');
    } finally {
        operatorPromptBusy = false;
    }
}

async function runNextGeneratedQueueItem() {
    const payload = await postAction('generated_queue_run_next', {});
    testRunsCache = Array.isArray(payload.reports) ? payload.reports : testRunsCache;
    testSessionDefinitions = Array.isArray(payload.definitions) ? payload.definitions : testSessionDefinitions;
    renderTestRuns();
    renderTestSessionDefinitions();
    if (payload.latest_report && testRunSelect && payload.latest_report.run_id) {
        testRunSelect.value = payload.latest_report.run_id;
        renderTestRunPreview();
    }
    const selected = payload.selected && payload.selected.file ? payload.selected.file : 'none';
    const latest = payload.latest_report && payload.latest_report.run_id ? payload.latest_report.run_id : 'no report';
    setAction(`${payload.message || 'generated_queue_run_next completed'}\nSelected: ${selected}\nLatest report: ${latest}`);
    await refresh();
}

async function investigateNextGeneratedQueueItem() {
    const payload = await postAction('generated_queue_investigate', {
        session_id: operatorSessionIdInput ? operatorSessionIdInput.value.trim() : '',
        user_id: 'operator',
    });
    sessionsCache = Array.isArray(payload.sessions) ? payload.sessions : sessionsCache;
    renderSessions();
    focusOperatorSession(payload.session_id || '');
    renderOperatorReply(payload);
    const selected = payload.selected && payload.selected.file ? payload.selected.file : 'none';
    setAction(`${payload.message || 'generated_queue_investigate completed'}\nSelected: ${selected}\nOperator session: ${payload.session_id || 'n/a'}`);
}

async function startAutonomyMaintenanceWorker() {
    const payload = await postAction('autonomy_maintenance_start', {});
    const runtimeWorker = payload.autonomy_maintenance && payload.autonomy_maintenance.runtime_worker ? payload.autonomy_maintenance.runtime_worker : {};
    const status = runtimeWorker.last_cycle_status || 'running';
    await refresh();
    setAction(`${payload.message || 'autonomy maintenance worker started'}\nWorker status: ${status}`);
}

async function stopAutonomyMaintenanceWorker() {
    const payload = await postAction('autonomy_maintenance_stop', {});
    const runtimeWorker = payload.autonomy_maintenance && payload.autonomy_maintenance.runtime_worker ? payload.autonomy_maintenance.runtime_worker : {};
    const status = runtimeWorker.last_cycle_status || 'stopped';
    await refresh();
    setAction(`${payload.message || 'autonomy maintenance worker stopped'}\nWorker status: ${status}`);
}

function formatStorageBytes(value) {
    const bytes = Number(value != null ? value : 0);
    if (!Number.isFinite(bytes) || bytes <= 0) return '0 MB';
    const mb = bytes / (1024 * 1024);
    if (mb >= 1024) {
        const gb = mb / 1024;
        return `${gb.toFixed(gb >= 10 ? 1 : 2)} GB`;
    }
    return `${mb.toFixed(mb >= 10 ? 1 : 2)} MB`;
}

function renderMetricGrid(status) {
    if (!statusKv) return;
    const standardKeys = [
        'server_time', 'ollama_api_up', 'chat_model', 'memory_enabled', 'memory_scope', 'web_enabled',
        'search_provider', 'allow_domains_count', 'active_http_sessions', 'health_score',
        'self_check_pass_ratio', 'tool_events_total', 'memory_health_status', 'memory_db_total', 'memory_scoped_total',
        'memory_events_total', 'memory_events_log_status', 'action_ledger_total',
        'last_planner_decision', 'last_route_summary', 'process_counting_mode', 'heartbeat_age_sec',
    ];
    const subconsciousRow = [
        'subconscious_family_count', 'subconscious_training_priority_count', 'subconscious_generated_definition_count'
    ];
    const storageRows = [
        ['storage_watch_summary', 'storage_watch_total', 'release_validation_extracts'],
        ['release_package_stages', 'release_package_zips', 'snapshot_storage'],
    ];
    const displayLabels = {
        memory_health_status: 'Memory Health',
        memory_db_total: 'Memory DB Rows',
        memory_scoped_total: 'Memory Scope Rows',
        memory_events_log_status: 'Memory Event Log',
        subconscious_family_count: 'Families',
        subconscious_training_priority_count: 'Priorities',
        subconscious_generated_definition_count: 'Definitions',
        storage_watch_summary: 'Storage Watch',
        storage_watch_total: 'Watched Total',
        release_validation_extracts: 'Release Extracts',
        release_package_stages: 'Release Stages',
        release_package_zips: 'Release Zips',
        snapshot_storage: 'Snapshots',
    };
    const storageValue = (key) => {
        if (!status) return '';
        if (key === 'storage_watch_summary') {
            const state = String(status.storage_watch_status || 'unknown');
            const note = String(status.storage_watch_note || 'no note');
            return `${state} | ${note}`;
        }
        if (key === 'storage_watch_total') {
            return formatStorageBytes(status.storage_watch_total_bytes);
        }
        if (key === 'release_validation_extracts') {
            return `${status.release_validation_extract_count || 0} | ${formatStorageBytes(status.release_validation_extract_bytes)}`;
        }
        if (key === 'release_package_stages') {
            return `${status.release_stage_count || 0} | ${formatStorageBytes(status.release_stage_bytes)}`;
        }
        if (key === 'release_package_zips') {
            return `${status.release_zip_count || 0} | ${formatStorageBytes(status.release_zip_bytes)}`;
        }
        if (key === 'snapshot_storage') {
            return `patch ${status.patch_snapshot_count || 0} | kidney ${status.kidney_snapshot_count || 0}`;
        }
        return status[key] != null ? status[key] : '';
    };
    const matrixCell = (key) => [
        '<td class="system-matrix-cell">',
        '<table class="system-matrix-entry" aria-hidden="true">',
        '<tbody>',
        '<tr>',
        `<th scope="row" class="system-matrix-key">${escapeHtml(displayLabels[key] || key)}</th>`,
        '</tr>',
        '<tr>',
        `<td class="system-matrix-value">${escapeHtml(storageValue(key))}</td>`,
        '</tr>',
        '</tbody>',
        '</table>',
        '</td>'
    ].join('');
    const columnCount = 3;
    const rows = [];

    for (let index = 0; index < standardKeys.length; index += columnCount) {
        rows.push(standardKeys.slice(index, index + columnCount));
    }

    statusKv.innerHTML = [
        '<tbody>',
        rows.map((row) => [
            '<tr class="system-matrix-row">',
            row.map((key) => matrixCell(key)).join(''),
            '</tr>'
        ].join('')).join(''),
        '<tr class="system-matrix-section-row">',
        '<td class="system-matrix-section-cell" colspan="3">STORAGE WATCH</td>',
        '</tr>',
        storageRows.map((row) => [
            '<tr class="system-matrix-row">',
            row.map((key) => matrixCell(key)).join(''),
            '</tr>'
        ].join('')).join(''),
        '<tr class="system-matrix-section-row">',
        '<td class="system-matrix-section-cell" colspan="3">SUBCONSCIOUS</td>',
        '</tr>',
        '<tr class="system-matrix-row system-matrix-row-subconscious">',
        subconsciousRow.map((key) => matrixCell(key)).join(''),
        '</tr>',
        '</tbody>'
    ].join('');
}

function renderSubconscious(status) {
    const summary = status && status.subconscious_summary ? status.subconscious_summary : {};
    const liveSummary = status && status.subconscious_live_summary ? status.subconscious_live_summary : {};
    const topPriorities = Array.isArray(status && status.subconscious_top_priorities) ? status.subconscious_top_priorities : [];
    const workQueue = status && status.generated_work_queue ? status.generated_work_queue : {};
    const maintenance = status && status.autonomy_maintenance ? status.autonomy_maintenance : {};
    const runtimeWorker = maintenance && maintenance.runtime_worker ? maintenance.runtime_worker : {};
    const maintenanceSchedulerStatus = status && status.maintenance_scheduler_status ? status.maintenance_scheduler_status : '';
    const maintenanceSchedulerMode = status && status.maintenance_scheduler_mode ? status.maintenance_scheduler_mode : '';
    const lastQueueRun = maintenance && maintenance.last_generated_queue_run ? maintenance.last_generated_queue_run : {};
    const advisor = status && status.autonomy_orchestrator
        ? status.autonomy_orchestrator
        : (maintenance && maintenance.last_autonomy_orchestrator ? maintenance.last_autonomy_orchestrator : {});
    const advisorSummary = status && status.autonomy_orchestrator_summary
        ? status.autonomy_orchestrator_summary
        : (maintenance && maintenance.autonomy_orchestrator_summary ? maintenance.autonomy_orchestrator_summary : {});
    const advisorAction = advisor && advisor.action ? advisor.action : {};
    const queueItems = Array.isArray(workQueue && workQueue.items) ? workQueue.items : [];
    const liveSessions = Array.isArray(liveSummary && liveSummary.sessions) ? liveSummary.sessions : [];
    const pressureConfig = liveSummary && liveSummary.pressure_config ? liveSummary.pressure_config : {};
    const weakSignalThresholds = pressureConfig && pressureConfig.weak_signal_thresholds ? pressureConfig.weak_signal_thresholds : {};
    const thresholdText = Object.entries(weakSignalThresholds).map(([signal, threshold]) => `${signal}:${threshold}`).join(' | ');
    const workerStatus = maintenanceSchedulerStatus || (runtimeWorker && runtimeWorker.last_cycle_status ? runtimeWorker.last_cycle_status : 'inactive');
    const workerMode = maintenanceSchedulerMode || (runtimeWorker && runtimeWorker.active ? 'worker_loop' : 'inactive');
    const workerInterval = runtimeWorker && runtimeWorker.interval_sec != null ? `${runtimeWorker.interval_sec}s` : 'n/a';
    const workerCycles = runtimeWorker && runtimeWorker.cycle_count != null ? runtimeWorker.cycle_count : 0;
    const lastQueueRunText = lastQueueRun && lastQueueRun.selected_file
        ? `${lastQueueRun.status || 'n/a'} | ${lastQueueRun.selected_file}`
        : (lastQueueRun && lastQueueRun.status ? `${lastQueueRun.status} | none selected` : 'n/a');
    const lastQueueReport = lastQueueRun && lastQueueRun.latest_report_status ? lastQueueRun.latest_report_status : 'n/a';
    const advisorDecision = status && status.autonomy_orchestrator_display_decision
        ? status.autonomy_orchestrator_display_decision
        : (advisor && advisor.decision ? advisor.decision : 'n/a');
    const advisorActionText = status && status.autonomy_orchestrator_display_action
        ? status.autonomy_orchestrator_display_action
        : (advisorAction && advisorAction.act ? advisorAction.act : 'none');
    const advisorCurrentNote = status && status.autonomy_orchestrator_current_note
        ? status.autonomy_orchestrator_current_note
        : '';
    const advisorLedger = advisor && advisor.ledger_status ? advisor.ledger_status : 'n/a';
    const advisorChurn = advisorSummary && advisorSummary.count
        ? `${advisorSummary.recommendation_changes || 0}/${Math.max(0, Number(advisorSummary.count || 0) - 1)}`
        : 'n/a';
    const advisorStable = advisorSummary && advisorSummary.count ? (advisorSummary.stable_recommendation ? 'stable' : 'churn') : 'n/a';
    const advisorWeakRefusal = advisorSummary && advisorSummary.weak_posture_count
        ? `${Math.round(Number(advisorSummary.weak_posture_refusal_rate || 0) * 100)}%`
        : 'n/a';

    renderMatrixTable(subconsciousStatusBox, [
        {label: 'Latest run', value: summary.generated_at || 'not available'},
        {label: 'Label', value: summary.label || 'n/a'},
        {label: 'Families', value: summary.family_count != null ? summary.family_count : 0},
        {label: 'Variations', value: summary.variation_count != null ? summary.variation_count : 0},
        {label: 'Priorities', value: summary.training_priority_count != null ? summary.training_priority_count : 0},
        {label: 'Definitions', value: summary.generated_definition_count != null ? summary.generated_definition_count : 0},
        {label: 'Maintenance status', value: workerStatus},
        {label: 'Maintenance mode', value: workerMode},
        {label: 'Worker interval', value: workerInterval},
        {label: 'Worker cycles', value: workerCycles},
        {label: 'Live tracked', value: liveSummary.tracked_session_count != null ? liveSummary.tracked_session_count : 0},
        {label: 'Live replans', value: liveSummary.replan_session_count != null ? liveSummary.replan_session_count : 0},
        {label: 'Weak thresholds', value: thresholdText || 'n/a'},
        {label: 'Open queue', value: workQueue.open_count != null ? workQueue.open_count : 0},
        {label: 'Next item', value: workQueue.next_item && workQueue.next_item.file ? workQueue.next_item.file : 'none'},
        {label: 'Last queue run', value: lastQueueRunText},
        {label: 'Last queue report', value: lastQueueReport},
        {label: 'Advisor decision', value: advisorDecision},
        {label: 'Advisor action', value: advisorActionText},
        {label: 'Advisor current', value: advisorCurrentNote || 'current evidence matches last recommendation'},
        {label: 'Advisor ledger', value: advisorLedger},
        {label: 'Advisor churn', value: advisorChurn},
        {label: 'Advisor stability', value: advisorStable},
        {label: 'Weak refusals', value: advisorWeakRefusal},
        {label: 'Report path', value: summary.latest_report_path || 'n/a'},
    ], 3);

    renderInspectorList(subconsciousLiveList, liveSessions.map((item) => {
        const reasons = Array.isArray(item && item.replan_reasons) ? item.replan_reasons : [];
        const reasonText = reasons.length
            ? reasons.map((reason) => {
                const signal = reason && reason.signal ? reason.signal : 'signal';
                if (reason && reason.kind === 'weak_signal_threshold') {
                    return `${signal} ${reason.window_count}/${reason.threshold}`;
                }
                return signal;
            }).join(' | ')
            : ((Array.isArray(item && item.active_recent_signals) ? item.active_recent_signals : []).join(' | ') || 'No active reasons');
        const subject = item && item.active_subject ? ` | ${item.active_subject}` : '';
        const lastUser = item && item.last_user ? ` | ${item.last_user}` : '';
        const owner = item && item.owner ? ` [${item.owner}]` : '';
        return {
            label: `${item && item.session_id ? item.session_id : 'session'}${owner}${item && item.replan_requested ? ' [replan]' : ''}`,
            value: `${reasonText}${subject}${lastUser}`,
        };
    }));

    renderInspectorList(subconsciousPriorityList, topPriorities.map((item) => {
        const badge = subconsciousSeamBadgeMeta(item.seam);
        return {
            label: `${item.seam_label || formatSeamLabel(item.seam) || 'unknown seam'} | ${item.signal || 'signal'} [${item.urgency || 'n/a'}]`,
            badgeText: badge ? badge.text : '',
            badgeClass: badge ? badge.className : '',
            value: `${item.suggested_test_name || 'no_test_name'} (robustness=${item.robustness != null ? item.robustness : 'n/a'})`
        };
    }));

    renderInspectorList(generatedQueueBox, queueItems.map((item) => {
        const leadPriority = orderedGeneratedPriorities(item)[0] || {};
        const badge = subconsciousSeamBadgeMeta(leadPriority.seam || item.family_id || '');
        return {
            label: `${item.file || 'generated session'} [${item.latest_status || 'never_run'}]`,
            badgeText: badge ? badge.text : '',
            badgeClass: badge ? badge.className : '',
            value: `${item.opportunity_reason || 'n/a'}${item.family_id ? ' | ' + item.family_id : ''}${summarizeGeneratedPriority(item) ? ' | ' + summarizeGeneratedPriority(item) : ''}`
        };
    }));

    if (generatedQueueCount) {
        const total = queueItems.length;
        const open = workQueue.open_count != null ? workQueue.open_count : total;
        generatedQueueCount.textContent = `${total} queued | ${open} open`;
    }
}

function renderMatrixTable(container, items, columnCount = 3) {
    if (!container) return;
    const safeItems = items && items.length ? items : [{label: 'Signal', value: 'Feed pending.'}];
    const rows = [];

    for (let index = 0; index < safeItems.length; index += columnCount) {
        rows.push(safeItems.slice(index, index + columnCount));
    }

    container.innerHTML = [
        '<tbody>',
        rows.map((row) => [
            '<tr class="system-matrix-row">',
            row.map((item) => [
                '<td class="system-matrix-cell">',
                '<table class="system-matrix-entry" aria-hidden="true">',
                '<tbody>',
                '<tr>',
                `<th scope="row" class="system-matrix-key">${escapeHtml(item.label)}</th>`,
                '</tr>',
                '<tr>',
                `<td class="system-matrix-value">${escapeHtml(item.value)}</td>`,
                '</tr>',
                '</tbody>',
                '</table>',
                '</td>'
            ].join('')).join(''),
            '</tr>'
        ].join('')).join(''),
        '</tbody>'
    ].join('');
}

function renderInspectorList(container, items) {
    if (!container) return;
    const safeItems = items && items.length ? items : [{label: 'Signal', value: 'Feed pending.'}];
    container.innerHTML = [
        '<table class="section-data-table" aria-hidden="true">',
        '<tbody>',
        safeItems.map((item) => [
            '<tr class="section-data-row">',
            '<th scope="row" class="section-data-key">',
            item.badgeText
                ? `<span class="section-data-key-wrap"><span class="${escapeHtml(item.badgeClass || 'status-pill status-pill-neutral')}">${escapeHtml(item.badgeText)}</span><span>${escapeHtml(item.label)}</span></span>`
                : escapeHtml(item.label),
            '</th>',
            `<td class="section-data-value">${escapeHtml(item.value)}</td>`,
            '</tr>'
        ].join('')).join(''),
        '</tbody>',
        '</table>'
    ].join('');
}

function selectedPipeline() {
    return pipelinesCache.find((item) => String(item && item.pipeline_id ? item.pipeline_id : '') === selectedPipelineId) || null;
}

function renderPipelineCards() {
    if (!pipelineCards) return;
    if (!pipelinesCache.length) {
        pipelineCards.textContent = 'No pipelines registered.';
        return;
    }
    pipelineCards.innerHTML = pipelinesCache.map((pipeline) => {
        const id = String(pipeline.pipeline_id || '').trim();
        const active = id === selectedPipelineId ? ' active' : '';
        const laneState = pipeline.lane_state && typeof pipeline.lane_state === 'object' ? pipeline.lane_state : {};
        const state = String(laneState.state || (laneState.enabled === false ? 'paused' : 'running'));
        const mode = pipeline.read_only ? 'read-only' : 'read/write';
        const scope = String(pipeline.network_scope || 'unknown');
        return [
            `<button class="pipeline-card-button${active}" type="button" data-pipeline-id="${escapeHtml(id)}">`,
            `<div class="pipeline-card-title">${escapeHtml(pipeline.display_name || id)}</div>`,
            `<div class="pipeline-card-meta">${escapeHtml(id)} | ${escapeHtml(mode)} | ${escapeHtml(scope)} | ${escapeHtml(state)}</div>`,
            '</button>'
        ].join('');
    }).join('');
}

function renderPipelineSelect() {
    if (!pipelineSelect) return;
    const previous = selectedPipelineId || String(pipelineSelect.value || '').trim();
    pipelineSelect.innerHTML = '';
    if (!pipelinesCache.length) {
        const option = document.createElement('option');
        option.value = '';
        option.textContent = '(no pipelines)';
        pipelineSelect.appendChild(option);
        return;
    }
    pipelinesCache.forEach((pipeline) => {
        const option = document.createElement('option');
        option.value = String(pipeline.pipeline_id || '').trim();
        option.textContent = `${pipeline.display_name || pipeline.pipeline_id} (${pipeline.pipeline_id})`;
        pipelineSelect.appendChild(option);
    });
    if (previous && pipelinesCache.some((item) => String(item.pipeline_id || '') === previous)) {
        pipelineSelect.value = previous;
        selectedPipelineId = previous;
    } else {
        selectedPipelineId = String(pipelineSelect.value || '').trim();
    }
}

const PIPELINE_QUERY_PARAM_SPECS = {
    offset: {label: 'Offset', type: 'number', placeholder: '0', defaultValue: '0'},
    query: {label: 'Query', type: 'text', placeholder: 'school'},
    namespace: {label: 'Namespace', type: 'text', placeholder: 'ed-fi'},
    resource: {
        label: 'Resource',
        type: 'select',
        options: ['ed-fi/schools', 'ed-fi/students', 'ed-fi/studentSchoolAssociations'],
        defaultValue: 'ed-fi/schools',
    },
    min_change_version: {label: 'Min change version', type: 'number', placeholder: 'saved cursor'},
    advance_cursor: {label: 'Advance cursor after pull', type: 'checkbox', defaultValue: false},
};

function pipelineQueryTemplateCatalog(probe) {
    const catalog = probe && probe.query_template_catalog && typeof probe.query_template_catalog === 'object'
        ? probe.query_template_catalog
        : {};
    return catalog;
}

function collectPipelineQueryParams(operation) {
    const template = pipelineQueryCatalogCache[operation] || {};
    const allowed = Array.isArray(template.params) ? template.params.map((item) => String(item)) : [];
    const params = {};
    allowed.forEach((name) => {
        const field = document.getElementById(`pipelineQueryParam_${name}`);
        if (!field) return;
        if (field.type === 'checkbox') {
            if (field.checked) params[name] = true;
            return;
        }
        const raw = String(field.value || '').trim();
        if (!raw) return;
        if (field.type === 'number') {
            const parsed = Number(raw);
            if (!Number.isNaN(parsed)) params[name] = parsed;
            return;
        }
        params[name] = raw;
    });
    pipelineQueryParamValuesCache[operation] = {...params};
    return params;
}

function renderPipelineQueryParamFields(operation) {
    if (!pipelineQueryParams) return;
    const template = pipelineQueryCatalogCache[operation] || {};
    const allowed = Array.isArray(template.params) ? template.params.map((item) => String(item)) : [];
    if (!allowed.length) {
        pipelineQueryParams.innerHTML = '<div class="section-footnote">This operation has no extra parameters.</div>';
        return;
    }
    const cached = pipelineQueryParamValuesCache[operation] || {};
    pipelineQueryParams.innerHTML = allowed.map((name) => {
        const spec = PIPELINE_QUERY_PARAM_SPECS[name] || {label: name, type: 'text', placeholder: name};
        const fieldId = `pipelineQueryParam_${name}`;
        const cachedValue = cached[name];
        if (spec.type === 'checkbox') {
            const checked = cachedValue === true || cachedValue === 'true' || Boolean(spec.defaultValue);
            return [
                '<div class="pipeline-query-param-field">',
                `<label class="field-label d-flex align-items-center gap-2" for="${fieldId}">`,
                `<input id="${fieldId}" type="checkbox"${checked ? ' checked' : ''}>`,
                `<span>${escapeHtml(spec.label || name)}</span>`,
                '</label>',
                '</div>',
            ].join('');
        }
        if (spec.type === 'select') {
            const options = Array.isArray(spec.options) ? spec.options : [];
            const selected = String(cachedValue != null ? cachedValue : (spec.defaultValue || options[0] || ''));
            return [
                '<div class="pipeline-query-param-field">',
                `<label class="field-label" for="${fieldId}">${escapeHtml(spec.label || name)}</label>`,
                `<select id="${fieldId}" class="form-select form-select-sm">`,
                options.map((option) => {
                    const value = String(option);
                    return `<option value="${escapeHtml(value)}"${value === selected ? ' selected' : ''}>${escapeHtml(value)}</option>`;
                }).join(''),
                '</select>',
                '</div>',
            ].join('');
        }
        const value = cachedValue != null ? String(cachedValue) : String(spec.defaultValue || '');
        return [
            '<div class="pipeline-query-param-field">',
            `<label class="field-label" for="${fieldId}">${escapeHtml(spec.label || name)}</label>`,
            `<input id="${fieldId}" class="form-control form-control-sm" type="${escapeHtml(spec.type || 'text')}"`,
            ` placeholder="${escapeHtml(spec.placeholder || '')}" value="${escapeHtml(value)}">`,
            '</div>',
        ].join('');
    }).join('');
}

function renderPipelineQueryTable(result) {
    if (!pipelineQueryTable) return;
    const rows = Array.isArray(result && result.rows) ? result.rows : [];
    const columns = Array.isArray(result && result.columns) && result.columns.length
        ? result.columns
        : (rows[0] && typeof rows[0] === 'object' ? Object.keys(rows[0]).slice(0, 8) : []);
    if (!rows.length || !columns.length) {
        pipelineQueryTable.classList.add('d-none');
        pipelineQueryTable.innerHTML = '';
        return;
    }
    pipelineQueryTable.classList.remove('d-none');
    pipelineQueryTable.innerHTML = [
        '<table class="pipeline-query-table">',
        '<thead><tr>',
        columns.map((column) => `<th scope="col">${escapeHtml(String(column))}</th>`).join(''),
        '</tr></thead>',
        '<tbody>',
        rows.slice(0, 25).map((row) => [
            '<tr>',
            columns.map((column) => {
                const value = row && Object.prototype.hasOwnProperty.call(row, column) ? row[column] : '';
                const text = typeof value === 'object' ? JSON.stringify(value) : String(value == null ? '' : value);
                return `<td>${escapeHtml(text)}</td>`;
            }).join(''),
            '</tr>',
        ].join('')).join(''),
        '</tbody>',
        '</table>',
    ].join('');
}

function formatPipelineQueryResult(result) {
    if (!result || typeof result !== 'object') return 'No query result returned.';
    const lines = [
        `ok: ${Boolean(result.ok)}`,
        `execution_mode: ${String(result.execution_mode || 'unknown')}`,
        `operation: ${String(result.operation || '')}`,
        `effective_row_limit: ${result.effective_row_limit != null ? result.effective_row_limit : 'n/a'}`,
    ];
    if (result.description) lines.push(`description: ${String(result.description)}`);
    if (result.error) lines.push(`error: ${String(result.error)}`);
    if (result.next_step) lines.push(`next_step: ${String(result.next_step)}`);
    if (result.row_count != null) lines.push(`row_count: ${result.row_count}`);
    if (result.note) lines.push(`note: ${String(result.note)}`);
    if (result.mechanism) lines.push(`mechanism: ${String(result.mechanism)}`);
    if (result.min_change_version != null) lines.push(`min_change_version: ${result.min_change_version}`);
    if (result.next_change_version != null) lines.push(`next_change_version: ${result.next_change_version}`);
    if (result.edfi && typeof result.edfi === 'object') {
        const edfi = result.edfi;
        if (edfi.records_scanned != null) lines.push(`records_scanned: ${edfi.records_scanned}`);
        if (edfi.district_filter_strategy) lines.push(`district_filter_strategy: ${edfi.district_filter_strategy}`);
        if (edfi.resource) lines.push(`resource: ${edfi.resource}`);
    }
    if (Array.isArray(result.rows) && result.rows.length) {
        lines.push('', `rows: showing up to 25 in table (${result.rows.length} total returned)`);
    } else if (Array.isArray(result.items) && result.items.length && typeof result.items[0] !== 'object') {
        lines.push('', 'items:');
        result.items.slice(0, 20).forEach((item, index) => lines.push(`${index + 1}. ${String(item)}`));
    } else if (result.items && typeof result.items === 'object' && !Array.isArray(result.items)) {
        lines.push('', 'summary:');
        lines.push(JSON.stringify(result.items, null, 2));
    } else if (Array.isArray(result.rows) && result.rows.length === 1 && typeof result.rows[0] === 'object') {
        lines.push('', 'summary:');
        lines.push(JSON.stringify(result.rows[0], null, 2));
    }
    return lines.join('\n');
}

function renderEdfiSyncSummary(status) {
    if (!pipelineEdfiSyncGrid) return;
    const sync = status.change_sync && typeof status.change_sync === 'object' ? status.change_sync : {};
    const resources = sync.resources && typeof sync.resources === 'object' ? sync.resources : {};
    const rows = Object.keys(resources).sort().map((resource) => {
        const entry = resources[resource] || {};
        return {
            label: 'Cursor',
            value: `${resource} | last=${String(entry.last_change_version || 0)} | items=${String(entry.last_item_count || 0)} | mechanism=${String(entry.last_pull_mechanism || 'none')}`,
        };
    });
    const available = sync.available && typeof sync.available === 'object' ? sync.available : {};
    const summary = [
        {label: 'Cached newest version', value: String(available.newest_change_version != null ? available.newest_change_version : (status.newest_change_version || 0))},
        {label: 'Cached oldest version', value: String(available.oldest_change_version != null ? available.oldest_change_version : 'n/a')},
        {label: 'Cursor file', value: String(sync.cursor_path || status.change_sync_path || 'not created yet')},
        ...rows,
    ];
    if (!rows.length) {
        summary.push({label: 'Cursors', value: 'No saved cursors yet. Run sync status or pull changes with advance cursor.'});
    }
    renderInspectorList(pipelineEdfiSyncGrid, summary);
}

function renderPipelineQueryControls(status, probe) {
    const kind = String(status.kind || selectedPipeline()?.kind || '').trim().toLowerCase();
    const isEdfi = kind === 'edfi';
    const operations = Array.isArray(probe.query_templates) ? probe.query_templates.filter(Boolean) : [];
    const showRunner = operations.length > 0;
    pipelineQueryCatalogCache = pipelineQueryTemplateCatalog(probe);
    if (pipelineEdfiSection) {
        pipelineEdfiSection.classList.toggle('d-none', !isEdfi || !showRunner);
    }
    if (pipelineQuerySection) {
        pipelineQuerySection.classList.toggle('d-none', !showRunner);
    }
    if (pipelinePopulationSection) {
        pipelinePopulationSection.classList.toggle('d-none', isEdfi);
    }
    if (isEdfi) {
        renderEdfiSyncSummary(status);
    }
    if (!pipelineQueryOperation) return;
    const previous = String(pipelineQueryOperation.value || '').trim();
    pipelineQueryOperation.innerHTML = '';
    if (!showRunner) {
        const option = document.createElement('option');
        option.value = '';
        option.textContent = '(no governed operations)';
        pipelineQueryOperation.appendChild(option);
        if (pipelineQueryResult) pipelineQueryResult.textContent = 'Query results will appear here.';
        if (pipelineQueryTable) {
            pipelineQueryTable.classList.add('d-none');
            pipelineQueryTable.innerHTML = '';
        }
        return;
    }
    operations.forEach((operation) => {
        const option = document.createElement('option');
        option.value = String(operation);
        option.textContent = String(operation);
        pipelineQueryOperation.appendChild(option);
    });
    if (previous && operations.includes(previous)) {
        pipelineQueryOperation.value = previous;
    }
    renderPipelineQueryParamFields(String(pipelineQueryOperation.value || operations[0] || ''));
    const active = String(pipelineQueryOperation.value || operations[0] || '');
    const template = pipelineQueryCatalogCache[active] || {};
    if (pipelineQueryDescription) {
        pipelineQueryDescription.textContent = String(template.description || 'Select an operation to see its governed description and parameters.');
    }
    if (pipelineQueryRowLimit && template.max_rows != null) {
        pipelineQueryRowLimit.max = String(Math.max(1, Number(template.max_rows) || 50));
    }
}

async function executePipelineQuery({live = false, operation = '', rowLimit = null, params = null, confirmLive = true} = {}) {
    const pipelineId = pipelineSelect ? String(pipelineSelect.value || '').trim() : selectedPipelineId;
    const selectedOperation = String(operation || (pipelineQueryOperation ? pipelineQueryOperation.value : '') || '').trim();
    const limit = rowLimit != null
        ? Number(rowLimit)
        : Number(pipelineQueryRowLimit ? pipelineQueryRowLimit.value || 10 : 10);
    if (!pipelineId) {
        setAction('Select a data lane before running a query.');
        return null;
    }
    if (!selectedOperation) {
        setAction('Select a governed operation before running a query.');
        return null;
    }
    if (live && confirmLive) {
        const confirmed = window.confirm(`Run live governed query ${selectedOperation} on ${pipelineId}? This may read district data from the configured source.`);
        if (!confirmed) {
            setAction(`Live query canceled for ${selectedOperation}.`);
            return null;
        }
    }
    const queryParams = params && typeof params === 'object' ? params : collectPipelineQueryParams(selectedOperation);
    const action = live ? 'pipeline_query_run' : 'pipeline_query_preview';
    const payload = await postAction(action, {
        pipeline_id: pipelineId,
        operation: selectedOperation,
        row_limit: limit,
        params: queryParams,
    });
    const result = payload.result && typeof payload.result === 'object' ? payload.result : payload;
    if (pipelineQueryOperation && selectedOperation) pipelineQueryOperation.value = selectedOperation;
    renderPipelineQueryTable(result);
    if (pipelineQueryResult) pipelineQueryResult.textContent = formatPipelineQueryResult(result);
    if (live && selectedPipelineId === pipelineId) {
        await loadPipelines(pipelineId);
    }
    setAction(payload.message || (live ? 'pipeline_query_live_ok' : 'pipeline_query_preview_ok'));
    return result;
}

function renderPipelineDetail(payload) {
    const detail = payload && payload.detail && typeof payload.detail === 'object' ? payload.detail : {};
    pipelineDetailCache = detail;
    const status = detail.status && typeof detail.status === 'object' ? detail.status : {};
    const probe = detail.schema_probe && typeof detail.schema_probe === 'object' ? detail.schema_probe : {};
    const schema = probe.schema && typeof probe.schema === 'object' ? probe.schema : {};
    const schemaSource = schema.source && typeof schema.source === 'object' ? schema.source : {};
    const vendorDictionary = probe.vendor_dictionary && typeof probe.vendor_dictionary === 'object' ? probe.vendor_dictionary : {};
    const vendorSource = vendorDictionary.source && typeof vendorDictionary.source === 'object' ? vendorDictionary.source : {};
    const entities = Array.isArray(schema.entities) ? schema.entities : [];
    const populations = probe.population_definitions && Array.isArray(probe.population_definitions.populations)
        ? probe.population_definitions.populations
        : [];
    const intake = detail.intake && typeof detail.intake === 'object' ? detail.intake : {};
    const laneState = detail.lane_state && typeof detail.lane_state === 'object' ? detail.lane_state : {};
    const auth = status.auth_probe && typeof status.auth_probe === 'object' ? status.auth_probe : {};
    const network = status.network_probe && typeof status.network_probe === 'object' ? status.network_probe : {};
    const readiness = status.readiness && typeof status.readiness === 'object' ? status.readiness : {};
    const readinessBlockers = Array.isArray(status.readiness_blockers)
        ? status.readiness_blockers
        : (Array.isArray(readiness.blockers) ? readiness.blockers : []);
    const selectedSummary = selectedPipeline() || {};
    const pipelineKind = String(status.kind || selectedSummary.kind || '').trim().toLowerCase();
    const isEdfi = pipelineKind === 'edfi';

    if (pipelineEditName) pipelineEditName.value = String(status.display_name || selectedPipelineId || '');
    if (pipelineEditDescription) pipelineEditDescription.value = String(status.description || selectedSummary.description || '');
    if (pipelineEditScope) pipelineEditScope.value = String(status.network_scope || selectedSummary.network_scope || '');

    const statusRows = [
        {label: 'Pipeline', value: selectedPipelineId || 'none'},
        {label: 'Kind', value: pipelineKind || 'unknown'},
        {label: 'Lane state', value: String(laneState.state || (laneState.enabled === false ? 'paused' : 'running'))},
        {label: 'Read only', value: String(Boolean(status.read_only))},
        {label: 'Configured', value: String(Boolean(status.configured))},
        {label: 'Live ready', value: String(Boolean(status.live_query_ready))},
        {label: 'Readiness', value: `${String(readiness.state || (status.live_query_ready ? 'ready' : 'blocked'))}${readinessBlockers.length ? ' | ' + readinessBlockers.join(', ') : ''}`},
        {label: 'Next step', value: String(status.next_step || readiness.next_step || 'n/a')},
    ];
    if (isEdfi) {
        statusRows.splice(4, 0,
            {label: 'Connection', value: String(status.connection_id || 'not set')},
            {label: 'District LEA', value: String(status.district_lea_id || 'not set')},
            {label: 'Profile health', value: String(status.profile_health || 'unknown')},
            {label: 'Resources', value: String(status.resource_count != null ? status.resource_count : 'unknown')},
            {label: 'Cached change version', value: String(status.newest_change_version != null ? status.newest_change_version : 'n/a')},
            {label: 'Sync cursors', value: String(
                Object.keys((status.change_sync && status.change_sync.resources) || {}).length || 0
            )},
        );
    } else {
        statusRows.splice(5, 0,
            {label: 'Network', value: String(network.reason || 'unknown')},
            {label: 'Auth', value: String(auth.reason || 'unknown')},
            {label: 'Identity', value: status.current_windows_identity || status.intended_windows_identity ? `${String(status.current_windows_identity || 'unknown')} -> ${String(status.intended_windows_identity || 'not set')}` : 'n/a'},
            {label: 'Driver', value: String(status.driver_selected || 'none')},
        );
    }
    renderInspectorList(pipelineStatusGrid, statusRows);

    const schemaRows = [
        {label: 'Schema status', value: String(schemaSource.verification_status || (isEdfi ? 'edfi_manifest' : 'unknown'))},
        {label: 'Seeded groups', value: entities.map((entity) => `${entity.name}${entity.verification_status ? ' [' + entity.verification_status + ']' : ''}`).filter(Boolean).join(', ') || 'none'},
        {label: 'Governed operations', value: (Array.isArray(probe.query_templates) ? probe.query_templates : []).join(', ') || 'none'},
        {label: 'Intake log', value: String(intake.path || 'not created yet')},
    ];
    if (isEdfi) {
        schemaRows.splice(1, 0, {label: 'Ed-Fi entities', value: String(entities.length || 0)});
    } else {
        schemaRows.splice(1, 0,
            {label: 'Vendor dictionary', value: vendorDictionary.table_count ? `${vendorDictionary.table_count} tables | ${vendorSource.grounding_status || 'vendor_grounded'}` : 'not loaded'},
            {label: 'Population definitions', value: populations.map((item) => item.key).filter(Boolean).join(', ') || 'none'},
        );
    }
    renderInspectorList(pipelineSchemaSummary, schemaRows);
    renderPipelineQueryControls(status, probe);
    if (pipelineIntakeBox) {
        const recent = Array.isArray(intake.recent) ? intake.recent : [];
        pipelineIntakeBox.textContent = recent.length
            ? recent.map((entry) => `[${entry.created_at || ''}] ${entry.note_type || 'note'}\n${entry.note || ''}`).join('\n\n')
            : 'No scoped intake notes recorded for this pipeline yet.';
    }
}

function renderPipelines(payload) {
    pipelinesCache = Array.isArray(payload && payload.pipelines) ? payload.pipelines.filter((item) => item && typeof item === 'object') : [];
    selectedPipelineId = String(payload && payload.selected_pipeline_id ? payload.selected_pipeline_id : selectedPipelineId || '').trim();
    if (pipelineListSummary) {
        pipelineListSummary.textContent = `${pipelinesCache.length} registered pipeline${pipelinesCache.length === 1 ? '' : 's'}. Notes are scoped to the selected pipeline.`;
    }
    renderPipelineSelect();
    renderPipelineCards();
    renderPipelineDetail(payload || {});
}

async function loadPipelines(selectedId = '') {
    const target = String(selectedId || selectedPipelineId || '').trim();
    const query = target ? `?pipeline_id=${encodeURIComponent(target)}` : '';
    const payload = await getJson(`/api/control/pipelines${query}`);
    renderPipelines(payload);
    return payload;
}

function patchBadgeClass(status) {
    if (!status || status.patch_enabled === false) return 'status-pill status-pill-neutral';
    if (status.patch_ready_for_validated_apply) return 'status-pill status-pill-good';
    if (status.patch_pipeline_ready) return 'status-pill status-pill-warn';
    const previewStatus = String(status.patch_last_preview_status || '').toLowerCase();
    if (previewStatus.startsWith('rejected') || status.patch_behavioral_check === false || status.patch_strict_manifest === false) {
        return 'status-pill status-pill-danger';
    }
    return 'status-pill status-pill-warn';
}

function renderPatchReadiness(status) {
    const patchEnabled = Boolean(status && status.patch_enabled);
    const pipelineReady = Boolean(status && status.patch_pipeline_ready);
    const validatedReady = Boolean(status && status.patch_ready_for_validated_apply);
    const currentRevision = status && status.patch_current_revision != null ? status.patch_current_revision : 'n/a';
    const previewsTotal = status && status.patch_previews_total != null ? status.patch_previews_total : 0;
    const previewsPending = status && status.patch_previews_pending != null ? status.patch_previews_pending : 0;
    const previewsApproved = status && status.patch_previews_approved != null ? status.patch_previews_approved : 0;
    const previewsRejected = status && status.patch_previews_rejected != null ? status.patch_previews_rejected : 0;
    const previewsEligible = status && status.patch_previews_eligible != null ? status.patch_previews_eligible : 0;
    const previewsApprovedEligible = status && status.patch_previews_approved_eligible != null ? status.patch_previews_approved_eligible : 0;
    const previewsOrphaned = status && status.patch_previews_orphaned != null ? status.patch_previews_orphaned : 0;
    const reviewPreviewsTotal = status && status.patch_review_previews_total != null ? status.patch_review_previews_total : previewsTotal;
    const reviewPendingDistinct = status && status.patch_review_previews_pending_distinct != null ? status.patch_review_previews_pending_distinct : previewsPending;
    const reviewPendingSuperseded = status && status.patch_review_previews_pending_superseded != null ? status.patch_review_previews_pending_superseded : 0;
    const reviewApprovedDistinct = status && status.patch_review_previews_approved_distinct != null ? status.patch_review_previews_approved_distinct : previewsApproved;
    const reviewApprovedSuperseded = status && status.patch_review_previews_approved_superseded != null ? status.patch_review_previews_approved_superseded : 0;
    const reviewOrphaned = status && status.patch_review_previews_orphaned != null ? status.patch_review_previews_orphaned : previewsOrphaned;
    const reviewSupersededTotal = status && status.patch_review_previews_superseded_total != null
        ? status.patch_review_previews_superseded_total
        : (reviewPendingSuperseded + reviewApprovedSuperseded);
    const cleanupStatus = String(status && status.patch_cleanup_status ? status.patch_cleanup_status : '').trim();
    const cleanupAt = String(status && status.patch_cleanup_at ? status.patch_cleanup_at : '').trim();
    const cleanupOrphanRejected = status && status.patch_cleanup_orphan_rejected_count != null ? status.patch_cleanup_orphan_rejected_count : 0;
    const cleanupSupersededArchived = status && status.patch_cleanup_superseded_archived_count != null ? status.patch_cleanup_superseded_archived_count : 0;
    const cleanupReviewBefore = status && status.patch_cleanup_review_total_before != null ? status.patch_cleanup_review_total_before : 0;
    const cleanupReviewAfter = status && status.patch_cleanup_review_total_after != null ? status.patch_cleanup_review_total_after : 0;
    const previewStatus = String(status && status.patch_last_preview_status ? status.patch_last_preview_status : '').trim();
    const previewDecision = String(status && status.patch_last_preview_decision ? status.patch_last_preview_decision : 'pending').trim() || 'pending';
    const lastPreviewName = String(status && status.patch_last_preview_name ? status.patch_last_preview_name : '').trim() || 'none';
    const lastLogLine = String(status && status.patch_last_log_line ? status.patch_last_log_line : '').trim() || 'Patch log quiet.';

    if (patchStatusBadge) {
        patchStatusBadge.className = patchBadgeClass(status);
        if (!patchEnabled) patchStatusBadge.textContent = 'Patch pipeline disabled';
        else if (validatedReady) patchStatusBadge.textContent = previewsApprovedEligible === 1 ? '1 preview ready to apply' : `${previewsApprovedEligible} previews ready to apply`;
        else if (!pipelineReady) patchStatusBadge.textContent = 'Pipeline blocked';
        else if (previewsTotal === 0) patchStatusBadge.textContent = 'Awaiting preview';
        else if (reviewApprovedDistinct === 0 && reviewPendingDistinct > 0) patchStatusBadge.textContent = 'Awaiting review';
        else if (reviewApprovedDistinct > 0 && previewsApprovedEligible === 0) patchStatusBadge.textContent = 'Approved preview blocked';
        else if (previewStatus.toLowerCase().startsWith('rejected')) patchStatusBadge.textContent = 'Preview blocked';
        else patchStatusBadge.textContent = 'No ready preview';
    }

    if (patchStatusNarrative) {
        if (!patchEnabled) {
            patchStatusNarrative.textContent = 'Patch apply is disabled by policy. No live promotion should be attempted until the pipeline is re-enabled.';
        } else {
            const blockers = [];
            if (status && status.patch_strict_manifest === false) blockers.push('strict manifest is disabled');
            if (status && status.patch_behavioral_check === false) blockers.push('behavioral validation is disabled');
            if (status && status.patch_tests_available === false) blockers.push('tests are not available');
            if (!pipelineReady) {
                patchStatusNarrative.textContent = blockers.length
                    ? `The patch pipeline is not ready because ${blockers.join(', ')}.`
                    : 'The patch pipeline is not ready yet. Review policy gates and workspace validation coverage.';
            } else if (validatedReady) {
                const queueText = reviewPendingDistinct > 0
                    ? `${reviewPendingDistinct} distinct review item${reviewPendingDistinct === 1 ? '' : 's'} still await operator review`
                    : 'no additional distinct review work is waiting';
                const supersededText = reviewSupersededTotal > 0
                    ? ` ${reviewSupersededTotal} older preview artifact${reviewSupersededTotal === 1 ? ' is' : 's are'} superseded behind the active queue.`
                    : '';
                patchStatusNarrative.textContent = `The patch pipeline is armed at revision ${currentRevision}, and ${previewsApprovedEligible} approved eligible preview${previewsApprovedEligible === 1 ? '' : 's'} can be promoted now. ${queueText}.${supersededText}`;
            } else if (previewsTotal === 0) {
                patchStatusNarrative.textContent = `The patch pipeline is armed at revision ${currentRevision}, but there are no preview reports in the queue yet.`;
            } else {
                const queueReasons = [];
                if (reviewPendingDistinct > 0) {
                    queueReasons.push(`${reviewPendingDistinct} distinct review item${reviewPendingDistinct === 1 ? '' : 's'} still need operator approval`);
                }
                if (reviewApprovedDistinct > previewsApprovedEligible) {
                    const blockedApproved = reviewApprovedDistinct - previewsApprovedEligible;
                    queueReasons.push(`${blockedApproved} approved review item${blockedApproved === 1 ? '' : 's'} are not currently eligible`);
                }
                if (reviewSupersededTotal > 0) {
                    queueReasons.push(`${reviewSupersededTotal} superseded preview artifact${reviewSupersededTotal === 1 ? '' : 's'} are stacked behind newer queue entries`);
                }
                if (previewsRejected > 0) {
                    queueReasons.push(`${previewsRejected} preview${previewsRejected === 1 ? '' : 's'} are rejected`);
                }
                if (previewsOrphaned > 0) {
                    queueReasons.push(`${previewsOrphaned} preview artifact${previewsOrphaned === 1 ? ' is' : 's are'} orphaned`);
                }
                if (!queueReasons.length && previewStatus.toLowerCase().startsWith('rejected')) {
                    queueReasons.push(`the latest preview is ${previewStatus}`);
                }
                patchStatusNarrative.textContent = queueReasons.length
                    ? `The patch pipeline is armed, but no approved eligible preview is ready to apply because ${queueReasons.join(', ')}.`
                    : 'The patch pipeline is armed, but no approved eligible preview is ready to apply yet. Review preview state and the latest patch log before attempting promotion.';
            }
            if (cleanupStatus && cleanupStatus !== 'failed' && (cleanupOrphanRejected > 0 || cleanupSupersededArchived > 0 || cleanupReviewBefore !== cleanupReviewAfter)) {
                const cleanupBits = [];
                if (cleanupOrphanRejected > 0) cleanupBits.push(`${cleanupOrphanRejected} orphaned preview${cleanupOrphanRejected === 1 ? '' : 's'} rejected`);
                if (cleanupSupersededArchived > 0) cleanupBits.push(`${cleanupSupersededArchived} superseded artifact${cleanupSupersededArchived === 1 ? '' : 's'} archived`);
                if (cleanupReviewBefore !== cleanupReviewAfter) cleanupBits.push(`review queue ${cleanupReviewBefore} -> ${cleanupReviewAfter}`);
                patchStatusNarrative.textContent += ` Last cleanup${cleanupAt ? ` @ ${cleanupAt}` : ''}: ${cleanupBits.join(', ')}.`;
            }
        }
    }

    renderInspectorList(patchSummaryGrid, [
        {label: 'Patch enabled', value: String(patchEnabled)},
        {label: 'Strict manifest', value: String(Boolean(status && status.patch_strict_manifest))},
        {label: 'Behavioral gate', value: String(Boolean(status && status.patch_behavioral_check))},
        {label: 'Tests available', value: String(Boolean(status && status.patch_tests_available))},
        {label: 'Pipeline ready', value: String(pipelineReady)},
        {label: 'Validated apply ready', value: String(validatedReady)},
        {label: 'Current revision', value: currentRevision},
        {label: 'Behavior timeout sec', value: status && status.patch_behavioral_check_timeout_sec != null ? status.patch_behavioral_check_timeout_sec : 'n/a'},
    ]);

    renderInspectorList(patchPreviewGrid, [
        {label: 'Raw previews total', value: previewsTotal},
        {label: 'Distinct review queue', value: reviewPreviewsTotal},
        {label: 'Pending distinct', value: reviewPendingDistinct},
        {label: 'Pending superseded', value: reviewPendingSuperseded},
        {label: 'Approved distinct', value: reviewApprovedDistinct},
        {label: 'Approved superseded', value: reviewApprovedSuperseded},
        {label: 'Rejected', value: previewsRejected},
        {label: 'Eligible', value: previewsEligible},
        {label: 'Approved + eligible', value: previewsApprovedEligible},
        {label: 'Orphaned artifacts', value: previewsOrphaned},
        {label: 'Review orphaned distinct', value: reviewOrphaned},
        {label: 'Last cleanup', value: cleanupAt || 'n/a'},
        {label: 'Cleanup status', value: cleanupStatus || 'n/a'},
        {label: 'Orphans rejected', value: cleanupOrphanRejected},
        {label: 'Superseded archived', value: cleanupSupersededArchived},
        {label: 'Review queue delta', value: cleanupReviewBefore || cleanupReviewAfter ? `${cleanupReviewBefore} -> ${cleanupReviewAfter}` : 'n/a'},
        {label: 'Latest preview', value: lastPreviewName},
        {label: 'Preview status', value: previewStatus || 'unknown'},
        {label: 'Decision', value: previewDecision},
    ]);

    if (patchLogBox) {
        patchLogBox.textContent = lastLogLine;
    }

    if (patchPreviewSelect) {
        const previews = status && Array.isArray(status.patch_previews) ? status.patch_previews : [];
        const current = (patchPreviewSelect.value || '').trim();
        patchPreviewSelect.innerHTML = '';
        if (!previews.length) {
            const option = document.createElement('option');
            option.value = '';
            option.textContent = '(no patch previews)';
            patchPreviewSelect.appendChild(option);
        } else {
            previews.forEach((preview) => {
                const option = document.createElement('option');
                const name = String(preview && preview.name ? preview.name : '').trim();
                const decision = String(preview && preview.decision ? preview.decision : 'pending').trim() || 'pending';
                const previewState = String(preview && preview.status ? preview.status : 'unknown').trim() || 'unknown';
                option.value = name;
                option.textContent = `${decision.toUpperCase()} | ${previewState} | ${name}`;
                patchPreviewSelect.appendChild(option);
            });
            if (current && previews.some((preview) => String(preview && preview.name ? preview.name : '') === current)) {
                patchPreviewSelect.value = current;
            }
        }
    }

    if (patchPreviewBox && (!status || !Array.isArray(status.patch_previews) || !status.patch_previews.length)) {
        patchPreviewBox.textContent = 'Preview queue is empty.';
    }
    if (patchPreviewSummary && (!status || !Array.isArray(status.patch_previews) || !status.patch_previews.length)) {
        renderPatchPreviewSummary('', '');
    }

    renderPatchActionReadiness(status);
}

function selectedPatchPreviewState(status) {
    const readiness = status && status.patch_action_readiness ? status.patch_action_readiness : {};
    const previewMap = readiness && readiness.by_preview && typeof readiness.by_preview === 'object' ? readiness.by_preview : {};
    const selected = (patchPreviewSelect && patchPreviewSelect.value ? patchPreviewSelect.value.trim() : '') || String(readiness.default_preview || '').trim();
    return {
        readiness,
        selected,
        preview: selected && previewMap[selected] ? previewMap[selected] : null,
    };
}

function renderPatchActionReadiness(status) {
    const state = selectedPatchPreviewState(status);
    const previewState = state.preview;
    const fallback = String(state.readiness && state.readiness.preview_fallback_reason ? state.readiness.preview_fallback_reason : 'Select a patch preview first.');
    const refreshState = state.readiness && state.readiness.preview_refresh ? state.readiness.preview_refresh : {enabled: true, reason: 'Refresh patch preview queue state and governance telemetry.'};
    const showState = previewState && previewState.show ? previewState.show : {enabled: false, reason: fallback};
    const approveState = previewState && previewState.approve ? previewState.approve : {enabled: false, reason: fallback};
    const rejectState = previewState && previewState.reject ? previewState.reject : {enabled: false, reason: fallback};
    const applyState = previewState && previewState.apply ? previewState.apply : {enabled: false, reason: fallback};

    renderInspectorList(patchActionReadiness, [
        {label: 'Selected Preview', value: state.selected || 'none'},
        {label: 'Preview Status', value: previewState ? `${previewState.status || 'unknown'} | decision=${previewState.decision || 'pending'}` : 'No preview selected'},
        {label: 'Refresh Queue', value: `${refreshState.enabled ? 'Enabled' : 'Disabled'} - ${refreshState.reason}`},
        {label: 'Show Preview', value: `${showState.enabled ? 'Enabled' : 'Disabled'} - ${showState.reason}`},
        {label: 'Approve Preview', value: `${approveState.enabled ? 'Enabled' : 'Disabled'} - ${approveState.reason}`},
        {label: 'Reject Preview', value: `${rejectState.enabled ? 'Enabled' : 'Disabled'} - ${rejectState.reason}`},
        {label: 'Apply Preview', value: `${applyState.enabled ? 'Enabled' : 'Disabled'} - ${applyState.reason}`},
    ]);

    setButtonReadiness('btnPatchPreviewRefresh', refreshState);
    setButtonReadiness('btnPatchPreviewShow', showState);
    setButtonReadiness('btnPatchPreviewApprove', approveState);
    setButtonReadiness('btnPatchPreviewReject', rejectState);
    setButtonReadiness('btnPatchPreviewApply', applyState);
}

function renderPlannerInspector(status) {
    renderInspectorList(plannerInspector, [
        {label: 'Intent', value: status && status.last_intent ? status.last_intent : 'n/a'},
        {label: 'Route', value: status && status.last_planner_decision ? status.last_planner_decision : 'n/a'},
        {label: 'Tool', value: status && status.last_action_tool ? status.last_action_tool : 'n/a'},
        {label: 'Reason / Summary', value: status && status.last_route_summary ? status.last_route_summary : 'n/a'},
    ]);
}

function renderLedgerInspector(status) {
    if (!ledgerInspector) return;
    const trace = status && Array.isArray(status.last_route_trace) ? status.last_route_trace : [];
    const items = trace.length ? trace : [
        {stage: 'input', outcome: 'received'},
        {stage: 'planner', outcome: status && status.last_planner_decision ? status.last_planner_decision : 'n/a'},
        {stage: 'final_answer', outcome: status && status.last_action_final_answer ? status.last_action_final_answer : 'n/a'},
    ];
    ledgerInspector.innerHTML = items.map((item) => {
        const outcome = String(item.outcome || '');
        let cls = 'timeline-item';
        if (/ok|matched|grounded|run_tool/i.test(outcome)) cls += ' good';
        else if (/clarify|fallback|warning/i.test(outcome)) cls += ' warn';
        else if (/fail|error|denied/i.test(outcome)) cls += ' danger';
        return [
            `<div class="${cls}">`,
            '<div class="timeline-step">',
            '<div class="timeline-bullet"></div>',
            '<div>',
            `<div class="inspector-key">${escapeHtml(item.stage || 'stage')}</div>`,
            `<div class="inspector-value">${escapeHtml(outcome)}</div>`,
            '</div>',
            '</div>',
            '</div>'
        ].join('');
    }).join('');
}

function runtimeTimelineClass(levelText) {
    const low = String(levelText || '').trim().toLowerCase();
    if (low === 'good' || low === 'ok' || low === 'success') return 'timeline-item good';
    if (low === 'danger' || low === 'fail' || low === 'error') return 'timeline-item danger';
    if (low === 'warn' || low === 'warning') return 'timeline-item warn';
    return 'timeline-item';
}

function formatRuntimeEventTime(tsValue) {
    const numeric = Number(tsValue || 0);
    if (!Number.isFinite(numeric) || numeric <= 0) return 'time unavailable';
    return new Date(numeric * 1000).toLocaleString();
}

function renderRuntimeTimeline(status) {
    if (!runtimeTimeline) return;
    const payload = status && status.runtime_timeline ? status.runtime_timeline : {};
    const events = Array.isArray(payload.events) ? payload.events : [];
    if (!events.length) {
        runtimeTimeline.innerHTML = [
            '<tbody>',
            '<tr class="runtime-timeline-row">',
            '<td class="runtime-timeline-cell" colspan="3">',
            '<table class="runtime-timeline-entry" aria-hidden="true">',
            '<tbody>',
            '<tr><th scope="row" class="runtime-timeline-key">Runtime Event Timeline</th></tr>',
            '<tr><td class="runtime-timeline-value">Runtime lane quiet.</td></tr>',
            '</tbody>',
            '</table>',
            '</td>',
            '</tr>',
            '</tbody>'
        ].join('');
        return;
    }
    const columnCount = 3;
    const maxRows = 8;
    const limitedEvents = events.slice(0, columnCount * maxRows);
    const rows = [];
    for (let index = 0; index < limitedEvents.length; index += columnCount) {
        rows.push(limitedEvents.slice(index, index + columnCount));
    }
    runtimeTimeline.innerHTML = [
        '<tbody>',
        rows.map((row) => [
            '<tr class="runtime-timeline-row">',
            row.map((event) => {
                const tone = String(runtimeTimelineClass(event.level || '')).split(' ').pop();
                const level = String(event.level || 'info').trim().toUpperCase();
                const meta = [event.source || 'runtime', event.service || 'runtime', formatRuntimeEventTime(event.ts)]
                    .map((value) => String(value || '').trim())
                    .filter(Boolean)
                    .join(' | ');
                const detail = String(event.detail || '').trim() || 'No additional detail.';
                return [
                    `<td class="runtime-timeline-cell runtime-timeline-cell-${escapeHtml(tone)}">`,
                    '<table class="runtime-timeline-entry" aria-hidden="true">',
                    '<tbody>',
                    '<tr>',
                    `<th scope="row" class="runtime-timeline-key"><span class="runtime-timeline-keyline"><span class="runtime-timeline-dot runtime-timeline-dot-${escapeHtml(tone)}" aria-hidden="true"></span><span>${escapeHtml(event.title || 'Runtime event')}</span></span></th>`,
                    '</tr>',
                    '<tr>',
                    `<td class="runtime-timeline-meta">${escapeHtml(level)} | ${escapeHtml(meta)}</td>`,
                    '</tr>',
                    '<tr>',
                    `<td class="runtime-timeline-value">${escapeHtml(detail)}</td>`,
                    '</tr>',
                    '</tbody>',
                    '</table>',
                    '</td>'
                ].join('');
            }).join(''),
            '</tr>'
        ].join('')).join(''),
        '</tbody>'
    ].join('');
}

function runtimeBadgeClassForLevel(levelText) {
    const low = String(levelText || '').trim().toLowerCase();
    if (low === 'danger' || low === 'fail' || low === 'error') return 'status-pill status-pill-danger';
    if (low === 'warn' || low === 'warning') return 'status-pill status-pill-warn';
    if (low === 'good' || low === 'ok' || low === 'success') return 'status-pill status-pill-good';
    return 'status-pill status-pill-blue';
}

function renderRuntimeFailures(status) {
    if (!runtimeFailures) return;
    const failures = status && status.runtime_failures ? status.runtime_failures : {};
    const rows = ['guard', 'core', 'webui'].map((key) => failures[key]).filter(Boolean);
    if (!rows.length) {
        runtimeFailures.innerHTML = '<div class="runtime-card"><div class="runtime-card-label">Failure Reasons</div><div class="runtime-card-details"><div class="runtime-detail-value">Fault lane clear.</div></div></div>';
        return;
    }
    runtimeFailures.innerHTML = rows.map((item) => [
        '<div class="runtime-card">',
        '<div class="runtime-card-header">',
        `<div class="runtime-card-label">${escapeHtml(item.label || item.service || 'Service')}</div>`,
        `<span class="${escapeHtml(runtimeBadgeClassForLevel(item.level))}">${escapeHtml(item.status || item.level || 'unknown')}</span>`,
        '</div>',
        '<div class="runtime-card-details">',
        `<div class="runtime-detail-row"><div class="runtime-detail-key">Summary</div><div class="runtime-detail-value">${escapeHtml(item.summary || 'No failure detail.')}</div></div>`,
        `<div class="runtime-detail-row"><div class="runtime-detail-key">Latest Evidence</div><div class="runtime-detail-value">${escapeHtml(item.detail || 'No recent event detail.')}</div></div>`,
        '</div>',
        '</div>'
    ].join('')).join('');
}

function artifactBadgeClass(statusText) {
    const low = String(statusText || '').trim().toLowerCase();
    if (low === 'missing') return 'status-pill status-pill-neutral';
    if (low === 'stale') return 'status-pill status-pill-danger';
    if (low === 'running') return 'status-pill status-pill-good';
    if (low === 'present') return 'status-pill status-pill-blue';
    return 'status-pill status-pill-warn';
}

function renderRuntimeArtifacts(status) {
    if (!runtimeArtifacts) return;
    const payload = status && status.runtime_artifacts ? status.runtime_artifacts : {};
    const items = Array.isArray(payload.items) ? payload.items : [];
    if (!items.length) {
        runtimeArtifacts.innerHTML = '<div class="artifact-card"><div class="runtime-card-label">Runtime Artifacts</div><div class="runtime-detail-value">Artifact lane clear.</div></div>';
        return;
    }
    runtimeArtifacts.innerHTML = items.map((item) => [
        `<div class="artifact-card${selectedArtifactName && selectedArtifactName === String(item.name || '') ? ' is-active' : ''}">`,
        '<div class="runtime-card-header">',
        `<div class="runtime-card-label">${escapeHtml(item.name || 'artifact')}</div>`,
        `<span class="${escapeHtml(artifactBadgeClass(item.status))}">${escapeHtml(item.status || 'unknown')}</span>`,
        '</div>',
        `<div class="artifact-meta">${escapeHtml(item.kind || 'artifact')} | service=${escapeHtml(item.service || 'runtime')} | age=${escapeHtml(item.age_sec != null ? String(item.age_sec) + 's' : 'n/a')}</div>`,
        `<div class="runtime-detail-value artifact-summary">${escapeHtml(item.summary || '')}</div>`,
        '<div class="artifact-actions">',
        `<button type="button" class="btn btn-sm btn-operator-alt artifact-inspect-button" data-artifact-name="${escapeHtml(item.name || '')}">Inspect</button>`,
        `<button type="button" class="btn btn-sm btn-operator-primary artifact-copy-button" data-artifact-name="${escapeHtml(item.name || '')}" data-artifact-path="${escapeHtml(item.path || '')}">Copy Path</button>`,
        '</div>',
        `<pre class="artifact-excerpt">${escapeHtml(item.excerpt || '')}</pre>`,
        '</div>'
    ].join('')).join('');
}

function renderArtifactDetail(detail) {
    if (!artifactDetailMeta || !artifactDetailBox) return;
    if (!detail || !detail.name) {
        renderInspectorList(artifactDetailMeta, [{label: 'Artifact', value: 'Select an artifact to open its trace.'}]);
        artifactDetailBox.textContent = 'Artifact trace pending.';
        return;
    }
    const relatedEvents = Array.isArray(detail.related_events) ? detail.related_events : [];
    renderInspectorList(artifactDetailMeta, [
        {label: 'Artifact', value: detail.name || 'unknown'},
        {label: 'Path', value: detail.path || 'n/a'},
        {label: 'Status', value: `${detail.status || 'unknown'} | service=${detail.service || 'runtime'} | kind=${detail.kind || 'artifact'}`},
        {label: 'Summary', value: detail.summary || 'No artifact summary available.'},
        {label: 'Related Events', value: relatedEvents.length ? relatedEvents.map((event) => `${event.title || 'event'} | ${event.detail || 'no detail'}`).join('\n') : 'No related runtime events recorded.'},
    ]);
    artifactDetailBox.textContent = String(detail.content || detail.excerpt || 'Artifact content unavailable.');
}

function renderReleaseStatus(status) {
    const payload = status && status.release_status ? status.release_status : {};
    const latestState = String(payload.latest_state || 'no-builds');
    const latestReadinessState = String(payload.latest_readiness_state || 'no-builds');
    const latestReadyToShip = Boolean(payload.latest_ready_to_ship);
    const latestVersion = String(payload.latest_version || 'n/a');
    const latestChannel = String(payload.latest_channel || 'n/a');
    const latestLabel = String(payload.latest_label || '');
    const latestArtifactPath = String(payload.latest_artifact_path || 'n/a');
    const latestVerifiedAt = String(payload.latest_verified_at || '');
    const latestVerificationTarget = String(payload.latest_verification_target || '');
    const latestResult = String(payload.latest_validation_result || 'pending');
    const latestNote = String(payload.latest_validation_note || 'No validation note recorded.');
    const latestReadinessNote = String(payload.latest_readiness_note || 'No readiness note recorded.');
    const latestSeed = String(payload.latest_validation_seed_path || 'n/a');
    const recentEntries = Array.isArray(payload.recent_entries) ? payload.recent_entries : [];

    renderInspectorList(releaseStatusGrid, [
        {label: 'State', value: latestState},
        {label: 'Readiness', value: `${latestReadinessState} | ready_to_ship=${latestReadyToShip ? 'yes' : 'no'}`},
        {label: 'Version', value: latestVersion},
        {label: 'Channel', value: latestChannel},
        {label: 'Label', value: latestLabel || 'n/a'},
        {label: 'Result', value: latestResult},
        {label: 'Verified At', value: latestVerifiedAt || 'n/a'},
        {label: 'Verify Target', value: latestVerificationTarget || 'n/a'},
        {label: 'Artifact', value: latestArtifactPath},
        {label: 'Validation Seed', value: latestSeed},
    ]);

    if (releaseNarrative) {
        releaseNarrative.textContent = `Latest release state: ${latestState}. Readiness: ${latestReadinessState}. Validation result: ${latestResult}. ${latestReadinessNote} ${latestNote}`;
    }

    if (!releaseLedgerGrid) return;
    if (!recentEntries.length) {
        releaseLedgerGrid.innerHTML = '<div class="artifact-card"><div class="runtime-card-label">Release Ledger</div><div class="runtime-detail-value">No release entries recorded yet.</div></div>';
        return;
    }
    releaseLedgerGrid.innerHTML = recentEntries.map((entry) => [
        '<div class="artifact-card">',
        '<div class="runtime-card-header">',
        `<div class="runtime-card-label">${escapeHtml(entry.event || 'entry')} | ${escapeHtml(entry.version || 'n/a')}</div>`,
        `<span class="${escapeHtml(artifactBadgeClass(entry.result || entry.event || 'present'))}">${escapeHtml(entry.result || entry.event || 'recorded')}</span>`,
        '</div>',
        `<div class="artifact-meta">channel=${escapeHtml(entry.channel || 'n/a')} | label=${escapeHtml(entry.label || 'n/a')} | at=${escapeHtml(entry.recorded_at || 'n/a')}</div>`,
        `<div class="runtime-detail-value artifact-summary">${escapeHtml(entry.note || entry.artifact_name || 'Release ledger event recorded.')}</div>`,
        `<pre class="artifact-excerpt">${escapeHtml(entry.artifact_path || entry.verification_target_path || entry.validation_record_seed_path || '')}</pre>`,
        '</div>'
    ].join('')).join('');
}

function renderRestartAnalytics(status) {
    const payload = status && status.runtime_restart_analytics ? status.runtime_restart_analytics : {};
    const recentOutcomes = Array.isArray(payload.recent_outcomes) ? payload.recent_outcomes : [];
    if (!restartAnalytics) return;
    const flapLevel = String(payload.flap_level || 'info').toUpperCase();
    const flapSummary = payload.flap_summary || 'Restart trace pending.';
    const latestOutcome = payload.latest_outcome || 'unknown';
    const latestReason = payload.latest_reason || 'n/a';
    const lastSuccess = payload.last_success_age_sec != null ? `${payload.last_success_age_sec}s` : 'none';
    const avgBoot = payload.avg_success_boot_sec ? `${payload.avg_success_boot_sec}s` : 'n/a';
    const recentHistory = recentOutcomes.length
        ? recentOutcomes.slice(0, 3).map((item) => `${item.outcome || 'unknown'}/${item.reason || 'n/a'}/${item.observed_sec != null ? item.observed_sec : 0}s`).join(' | ')
        : 'No recent restart observations.';
    const items = [
        {
            label: 'Stability',
            value: `${flapLevel}\n${latestOutcome}:${latestReason}`,
            title: `${flapLevel} | ${flapSummary} | latest=${latestOutcome} | reason=${latestReason}`
        },
        {
            label: 'Load',
            value: `t${payload.count != null ? payload.count : 0} | 24h ${payload.recent_restart_count_24h != null ? payload.recent_restart_count_24h : 0}\n15m ${payload.recent_restart_count_15m != null ? payload.recent_restart_count_15m : 0} | 1h ${payload.recent_restart_count_1h != null ? payload.recent_restart_count_1h : 0}`,
            title: `total=${payload.count != null ? payload.count : 0} | 15m=${payload.recent_restart_count_15m != null ? payload.recent_restart_count_15m : 0} | 1h=${payload.recent_restart_count_1h != null ? payload.recent_restart_count_1h : 0} | 24h=${payload.recent_restart_count_24h != null ? payload.recent_restart_count_24h : 0}`
        },
        {
            label: 'Mix',
            value: `ok ${payload.success_count != null ? payload.success_count : 0} | fail ${payload.failure_count != null ? payload.failure_count : 0}\ncons ${payload.consecutive_failures != null ? payload.consecutive_failures : 0}`,
            title: `success=${payload.success_count != null ? payload.success_count : 0} | failure=${payload.failure_count != null ? payload.failure_count : 0} | consecutive=${payload.consecutive_failures != null ? payload.consecutive_failures : 0}`
        },
        {
            label: 'Recovery',
            value: `ok ${lastSuccess}\nboot ${avgBoot}`,
            title: `last success=${payload.last_success_age_sec != null ? `${payload.last_success_age_sec}s ago` : 'none'} | avg boot=${avgBoot}`
        },
        {label: 'History', value: recentHistory, title: recentHistory, fullRow: true},
    ];

    restartAnalytics.innerHTML = [
        '<div class="restart-analytics-grid">',
        items.map((item) => [
            `<div class="restart-analytics-card${item.fullRow ? ' restart-analytics-card-history' : ''}" title="${escapeHtml(item.title || item.value)}">`,
            `<div class="restart-analytics-key">${escapeHtml(item.label)}</div>`,
            `<div class="restart-analytics-value">${escapeHtml(item.value)}</div>`,
            '</div>'
        ].join('')).join(''),
        '</div>'
    ].join('');
}

function renderTelemetrySummary(metrics, status) {
    if (!telemetrySummary) return;
    const points = Array.isArray(metrics && metrics.points) ? metrics.points : [];
    const recent = points.slice(-60);
    const last = recent.length ? recent[recent.length - 1] : null;
    const prev = recent.length > 1 ? recent[recent.length - 2] : null;
    if (!last) {
        telemetrySummary.innerHTML = [
            '<div class="telemetry-summary-card telemetry-summary-card-wide">',
            '<div class="telemetry-summary-key">Status</div>',
            '<div class="telemetry-summary-value">Telemetry lane warming.</div>',
            '</div>'
        ].join('');
        return;
    }

    const heartbeatNow = Number(last.heartbeat_age_sec || 0);
    const averageHeartbeat = recent.length
        ? recent.reduce((sum, point) => sum + Number(point.heartbeat_age_sec || 0), 0) / recent.length
        : heartbeatNow;
    const dt = prev ? Math.max(1, Number(last.ts || 0) - Number(prev.ts || 0)) : 1;
    const requestsDelta = prev ? Math.max(0, Number(last.requests_total || 0) - Number(prev.requests_total || 0)) : 0;
    const errorsDelta = prev ? Math.max(0, Number(last.errors_total || 0) - Number(prev.errors_total || 0)) : 0;
    const requestsPerMin = (requestsDelta * 60) / dt;
    const errorsPerMin = (errorsDelta * 60) / dt;
    const requestRates = [];
    const errorRates = [];

    for (let index = 1; index < recent.length; index += 1) {
        const current = recent[index] || {};
        const previous = recent[index - 1] || {};
        const deltaT = Math.max(1, Number(current.ts || 0) - Number(previous.ts || 0));
        requestRates.push((Math.max(0, Number(current.requests_total || 0) - Number(previous.requests_total || 0)) * 60) / deltaT);
        errorRates.push((Math.max(0, Number(current.errors_total || 0) - Number(previous.errors_total || 0)) * 60) / deltaT);
    }

    const peakRequestRate = requestRates.length ? Math.max(...requestRates) : requestsPerMin;
    const peakErrorRate = errorRates.length ? Math.max(...errorRates) : errorsPerMin;
    const healthScore = status && status.health_score != null ? Number(status.health_score) : null;
    const plannerDecision = status && status.last_planner_decision ? String(status.last_planner_decision) : 'n/a';
    const routeSummary = status && status.last_route_summary ? String(status.last_route_summary) : 'Route lane pending.';

    const cards = [
        {key: 'Heartbeat Now', value: `${heartbeatNow.toFixed(1)}s`},
        {key: 'Heartbeat Avg', value: `${averageHeartbeat.toFixed(1)}s`},
        {key: 'Requests / Min', value: requestsPerMin.toFixed(1)},
        {key: 'Peak Req / Min', value: peakRequestRate.toFixed(1)},
        {key: 'Errors / Min', value: errorsPerMin.toFixed(2)},
        {key: 'Peak Err / Min', value: peakErrorRate.toFixed(2)},
        {key: 'Health Score', value: healthScore != null ? `${healthScore}/100` : 'n/a'},
        {key: 'Planner', value: plannerDecision},
        {key: 'Route Trace', value: routeSummary, wide: true},
    ];

    telemetrySummary.innerHTML = cards.map((card) => [
        `<div class="telemetry-summary-card${card.wide ? ' telemetry-summary-card-wide' : ''}">`,
        `<div class="telemetry-summary-key">${escapeHtml(card.key)}</div>`,
        `<div class="telemetry-summary-value">${escapeHtml(card.value)}</div>`,
        '</div>'
    ].join('')).join('');
}

function telemetryWindowStats(points, seconds) {
    const rows = Array.isArray(points) ? points.filter((point) => point && Number.isFinite(Number(point.ts || 0))) : [];
    if (!rows.length) return null;
    const last = rows[rows.length - 1] || {};
    const endTs = Number(last.ts || 0);
    const startTs = Math.max(0, endTs - Math.max(1, Number(seconds || 0)));
    let windowPoints = rows.filter((point) => Number(point.ts || 0) >= startTs);
    if (windowPoints.length < 2) {
        windowPoints = rows.slice(-Math.min(rows.length, 12));
    }
    if (windowPoints.length < 2) return null;

    const first = windowPoints[0] || {};
    const latest = windowPoints[windowPoints.length - 1] || {};
    const elapsed = Math.max(1, Number(latest.ts || 0) - Number(first.ts || 0));
    const requestDelta = Math.max(0, Number(latest.requests_total || 0) - Number(first.requests_total || 0));
    const errorDelta = Math.max(0, Number(latest.errors_total || 0) - Number(first.errors_total || 0));
    const heartbeatValues = windowPoints.map((point) => Number(point.heartbeat_age_sec || 0));
    const heartbeatAvg = heartbeatValues.length
        ? heartbeatValues.reduce((sum, value) => sum + value, 0) / heartbeatValues.length
        : Number(latest.heartbeat_age_sec || 0);
    const heartbeatPeak = heartbeatValues.length ? Math.max(...heartbeatValues) : Number(latest.heartbeat_age_sec || 0);
    return {
        requestRate: (requestDelta * 60) / elapsed,
        errorRate: (errorDelta * 60) / elapsed,
        heartbeatAvg,
        heartbeatPeak,
    };
}

function renderTelemetryPressure(metrics, status) {
    if (!telemetryPressure) return;
    const points = Array.isArray(metrics && metrics.points) ? metrics.points : [];
    if (points.length < 2) {
        telemetryPressure.innerHTML = [
            '<div class="telemetry-pressure-card telemetry-pressure-card-wide">',
            '<div class="telemetry-pressure-key">Status Window</div>',
            '<div class="telemetry-pressure-value">Pressure lanes warming.</div>',
            '</div>'
        ].join('');
        return;
    }

    const windows = [
        {label: '1 Minute', meta: 'burst lane', seconds: 60},
        {label: '5 Minutes', meta: 'sustained lane', seconds: 300},
        {label: '15 Minutes', meta: 'drift lane', seconds: 900},
    ].map((window) => ({...window, stats: telemetryWindowStats(points, window.seconds)}));
    const last = points[points.length - 1] || {};
    const plannerDecision = status && status.last_planner_decision ? String(status.last_planner_decision) : 'n/a';
    const routeSummary = status && status.last_route_summary ? String(status.last_route_summary) : 'Route lane pending.';
    const healthScore = status && status.health_score != null ? `${Number(status.health_score)}/100` : 'n/a';
    const peakHeartbeat = Math.max(...windows.map((window) => Number(window.stats && window.stats.heartbeatPeak || 0)));

    const windowCards = windows.map((window) => {
        const stats = window.stats;
        if (!stats) {
            return [
                '<div class="telemetry-pressure-card">',
                '<div class="telemetry-pressure-head">',
                `<div class="telemetry-pressure-label">${escapeHtml(window.label)}</div>`,
                `<div class="telemetry-pressure-meta">${escapeHtml(window.meta)}</div>`,
                '</div>',
                '<div class="telemetry-pressure-value">Sampling window still warming up.</div>',
                '</div>'
            ].join('');
        }
        return [
            '<div class="telemetry-pressure-card">',
            '<div class="telemetry-pressure-head">',
            `<div class="telemetry-pressure-label">${escapeHtml(window.label)}</div>`,
            `<div class="telemetry-pressure-meta">${escapeHtml(window.meta)}</div>`,
            '</div>',
            '<div class="telemetry-pressure-metrics">',
            '<div>',
            '<div class="telemetry-pressure-key">Ingress / Min</div>',
            `<div class="telemetry-pressure-value">${escapeHtml(stats.requestRate.toFixed(1))}</div>`,
            '</div>',
            '<div>',
            '<div class="telemetry-pressure-key">Fault / Min</div>',
            `<div class="telemetry-pressure-value">${escapeHtml(stats.errorRate.toFixed(2))}</div>`,
            '</div>',
            '<div>',
            '<div class="telemetry-pressure-key">Heartbeat Drag</div>',
            `<div class="telemetry-pressure-value">${escapeHtml(`${stats.heartbeatAvg.toFixed(1)}s`)}</div>`,
            '</div>',
            '</div>',
            '</div>'
        ].join('');
    });

    telemetryPressure.innerHTML = [
        ...windowCards,
        [
            '<div class="telemetry-pressure-card telemetry-pressure-card-wide">',
            '<div class="telemetry-pressure-head">',
            '<div class="telemetry-pressure-label">Operator Signal</div>',
            `<div class="telemetry-pressure-meta">health ${escapeHtml(healthScore)}</div>`,
            '</div>',
            '<div class="telemetry-pressure-metrics">',
            '<div>',
            '<div class="telemetry-pressure-key">Lifetime Counters</div>',
            `<div class="telemetry-pressure-value">req ${escapeHtml(String(Number(last.requests_total || 0)))}\nerr ${escapeHtml(String(Number(last.errors_total || 0)))}</div>`,
            '</div>',
            '<div>',
            '<div class="telemetry-pressure-key">Heartbeat Envelope</div>',
            `<div class="telemetry-pressure-value">now ${escapeHtml(`${Number(last.heartbeat_age_sec || 0).toFixed(1)}s`)}\npeak ${escapeHtml(`${peakHeartbeat.toFixed(1)}s`)}</div>`,
            '</div>',
            '<div>',
            '<div class="telemetry-pressure-key">Planner Trace</div>',
            `<div class="telemetry-pressure-value">${escapeHtml(`${plannerDecision}\n${routeSummary}`)}</div>`,
            '</div>',
            '</div>',
            '</div>'
        ].join('')
    ].join('');
}

function selectedSession() {
    const sid = sessionSelect ? (sessionSelect.value || '').trim() : '';
    const available = filteredSessions();
    return available.find((item) => item.session_id === sid) || available[0] || null;
}

function selectedTestRun() {
    const runId = testRunSelect ? (testRunSelect.value || '').trim() : '';
    return testRunsCache.find((item) => item.run_id === runId) || testRunsCache[0] || null;
}

function testRunStatusLabel(run) {
    const status = String(run && run.status ? run.status : 'green').toLowerCase();
    if (status === 'drift') return 'DRIFT';
    if (status === 'warning') return 'WARN';
    return 'GREEN';
}

function testRunBadgeClass(run) {
    const status = String(run && run.status ? run.status : 'green').toLowerCase();
    if (status === 'drift') return 'status-pill status-pill-danger';
    if (status === 'warning') return 'status-pill status-pill-warn';
    return 'status-pill status-pill-good';
}

function renderSessionState(session) {
    if (!session) {
        renderInspectorList(sessionStateInspector, [{label: 'Session', value: 'Session focus pending.'}]);
        return;
    }
    const state = session.state || {};
    const reflection = session.reflection || {};
    renderInspectorList(sessionStateInspector, [
        {label: 'Session ID', value: session.session_id || ''},
        {label: 'Active Subject', value: state.active_subject || reflection.active_subject || 'none'},
        {label: 'State Kind', value: state.state_kind || 'none'},
        {label: 'Continuation', value: String(Boolean(state.continuation_used))},
        {label: 'Pending Action', value: state.pending_action ? JSON.stringify(state.pending_action, null, 2) : 'none'},
        {label: 'Pending Correction', value: state.pending_correction_target || 'none'},
    ]);
}

function renderSupervisorInspector(session, status) {
    const reflection = session && session.reflection ? session.reflection : {};
    const alerts = status && Array.isArray(status.alerts) ? status.alerts : [];
    const items = [
        {label: 'Probe Summary', value: reflection.probe_summary || (alerts.length ? `Alerts: ${alerts.length}` : 'All green')},
        {label: 'Findings', value: Array.isArray(reflection.probe_results) && reflection.probe_results.length ? reflection.probe_results.join('\n') : (alerts.length ? alerts.join('\n') : 'No supervisor issues detected.')},
    ];
    renderInspectorList(supervisorInspector, items);
    renderInspectorList(supervisorSummaryMain, items);
}

function renderOverrideBadges(session) {
    if (!overrideBadges) return;
    const reflection = session && session.reflection ? session.reflection : {};
    const overrides = Array.isArray(reflection.overrides_active) ? reflection.overrides_active : [];
    overrideBadges.innerHTML = [
        '<span class="override-status-icon-wrap" aria-hidden="true">',
        '<i class="bi bi-sliders2-vertical override-status-icon"></i>',
        '</span>',
        '<span class="override-status-copy">',
        '<span class="override-status-label">Overrides</span>',
        `<span class="override-status-value">${escapeHtml(overrides.length ? overrides.join(' | ') : 'No active overrides')}</span>`,
        '</span>',
    ].join('');
}

function memoryHealthDetails(status) {
    const pulse = status && status.pulse && typeof status.pulse === 'object' ? status.pulse : {};
    const healthPayload = status && status.memory_health && typeof status.memory_health === 'object'
        ? status.memory_health
        : (pulse.memory_health && typeof pulse.memory_health === 'object' ? pulse.memory_health : {});
    const eventLog = healthPayload.memory_events_log && typeof healthPayload.memory_events_log === 'object'
        ? healthPayload.memory_events_log
        : {};
    const statusText = String(
        (status && status.memory_health_status)
        || pulse.memory_health_status
        || 'unknown'
    ).trim() || 'unknown';
    const scopedTotal = Number(
        status && status.memory_scoped_total != null
            ? status.memory_scoped_total
            : (pulse.memory_scoped_total != null ? pulse.memory_scoped_total : (status && status.memory_entries_total != null ? status.memory_entries_total : 0))
    );
    const dbTotal = Number(
        status && status.memory_db_total != null
            ? status.memory_db_total
            : (pulse.memory_db_total != null ? pulse.memory_db_total : scopedTotal)
    );
    const issueCount = Number(
        status && status.memory_health_issue_count != null
            ? status.memory_health_issue_count
            : (pulse.memory_health_issue_count != null ? pulse.memory_health_issue_count : 0)
    );
    const issues = Array.isArray(status && status.memory_health_issues)
        ? status.memory_health_issues
        : (Array.isArray(pulse.memory_health_issues) ? pulse.memory_health_issues : []);
    const issueText = issues.length
        ? issues.slice(0, 3).map((item) => {
            const code = item && item.code ? item.code : 'memory_health_issue';
            const detail = item && item.detail ? item.detail : '';
            return detail ? `${code}: ${detail}` : code;
        }).join('\n')
        : '';
    const eventLogStatus = String(
        (status && status.memory_events_log_status)
        || pulse.memory_events_log_status
        || eventLog.status
        || (status && status.memory_events_ok ? 'ok' : 'unknown')
    ).trim() || 'unknown';
    const eventLogBytes = Number(
        status && status.memory_events_log_bytes != null
            ? status.memory_events_log_bytes
            : (pulse.memory_events_log_bytes != null ? pulse.memory_events_log_bytes : (eventLog.byte_count != null ? eventLog.byte_count : 0))
    );
    const invalidTailCount = Number(
        status && status.memory_events_log_invalid_tail_count != null
            ? status.memory_events_log_invalid_tail_count
            : (pulse.memory_events_log_invalid_tail_count != null ? pulse.memory_events_log_invalid_tail_count : (eventLog.invalid_tail_count != null ? eventLog.invalid_tail_count : 0))
    );
    const byteText = Number.isFinite(eventLogBytes) && eventLogBytes > 0
        ? `${(eventLogBytes / (1024 * 1024)).toFixed(eventLogBytes >= 10 * 1024 * 1024 ? 1 : 2)} MB`
        : '0 MB';
    const eventLogText = `${eventLogStatus} | ${byteText}${invalidTailCount ? ` | invalid tail ${invalidTailCount}` : ''}`;
    return {
        status: statusText,
        scopedTotal: Number.isFinite(scopedTotal) ? scopedTotal : 0,
        dbTotal: Number.isFinite(dbTotal) ? dbTotal : 0,
        issueCount: Number.isFinite(issueCount) ? issueCount : 0,
        eventLogStatus,
        eventLogBytes: Number.isFinite(eventLogBytes) ? eventLogBytes : 0,
        invalidTailCount: Number.isFinite(invalidTailCount) ? invalidTailCount : 0,
        eventLogText,
        issueText,
    };
}

function storageWatchDetails(status) {
    const storageStatus = String(status && status.storage_watch_status ? status.storage_watch_status : 'unknown');
    const storageNote = String(status && status.storage_watch_note ? status.storage_watch_note : 'No storage watch note.');
    const releaseExtractCount = Number(status && status.release_validation_extract_count != null ? status.release_validation_extract_count : 0);
    const releaseStageCount = Number(status && status.release_stage_count != null ? status.release_stage_count : 0);
    const releaseZipCount = Number(status && status.release_zip_count != null ? status.release_zip_count : 0);
    const patchCount = Number(status && status.patch_snapshot_count != null ? status.patch_snapshot_count : 0);
    const kidneyCount = Number(status && status.kidney_snapshot_count != null ? status.kidney_snapshot_count : 0);
    return {
        status: storageStatus,
        note: storageNote,
        totalText: formatStorageBytes(status && status.storage_watch_total_bytes),
        releaseExtractsText: `${Number.isFinite(releaseExtractCount) ? releaseExtractCount : 0} | ${formatStorageBytes(status && status.release_validation_extract_bytes)}`,
        releaseStagesText: `${Number.isFinite(releaseStageCount) ? releaseStageCount : 0} | ${formatStorageBytes(status && status.release_stage_bytes)}`,
        releaseZipsText: `${Number.isFinite(releaseZipCount) ? releaseZipCount : 0} | ${formatStorageBytes(status && status.release_zip_bytes)}`,
        snapshotsText: `patch ${Number.isFinite(patchCount) ? patchCount : 0} | kidney ${Number.isFinite(kidneyCount) ? kidneyCount : 0}`,
    };
}

function renderHealthSummary(status) {
    const alerts = status && Array.isArray(status.alerts) ? status.alerts : [];
    const memory = memoryHealthDetails(status);
    const storage = storageWatchDetails(status);
    renderInspectorList(healthSummary, [
        {label: 'Health Score', value: status && status.health_score != null ? status.health_score : 'n/a'},
        {label: 'Pass Ratio', value: status && status.self_check_pass_ratio != null ? status.self_check_pass_ratio : 'n/a'},
        {label: 'Memory Health', value: `${memory.status}${memory.issueCount ? ` (${memory.issueCount} issue${memory.issueCount === 1 ? '' : 's'})` : ''}`},
        {label: 'Memory Rows', value: `db ${memory.dbTotal} | scope ${memory.scopedTotal}`},
        {label: 'Memory Event Log', value: memory.eventLogText},
        {label: 'Memory Watch', value: memory.issueText || 'No amnesia signals'},
        {label: 'Storage Watch', value: `${storage.status} | ${storage.totalText}\n${storage.note}`},
        {label: 'Release Storage', value: `extracts ${storage.releaseExtractsText}\nstages ${storage.releaseStagesText}\nzips ${storage.releaseZipsText}`},
        {label: 'Snapshot Storage', value: storage.snapshotsText},
        {label: 'Alerts', value: alerts.length ? alerts.join('\n') : 'Alert board clear'},
    ]);
}

function compactRouteSummary(summary, maxSegments = 4) {
    const segments = String(summary || '').split('->').map((part) => part.trim()).filter(Boolean);
    if (!segments.length) return String(summary || 'route lane not available');
    if (segments.length > maxSegments) {
        return `${segments.slice(0, 2).join(' -> ')} -> ... -> ${segments[segments.length - 1]}`;
    }
    return segments.join(' -> ');
}

function shortArtifactName(value) {
    const clean = String(value || '').trim();
    if (!clean) return 'n/a';
    const parts = clean.split(/[\\/]/).filter(Boolean);
    return parts[parts.length - 1] || clean;
}

function renderHeroMeta(container, items) {
    if (!container) return;
    const safeItems = Array.isArray(items) ? items.filter((item) => item && item.value != null && String(item.value).trim()) : [];
    container.innerHTML = safeItems.map((item) => {
        const tone = String(item.tone || '').trim();
        return `<span class="hero-meta-pill${tone ? ` is-${escapeHtml(tone)}` : ''}">${escapeHtml(item.value)}</span>`;
    }).join('');
}

function recommendedCenterTab(status) {
    const alerts = status && Array.isArray(status.alerts) ? status.alerts : [];
    const queueOpen = Number(status && status.generated_work_queue_open_count != null ? status.generated_work_queue_open_count : 0);
    const patchStatus = String(status && status.patch_status ? status.patch_status : '').trim().toLowerCase();
    const releaseReadiness = String(status && status.release_status && status.release_status.latest_readiness_state ? status.release_status.latest_readiness_state : '').trim().toLowerCase();
    const operatorAttention = status && status.operator_attention && typeof status.operator_attention === 'object'
        ? status.operator_attention
        : {};
    const attentionActive = Boolean((status && status.operator_attention_active) || operatorAttention.active);
    const attentionMessage = String((status && status.operator_attention_message) || operatorAttention.message || '').trim();
    if (alerts.length) return {tab: 'failure-reasons', label: 'Failure Reasons', why: `${alerts.length} live alert${alerts.length === 1 ? '' : 's'} need attention`};
    if (attentionActive && attentionMessage) {
        const targetTab = /release/i.test(attentionMessage) ? 'release-governance' : 'system-matrix';
        return {tab: targetTab, label: 'Operator Attention', why: attentionMessage};
    }
    if (queueOpen > 0) return {tab: 'subconscious-watch', label: 'Subconscious Watch', why: `${queueOpen} queue item${queueOpen === 1 ? '' : 's'} are still open`};
    if (patchStatus && !patchStatus.includes('eligible') && !patchStatus.includes('ready')) {
        return {tab: 'patch-readiness', label: 'Patch Readiness', why: 'patch governance needs review'};
    }
    if (releaseReadiness && releaseReadiness !== 'ready') {
        return {tab: 'release-governance', label: 'Release Governance', why: `release candidate is ${releaseReadiness}`};
    }
    return {tab: 'system-matrix', label: 'System Matrix', why: 'runtime posture is stable enough for a general scan'};
}

function recommendedInspectorTab(status, session) {
    const alerts = status && Array.isArray(status.alerts) ? status.alerts : [];
    if (alerts.length) return {tab: 'supervisor', label: 'Supervisor', why: 'alerts are active'};
    if (session) return {tab: 'session', label: 'Session', why: 'a live thread is already in focus'};
    if (status && (status.last_planner_decision || status.last_route_summary)) return {tab: 'planner', label: 'Planner', why: 'route trace is available'};
    return {tab: 'ledger', label: 'Ledger', why: 'trace history is the next best signal'};
}

function openOperatorDeck() {
    setActiveView('operations');
    const operationsShell = document.querySelector('.layer-tab-shell[data-layer-tabs="operations"]');
    if (operationsShell) {
        setLayerTab(operationsShell, 'operator-deck');
    }
}

function openScheduledTreeBlockedView() {
    setActiveView('scheduled-tree');
    setWorkTreeViewMode('blocked');
}

function operatorOutboxOpenCount(status) {
    const summary = status && status.operator_outbox && typeof status.operator_outbox === 'object'
        ? status.operator_outbox
        : {};
    const direct = Number(status && status.operator_outbox_open_count != null ? status.operator_outbox_open_count : NaN);
    const actionable = Number(status && status.operator_outbox_actionable_open_count != null ? status.operator_outbox_actionable_open_count : NaN);
    const summaryOpen = Number(summary.open_count != null ? summary.open_count : NaN);
    const openEvents = Array.isArray(summary.open_events) ? summary.open_events.length : 0;
    const counts = [direct, actionable, summaryOpen, openEvents].filter((value) => Number.isFinite(value));
    return counts.length ? Math.max(...counts) : 0;
}

function latestOperatorOutboxEventId(status) {
    const summary = status && status.operator_outbox && typeof status.operator_outbox === 'object'
        ? status.operator_outbox
        : {};
    const candidates = [
        String(status && status.operator_outbox_actionable_latest_open_id || '').trim(),
        String(status && status.operator_outbox_latest_open_id || '').trim(),
        String((summary.latest_open && summary.latest_open.id) || '').trim(),
        String((summary.latest && summary.latest.id) || '').trim(),
    ];
    const openEvents = Array.isArray(summary.open_events) ? summary.open_events : [];
    if (openEvents.length) {
        candidates.unshift(String(openEvents[openEvents.length - 1].id || '').trim());
    }
    return candidates.find((value) => value) || '';
}

function workTreeBlockedCount(status) {
    const counts = status && status.work_tree_truth && status.work_tree_truth.counts && typeof status.work_tree_truth.counts === 'object'
        ? status.work_tree_truth.counts
        : {};
    const direct = Number(counts.blocked || 0);
    if (direct > 0) return direct;
    let blocked = 0;
    workTreesCache.forEach((tree) => {
        const nodes = Array.isArray(tree && tree.nodes) ? tree.nodes : [];
        nodes.forEach((node) => {
            const nodeStatus = String(node && node.status || '').trim().toLowerCase();
            if (['blocked', 'observing'].includes(nodeStatus)) blocked += 1;
        });
    });
    return blocked;
}

async function dismissOperatorOutboxNotice(eventId, message = 'Dismissed by operator from control panel.') {
    const resolvedId = String(eventId || latestOperatorOutboxEventId(latestStatus) || '').trim();
    if (!resolvedId) {
        setAction('No open operator outbox notice is available to dismiss.');
        return null;
    }
    const payload = await postAction('operator_outbox_respond', {
        event_id: resolvedId,
        message,
        resolution: 'dismissed',
        responder: 'operator',
    });
    setAction(payload.message || 'operator_outbox_response_ok');
    await refresh();
    return payload;
}

function renderOverviewStallRecovery(status) {
    if (!overviewStallRecovery) return;
    if (!status) {
        overviewStallRecovery.hidden = true;
        return;
    }
    const outboxOpen = operatorOutboxOpenCount(status);
    const blockedBranches = workTreeBlockedCount(status);
    const queueOpen = Number(status.generated_work_queue_open_count != null ? status.generated_work_queue_open_count : 0);
    const stallActive = outboxOpen > 0 || blockedBranches > 0;
    overviewStallRecovery.hidden = !stallActive;
    if (!stallActive) return;

    const lines = [];
    if (outboxOpen > 0) {
        lines.push(`${outboxOpen} open operator outbox notice${outboxOpen === 1 ? '' : 's'} need a response before autonomy can advance.`);
        const latestId = latestOperatorOutboxEventId(status);
        if (latestId) lines.push(`Latest notice: ${latestId}`);
    }
    if (blockedBranches > 0) {
        lines.push(`${blockedBranches} blocked Work Tree branch${blockedBranches === 1 ? '' : 'es'} are holding execution.`);
    }
    if (queueOpen > 0) {
        lines.push(`${queueOpen} generated queue item${queueOpen === 1 ? '' : 's'} waiting — use Run Next Queue Item after clearing operator holds.`);
    }
    if (overviewStallRecoverySummary) {
        overviewStallRecoverySummary.textContent = lines[0] || 'Autonomy is waiting on operator action before it can advance blocked work.';
    }
    if (overviewStallRecoveryBadge) {
        overviewStallRecoveryBadge.className = outboxOpen > 0 ? 'status-pill status-pill-warn' : 'status-pill status-pill-neutral';
        overviewStallRecoveryBadge.textContent = outboxOpen > 0 ? `${outboxOpen} outbox open` : `${blockedBranches} blocked`;
    }
    if (overviewStallRecoveryBox) {
        overviewStallRecoveryBox.textContent = [
            'Use these controls to unblock autonomy without hunting through tabs.',
            '',
            ...lines,
            '',
            'Operator Deck path: Operations → Operator Deck → Operator Outbox.',
            'Queue path: Sessions → Parity Runs → Run Next Queue Item.',
        ].join('\n');
    }
    const dismissBtn = document.getElementById('btnStallDismissOutbox');
    const queueBtn = document.getElementById('btnStallRunQueueNext');
    if (dismissBtn) dismissBtn.style.display = outboxOpen > 0 ? '' : 'none';
    if (queueBtn) queueBtn.style.display = queueOpen > 0 ? '' : 'none';
}

function renderOverviewFocus(status) {
    if (!overviewFocusStrip) return;
    if (!status) {
        overviewFocusStrip.innerHTML = '<div class="overview-focus-card overview-focus-card-wide"><div class="overview-focus-key">Live Focus</div><div class="overview-focus-value">Focus strip will populate after live status lands.</div></div>';
        return;
    }
    const alerts = Array.isArray(status.alerts) ? status.alerts : [];
    const route = String(status.last_planner_decision || 'n/a');
    const routeSummary = compactRouteSummary(status.last_route_summary || 'route lane not available');
    const selected = selectedSession();
    const centerTarget = recommendedCenterTab(status);
    const inspectorTarget = recommendedInspectorTab(status, selected);
    const operatorAttention = status && status.operator_attention && typeof status.operator_attention === 'object'
        ? status.operator_attention
        : {};
    const attentionActive = Boolean((status && status.operator_attention_active) || operatorAttention.active);
    const attentionMessage = String((status && status.operator_attention_message) || operatorAttention.message || '').trim();
    const queueOpen = Number(status.generated_work_queue_open_count != null ? status.generated_work_queue_open_count : 0);
    const queueNext = shortArtifactName(status.generated_work_queue_next_file || '');
    const memory = memoryHealthDetails(status);
    const heartbeatAge = Number((status.runtime_summary && status.runtime_summary.core && status.runtime_summary.core.heartbeat_age_sec != null)
        ? status.runtime_summary.core.heartbeat_age_sec
        : (status.heartbeat_age_sec != null ? status.heartbeat_age_sec : 0));
    const focusCards = [
        {
            key: 'Route Lock',
            value: `${route}\n${routeSummary}`,
        },
        {
            key: 'Runtime Posture',
            value: alerts.length
                ? `${status.health_score}/100\n${alerts.length} alert${alerts.length === 1 ? '' : 's'} | mem ${memory.status}`
                : `${status.health_score}/100\nhb ${heartbeatAge.toFixed(1)}s | mem ${memory.status}`,
        },
        {
            key: 'Standing Queue',
            value: queueOpen > 0 ? `${queueOpen} open\nnext ${queueNext}` : 'queue clear\nno open item',
        },
        {
            key: 'Operator Focus',
            value: attentionActive && attentionMessage
                ? `Needs Help\n${attentionMessage}`
                : (operatorOutboxOpenCount(status) > 0
                    ? `Outbox Hold\n${operatorOutboxOpenCount(status)} open notice${operatorOutboxOpenCount(status) === 1 ? '' : 's'}`
                    : `${centerTarget.label}\n${centerTarget.why}`),
            actions: operatorOutboxOpenCount(status) > 0
                ? [
                    {label: 'Operator Deck', view: 'operations', layerTab: 'operator-deck'},
                    {label: 'Blocked Tree', view: 'scheduled-tree', workTreeMode: 'blocked'},
                ]
                : [
                    {label: centerTarget.label, center: centerTarget.tab},
                    {label: inspectorTarget.label, inspector: inspectorTarget.tab},
                ],
        },
    ];
    overviewFocusStrip.innerHTML = focusCards.map((card) => [
        `<div class="overview-focus-card${card.wide ? ' overview-focus-card-wide' : ''}">`,
        `<div class="overview-focus-key">${escapeHtml(card.key)}</div>`,
        `<div class="overview-focus-value">${escapeHtml(card.value)}</div>`,
        Array.isArray(card.actions) && card.actions.length ? [
            '<div class="overview-focus-actions">',
            card.actions.map((action) => `<button type="button" class="focus-jump-button"${action.center ? ` data-focus-center-tab="${escapeHtml(action.center)}"` : ''}${action.inspector ? ` data-focus-inspector-tab="${escapeHtml(action.inspector)}"` : ''}${action.view ? ` data-focus-view="${escapeHtml(action.view)}"` : ''}${action.layerTab ? ` data-focus-layer-tab="${escapeHtml(action.layerTab)}"` : ''}${action.workTreeMode ? ` data-focus-work-tree-mode="${escapeHtml(action.workTreeMode)}"` : ''}>${escapeHtml(action.label)}</button>`).join(''),
            '</div>'
        ].join('') : '',
        '</div>'
    ].join('')).join('');
}

function missionArray(primary, fallback) {
    if (Array.isArray(primary)) return primary;
    if (Array.isArray(fallback)) return fallback;
    return [];
}

function missionBlockerLine(item) {
    if (!item || typeof item !== 'object') return String(item || '').trim();
    const owner = String(item.owner || '').trim();
    const code = String(item.code || '').trim();
    const detail = String(item.detail || '').trim();
    const prefix = owner && code ? `${owner}:${code}` : (code || owner || 'unknown');
    return detail ? `${prefix} - ${detail}` : prefix;
}

function missionVerdictLine(item) {
    if (!item || typeof item !== 'object') return '';
    const owner = String(item.owner || 'unknown').trim();
    const ready = Boolean(item.ready);
    const blocksGreen = item.blocks_green !== false;
    const summary = String(item.summary || '').trim();
    const status = ready ? 'ready' : 'blocked';
    const gate = blocksGreen ? 'blocks green' : 'pressure only';
    return summary ? `${owner}: ${status} / ${gate}\n${summary}` : `${owner}: ${status} / ${gate}`;
}

function missionOwnerPressureText(ownerBlockers, ownerVerdicts) {
    const verdictByOwner = new Map();
    ownerVerdicts.forEach((item) => {
        if (!item || typeof item !== 'object') return;
        const owner = String(item.owner || '').trim();
        if (owner) verdictByOwner.set(owner, item);
    });
    const blocking = [];
    const pressureOnly = [];
    ownerBlockers.forEach((item) => {
        const line = missionBlockerLine(item);
        if (!line) return;
        const owner = item && typeof item === 'object' ? String(item.owner || '').trim() : '';
        const verdict = verdictByOwner.get(owner) || {};
        if (verdict.blocks_green === false) {
            pressureOnly.push(line);
        } else {
            blocking.push(line);
        }
    });
    const parts = [];
    if (pressureOnly.length) parts.push(`pressure only\n${pressureOnly.slice(0, 4).join('\n')}`);
    if (blocking.length) parts.push(`green blockers\n${blocking.slice(0, 4).join('\n')}`);
    return parts.join('\n') || 'no owner pressure';
}

function renderCenterMissionBrief(status) {
    if (!centerMissionBrief) return;
    if (!status) {
        centerMissionBrief.innerHTML = '<div class="center-brief-card center-brief-card-wide"><div class="center-brief-key">Standby</div><div class="center-brief-value">Mission brief will populate after live status lands.</div></div>';
        return;
    }
    const alerts = Array.isArray(status.alerts) ? status.alerts : [];
    const selected = selectedSession();
    const centerTarget = recommendedCenterTab(status);
    const inspectorTarget = recommendedInspectorTab(status, selected);
    const queueOpen = Number(status.generated_work_queue_open_count != null ? status.generated_work_queue_open_count : 0);
    const queueNext = shortArtifactName(status.generated_work_queue_next_file || '');
    const sessions = Number(status.active_http_sessions != null ? status.active_http_sessions : 0);
    const route = String(status.last_planner_decision || 'n/a');
    const tool = String(status.last_action_tool || 'no tool');
    const routeSummary = compactRouteSummary(status.last_route_summary || 'route lane not available', 5);
    const memory = memoryHealthDetails(status);
    const mission = status.nova_mission && typeof status.nova_mission === 'object' ? status.nova_mission : {};
    const missionStatus = String(mission.status || status.nova_mission_status || 'unknown');
    const missionAction = String(mission.action || status.nova_mission_action || 'n/a');
    const missionHeadline = String(mission.headline || status.nova_mission_headline || 'mission brief pending');
    const truthBlockers = missionArray(mission.truth_blockers, status.nova_mission_truth_blockers);
    const ownerVerdicts = missionArray(mission.owner_verdicts, status.nova_mission_owner_verdicts).filter((item) => item && typeof item === 'object');
    const ownerBlockers = missionArray(mission.owner_blockers, status.nova_mission_owner_blockers);
    const greenBlockers = missionArray(mission.green_blockers, status.nova_mission_green_blockers);
    const ownerVerdictLines = ownerVerdicts.map(missionVerdictLine).filter(Boolean);
    const greenBlockerLines = greenBlockers.map(missionBlockerLine).filter(Boolean);
    const coreThinningSync = status.core_thinning_sync && typeof status.core_thinning_sync === 'object' ? status.core_thinning_sync : {};
    const coreThinningStatus = String(status.core_thinning_sync_status || coreThinningSync.status || 'unknown');
    const coreThinningOrders = Number(status.core_thinning_order_count != null ? status.core_thinning_order_count : (coreThinningSync.order_count || 0));
    const coreThinningAdded = Number(status.core_thinning_added_count != null ? status.core_thinning_added_count : (coreThinningSync.added_count || 0));
    const coreThinningResolved = Number(status.core_thinning_resolved_count != null ? status.core_thinning_resolved_count : (coreThinningSync.resolved_count || 0));
    const coreThinningAt = String(status.core_thinning_sync_at || coreThinningSync.ts || 'n/a');
    const sustainedWatch = Boolean(status.nova_mission_sustained_watch);
    const watchStreak = Number(status.nova_mission_watch_streak != null ? status.nova_mission_watch_streak : 0);
    const truthGateValue = truthBlockers.length || greenBlockerLines.length
        ? [
            truthBlockers.length ? `truth: ${truthBlockers.join(', ')}` : 'truth blockers: none',
            greenBlockerLines.length ? `green blockers\n${greenBlockerLines.slice(0, 4).join('\n')}` : '',
        ].filter(Boolean).join('\n')
        : `ready\ngreen=${Boolean(mission.green_cycle || status.nova_mission_green_cycle)}`;
    const briefCards = [
        {
            key: 'Mission',
            value: `${missionStatus} / ${missionAction}\n${missionHeadline}`,
            wide: true,
        },
        {
            key: 'Truth Gate',
            value: truthGateValue,
        },
        {
            key: 'Owner Pressure',
            value: missionOwnerPressureText(ownerBlockers, ownerVerdicts),
        },
        {
            key: 'Core Thinning Sync',
            value: `${coreThinningStatus}\norders=${coreThinningOrders} added=${coreThinningAdded} resolved=${coreThinningResolved}\n${coreThinningAt}`,
        },
        {
            key: 'Owner Verdicts',
            value: ownerVerdictLines.length ? ownerVerdictLines.slice(0, 5).join('\n') : 'owner verdicts pending',
            wide: true,
        },
        {
            key: 'Mission Watch',
            value: sustainedWatch
                ? `sustained watch\nstreak=${watchStreak}`
                : (watchStreak > 0 ? `watch streak=${watchStreak}` : 'no sustained watch'),
        },
        {
            key: 'Risk Posture',
            value: alerts.length
                ? `${status.health_score}/100\n${alerts.join('\n')}\nmem ${memory.status}`
                : `${status.health_score}/100\nno active alerts\nmem ${memory.status}`,
        },
        {
            key: 'Operator Load',
            value: `${sessions} live session${sessions === 1 ? '' : 's'}\nqueue ${queueOpen > 0 ? `${queueOpen} open / ${queueNext}` : 'clear'}`,
        },
        {
            key: 'Route Chain',
            value: `${route}\n${tool}\n${routeSummary}`,
            wide: true,
        },
        {
            key: 'Recommended Surface',
            value: `${centerTarget.label}\n${centerTarget.why}`,
            actions: [
                {label: `Open ${centerTarget.label}`, center: centerTarget.tab},
                {label: `Lens ${inspectorTarget.label}`, inspector: inspectorTarget.tab},
            ],
            wide: true,
        },
    ];
    centerMissionBrief.innerHTML = briefCards.map((card) => [
        `<div class="center-brief-card${card.wide ? ' center-brief-card-wide' : ''}">`,
        `<div class="center-brief-key">${escapeHtml(card.key)}</div>`,
        `<div class="center-brief-value">${escapeHtml(card.value)}</div>`,
        Array.isArray(card.actions) && card.actions.length ? [
            '<div class="center-brief-actions">',
            card.actions.map((action) => `<button type="button" class="focus-jump-button"${action.center ? ` data-focus-center-tab="${escapeHtml(action.center)}"` : ''}${action.inspector ? ` data-focus-inspector-tab="${escapeHtml(action.inspector)}"` : ''}>${escapeHtml(action.label)}</button>`).join(''),
            '</div>'
        ].join('') : '',
        '</div>'
    ].join('')).join('');
}

function setButtonReadiness(buttonId, readiness) {
    const button = document.getElementById(buttonId);
    if (!button) return;
    const enabled = Boolean(readiness && readiness.enabled);
    const reason = String(readiness && readiness.reason ? readiness.reason : '');
    button.disabled = !enabled;
    button.title = reason;
}

function renderActionReadiness(status) {
    const readiness = status && status.action_readiness ? status.action_readiness : {};
    renderInspectorList(runtimeActionReadiness, [
        {label: 'Guard Start', value: `${readiness.guard_start && readiness.guard_start.enabled ? 'Enabled' : 'Disabled'} - ${readiness.guard_start && readiness.guard_start.reason ? readiness.guard_start.reason : 'n/a'}`},
        {label: 'Guard Stop', value: `${readiness.guard_stop && readiness.guard_stop.enabled ? 'Enabled' : 'Disabled'} - ${readiness.guard_stop && readiness.guard_stop.reason ? readiness.guard_stop.reason : 'n/a'}`},
        {label: 'Guard Restart', value: `${readiness.guard_restart && readiness.guard_restart.enabled ? 'Enabled' : 'Disabled'} - ${readiness.guard_restart && readiness.guard_restart.reason ? readiness.guard_restart.reason : 'n/a'}`},
        {label: 'Core Start', value: `${readiness.nova_start && readiness.nova_start.enabled ? 'Enabled' : 'Disabled'} - ${readiness.nova_start && readiness.nova_start.reason ? readiness.nova_start.reason : 'n/a'}`},
        {label: 'Core Stop', value: `${readiness.core_stop && readiness.core_stop.enabled ? 'Enabled' : 'Disabled'} - ${readiness.core_stop && readiness.core_stop.reason ? readiness.core_stop.reason : 'n/a'}`},
        {label: 'Core Restart', value: `${readiness.core_restart && readiness.core_restart.enabled ? 'Enabled' : 'Disabled'} - ${readiness.core_restart && readiness.core_restart.reason ? readiness.core_restart.reason : 'n/a'}`},
        {label: 'Web UI Restart', value: `${readiness.webui_restart && readiness.webui_restart.enabled ? 'Enabled' : 'Disabled'} - ${readiness.webui_restart && readiness.webui_restart.reason ? readiness.webui_restart.reason : 'n/a'}`},
    ]);

    setButtonReadiness('btnGuardStart', readiness.guard_start);
    setButtonReadiness('btnGuardStop', readiness.guard_stop);
    setButtonReadiness('btnGuardRestart', readiness.guard_restart);
    setButtonReadiness('btnNovaStart', readiness.nova_start);
    setButtonReadiness('btnCoreStart', readiness.nova_start);
    setButtonReadiness('btnCoreStop', readiness.core_stop);
    setButtonReadiness('btnCoreRestart', readiness.core_restart);
    setButtonReadiness('btnWebuiRestart', readiness.webui_restart);
}

function registerRuntimeInspectPayload(payload) {
    runtimeInspectSeq += 1;
    const key = `runtime-${runtimeInspectSeq}`;
    runtimeInspectCache.set(key, payload || {});
    return key;
}

function runtimeBadgeClassForStatus(statusText) {
    const low = String(statusText || '').trim().toLowerCase();
    if (!low || low === 'stopped') return 'status-pill status-pill-neutral';
    if (['running', 'healthy', 'ok'].includes(low)) return 'status-pill status-pill-good';
    if (low === 'heartbeat_only') return 'status-pill status-pill-blue';
    if (low === 'starting' || low === 'stopping') return 'status-pill status-pill-warn';
    if (low === 'heartbeat_stale' || low === 'boot_timeout' || low === 'stale_identity') return 'status-pill status-pill-danger';
    if (
        low.includes('starting') ||
        low.includes('boot') ||
        low.includes('restart') ||
        low.includes('stopping') ||
        low.includes('resolving') ||
        low.includes('wait')
    ) {
        return 'status-pill status-pill-warn';
    }
    if (
        low.includes('stale') ||
        low.includes('fail') ||
        low.includes('error') ||
        low.includes('dead') ||
        low.includes('timeout') ||
        low.includes('missing') ||
        low.includes('orphan')
    ) {
        return 'status-pill status-pill-danger';
    }
    return 'status-pill status-pill-blue';
}

function runtimeStatusLabel(payload) {
    return String(payload && payload.status ? payload.status : (payload && payload.running ? 'running' : 'stopped'));
}

function runtimeSummaryRows(status) {
    const summary = status && status.runtime_summary ? status.runtime_summary : {};
    const guard = summary.guard || (status && status.guard) || {};
    const core = summary.core || (status && status.core) || {};
    const webui = summary.webui || (status && status.webui) || {};
    return [
        {
            label: 'Guard',
            status: runtimeStatusLabel(guard),
            badgeClass: runtimeBadgeClassForStatus(runtimeStatusLabel(guard)),
            raw: guard,
            details: [
                {key: 'PID', value: guard.pid != null ? String(guard.pid) : '-'},
                {key: 'Process Count', value: guard.process_count != null ? String(guard.process_count) : '0'},
                {key: 'Lock File', value: guard.lock_exists ? 'present' : 'missing'},
                {key: 'Stop Flag', value: guard.stop_flag ? 'present' : 'clear'},
            ],
            value: `${runtimeStatusLabel(guard)} | pid=${guard.pid != null ? guard.pid : '-'} | count=${guard.process_count != null ? guard.process_count : 0} | lock=${guard.lock_exists ? 'yes' : 'no'} | stop=${guard.stop_flag ? 'yes' : 'no'}`,
        },
        {
            label: 'Core',
            status: runtimeStatusLabel(core),
            badgeClass: runtimeBadgeClassForStatus(runtimeStatusLabel(core)),
            raw: core,
            details: [
                {key: 'PID', value: core.pid != null ? String(core.pid) : '-'},
                {key: 'Process Count', value: core.process_count != null ? String(core.process_count) : '0'},
                {key: 'Heartbeat Age', value: core.heartbeat_age_sec != null ? `${core.heartbeat_age_sec}s` : '-'},
                {key: 'State File', value: core.state_exists === false ? 'missing' : 'present or n/a'},
            ],
            value: `${runtimeStatusLabel(core)} | pid=${core.pid != null ? core.pid : '-'} | count=${core.process_count != null ? core.process_count : 0} | hb_age=${core.heartbeat_age_sec != null ? core.heartbeat_age_sec + 's' : '-'}`,
        },
        {
            label: 'Web UI',
            status: runtimeStatusLabel(webui),
            badgeClass: runtimeBadgeClassForStatus(runtimeStatusLabel(webui)),
            raw: webui,
            details: [
                {key: 'PID', value: webui.pid != null ? String(webui.pid) : '-'},
                {key: 'Process Count', value: webui.process_count != null ? String(webui.process_count) : '0'},
                {key: 'Host', value: webui.host ? String(webui.host) : 'n/a'},
                {key: 'Port', value: webui.port != null ? String(webui.port) : 'n/a'},
            ],
            value: `${runtimeStatusLabel(webui)} | pid=${webui.pid != null ? webui.pid : '-'} | count=${webui.process_count != null ? webui.process_count : 0}`,
        },
    ];
}

function formatRuntimeRawFields(title, payload) {
    return [
        `${title}`,
        '',
        JSON.stringify(payload || {}, null, 2),
    ].join('\n');
}

function selectRuntimeInspectButton(group, inspectKey) {
    document.querySelectorAll(`[data-runtime-group="${group}"]`).forEach((button) => {
        const active = (button.getAttribute('data-runtime-key') || '') === inspectKey;
        button.setAttribute('aria-pressed', active ? 'true' : 'false');
        const card = button.closest('.runtime-card');
        if (card) card.classList.toggle('is-active', active);
    });
}

function showRuntimeInspect(targetId, title, inspectKey, group) {
    const target = document.getElementById(targetId);
    if (!target) return;
    target.textContent = formatRuntimeRawFields(title, runtimeInspectCache.get(inspectKey) || {});
    selectRuntimeInspectButton(group, inspectKey);
}

function renderRuntimeCards(container, rawBox, rows, group) {
    if (!container) return;
    container.className = 'runtime-summary-grid';
    container.innerHTML = rows.map((item) => {
        const inspectKey = registerRuntimeInspectPayload(item.raw || {});
        return [
            '<div class="runtime-card">',
            '<div class="runtime-card-header">',
            `<div class="runtime-card-label">${escapeHtml(item.label)}</div>`,
            `<button type="button" class="${escapeHtml(item.badgeClass)} runtime-badge-button" data-runtime-group="${escapeHtml(group)}" data-runtime-key="${escapeHtml(inspectKey)}" data-runtime-target="${escapeHtml(rawBox ? rawBox.id : '')}" data-runtime-title="${escapeHtml(item.label + ' Raw Fields')}">${escapeHtml(item.status)}</button>`,
            '</div>',
            '<div class="runtime-card-details">',
            (Array.isArray(item.details) ? item.details : []).map((detail) => [
                '<div class="runtime-detail-row">',
                `<div class="runtime-detail-key">${escapeHtml(detail.key || '')}</div>`,
                `<div class="runtime-detail-value">${escapeHtml(detail.value || '')}</div>`,
                '</div>'
            ].join('')).join(''),
            '</div>',
            '</div>'
        ].join('');
    }).join('');
    if (rawBox && rows.length) {
        const firstButton = container.querySelector('.runtime-badge-button');
        if (firstButton) {
            showRuntimeInspect(
                firstButton.getAttribute('data-runtime-target') || rawBox.id,
                firstButton.getAttribute('data-runtime-title') || 'Runtime Raw Fields',
                firstButton.getAttribute('data-runtime-key') || '',
                group,
            );
        }
    }
}

function renderRuntimeSummary(status) {
    renderRuntimeCards(runtimeSummary, runtimeRawBox, runtimeSummaryRows(status), 'health-runtime');
}

function formatRuntimeConsole(status) {
    return runtimeSummaryRows(status).map((item) => `${item.label}: ${item.value}`).join('\n');
}

function renderGuardRuntime(status) {
    renderRuntimeCards(guardBox, guardRawBox, runtimeSummaryRows(status), 'guard-runtime');
}

function renderHeroDeck(status) {
    const alerts = status && Array.isArray(status.alerts) ? status.alerts : [];
    const numericScore = Number(status && status.health_score != null ? status.health_score : 0);
    const ratio = Math.max(0, Math.min(100, Math.round(Number(status && status.self_check_pass_ratio != null ? status.self_check_pass_ratio : 0) * 100)));
    if (heroHealthSummary) {
        heroHealthSummary.textContent = alerts.length
            ? `Health ${numericScore}/100 at ${ratio}% pass with ${alerts.length} alert${alerts.length === 1 ? '' : 's'}`
            : `Health ${numericScore}/100 with ${ratio}% pass and no active alerts`;
    }
    renderHeroMeta(heroHealthMeta, [
        {value: `${ratio}% pass`},
        alerts.length ? {value: `${alerts.length} alert${alerts.length === 1 ? '' : 's'}`, tone: alerts.length > 1 ? 'danger' : 'warn'} : {value: 'alerts clear'},
    ]);
    if (heroRouteSummary) {
        const route = status && status.last_planner_decision ? status.last_planner_decision : 'planner decision pending';
        const summary = status && status.last_route_summary ? status.last_route_summary : 'route lane not available';
        const tool = status && status.last_action_tool ? status.last_action_tool : 'no tool used';
        const compactSummary = compactRouteSummary(summary);
        heroRouteSummary.textContent = `${route} | ${compactSummary} | ${tool}`;
        renderHeroMeta(heroRouteMeta, [
            {value: route},
            {value: tool || 'no tool'},
        ]);
    }
    if (heroOpsSummary) {
        const sessions = Number(status && status.active_http_sessions != null ? status.active_http_sessions : 0);
        const provider = status && status.search_provider ? status.search_provider : 'n/a';
        const scope = status && status.memory_scope ? status.memory_scope : 'private';
        const processMode = status && status.process_counting_mode ? status.process_counting_mode : 'n/a';
        heroOpsSummary.textContent = `${sessions} live session${sessions === 1 ? '' : 's'} | ${provider} search | ${scope} memory | ${processMode}`;
        renderHeroMeta(heroOpsMeta, [
            {value: `${sessions} live`},
            {value: provider},
            {value: scope},
        ]);
    }
}

function renderSessionPreview() {
    const session = selectedSession();
    if (!sessionBox) return;
    if (!session) {
        sessionBox.textContent = 'Session focus pending.';
        if (sessionProbeBox) sessionProbeBox.textContent = 'Probe trace pending.';
        renderSessionState(null);
        renderSupervisorInspector(null, latestStatus);
        renderOverrideBadges(null);
        renderOverviewFocus(latestStatus);
        renderCenterMissionBrief(latestStatus);
        return;
    }
    const reflection = session.reflection || {};
    const probeResults = Array.isArray(reflection.probe_results) ? reflection.probe_results : [];
    const suggestions = Array.isArray(reflection.suggestions) ? reflection.suggestions : [];
    sessionBox.textContent = [
        `Session: ${session.session_id}`,
        `Owner: ${session.owner || '(none)'}`,
        `Turns: ${session.turn_count}`,
        '',
        'Last user:',
        session.last_user || '(none)',
        '',
        'Last assistant:',
        session.last_assistant || '(none)',
    ].join('\n');
    if (sessionProbeBox) {
        sessionProbeBox.textContent = [
            `Probe summary: ${reflection.probe_summary || 'All green'}`,
            '',
            'Findings:',
            probeResults.length ? probeResults.join('\n') : 'No supervisor issues detected.',
            '',
            'Suggestions:',
            suggestions.length ? suggestions.join('\n') : 'None',
        ].join('\n');
    }
    renderSessionState(session);
    renderSupervisorInspector(session, latestStatus);
    renderOverrideBadges(session);
    renderOverviewFocus(latestStatus);
    renderCenterMissionBrief(latestStatus);
}

function renderSessions() {
    const previous = sessionSelect ? (sessionSelect.value || '').trim() : '';
    if (!sessionSelect) return;
    const available = filteredSessions();
    sessionSelect.innerHTML = '';
    if (!available.length) {
        const option = document.createElement('option');
        option.value = '';
        option.textContent = '(no live sessions)';
        sessionSelect.appendChild(option);
        renderSessionPreview();
        return;
    }
    available.forEach((session) => {
        const option = document.createElement('option');
        option.value = session.session_id;
        option.textContent = `${session.session_id} (${session.turn_count} turns)${String(session.owner || '').trim() ? ' | ' + session.owner : ''}`;
        sessionSelect.appendChild(option);
    });
    if (previous && available.some((session) => session.session_id === previous)) {
        sessionSelect.value = previous;
    }
    renderSessionPreview();
}

function renderTestRunPreview() {
    const run = selectedTestRun();
    if (!testRunBox || !testRunProbeBox || !testRunDriftGrid) return;
    if (!run) {
        testRunBox.textContent = 'Parity run focus pending.';
        testRunProbeBox.textContent = 'Parity trace pending.';
        testRunDriftGrid.textContent = 'Drift view pending.';
        return;
    }

    const comparison = run.comparison || {};
    const diffs = Array.isArray(comparison.diffs) ? comparison.diffs : [];
    const leftMode = String(comparison.left_mode || 'cli');
    const rightMode = String(comparison.right_mode || 'http');
    const leftLabel = String(comparison.left_label || 'CLI');
    const rightLabel = String(comparison.right_label || 'HTTP');
    const leftTurns = Number(comparison.left_turns != null ? comparison.left_turns : comparison.cli_turns || 0);
    const rightTurns = Number(comparison.right_turns != null ? comparison.right_turns : comparison.http_turns || 0);
    const leftFlagged = Array.isArray(comparison.left_flagged_probes)
        ? comparison.left_flagged_probes
        : (Array.isArray(comparison.cli_flagged_probes) ? comparison.cli_flagged_probes : []);
    const rightFlagged = Array.isArray(comparison.right_flagged_probes)
        ? comparison.right_flagged_probes
        : (Array.isArray(comparison.http_flagged_probes) ? comparison.http_flagged_probes : []);
    const diffLines = diffs.length
        ? diffs.map((item) => {
            const fields = Object.keys(item.issues || {});
            return `Turn ${item.turn}: ${fields.length ? fields.join(', ') : 'difference detected'}`;
        })
        : ['None'];

    testRunBox.textContent = [
        `Run: ${run.run_id}`,
        `Session: ${run.session_name || '(unknown)'}`,
        `Generated: ${run.generated_at || '(unknown)'}`,
        `Source: ${run.session_path || '(unknown)'}`,
        `Messages: ${run.message_count || 0}`,
        `${leftLabel} turns / ${rightLabel} turns: ${leftTurns} / ${rightTurns}`,
        `Turn count parity: ${comparison.turn_count_match ? 'OK' : 'MISMATCH'}`,
        `Drift count: ${comparison.diff_count || 0}`,
        `Flagged probes: ${comparison.flagged_probe_count || 0}`,
        `Report: ${run.report_path || ''}`,
        '',
        'Drift details:',
        diffLines.join('\n'),
    ].join('\n');

    const formatProbeRows = (label, rows) => {
        if (!rows.length) return `${label}: none`;
        return `${label}:\n` + rows.map((row) => `- Turn ${row.turn}: ${(row.lines || []).join(' | ') || 'flagged'}`).join('\n');
    };

    testRunProbeBox.textContent = [
        `Runner status: ${testRunStatusLabel(run)}`,
        '',
        formatProbeRows(`${leftLabel} flagged probes`, leftFlagged),
        '',
        formatProbeRows(`${rightLabel} flagged probes`, rightFlagged),
    ].join('\n');

    if (diffs.length) {
        testRunDriftGrid.className = 'drift-grid';
        testRunDriftGrid.innerHTML = diffs.map((item) => {
            const issues = item.issues || {};
            const fields = Object.keys(issues);
            const rows = fields.map((fieldName) => {
                const values = issues[fieldName] || {};
                const leftValue = values[leftMode] != null ? values[leftMode] : values.left;
                const rightValue = values[rightMode] != null ? values[rightMode] : values.right;
                return [
                    '<div class="drift-field">',
                    `<div class="inspector-key">${escapeHtml(fieldName)}</div>`,
                    `<div class="inspector-value">${escapeHtml(leftLabel)}: ${escapeHtml(leftValue != null ? leftValue : '')}</div>`,
                    `<div class="inspector-value">${escapeHtml(rightLabel)}: ${escapeHtml(rightValue != null ? rightValue : '')}</div>`,
                    '</div>'
                ].join('');
            }).join('');
            return [
                '<div class="drift-card drift-danger">',
                '<div class="drift-card-header">',
                `<div class="section-title">Turn ${escapeHtml(item.turn)}</div>`,
                '<span class="status-pill status-pill-danger">Drift</span>',
                '</div>',
                '<div class="drift-field-list">',
                rows,
                '</div>',
                '</div>'
            ].join('');
        }).join('');
    } else {
        testRunDriftGrid.className = 'drift-grid';
        testRunDriftGrid.innerHTML = '<div class="drift-card drift-good"><div class="drift-card-header"><div class="section-title">Per-Turn Drift</div><span class="status-pill status-pill-good">Clean</span></div><div class="inspector-value">No CLI/HTTP field drift detected for this run.</div></div>';
    }
}

function renderTestRuns() {
    if (!testRunSelect) return;
    const previous = (testRunSelect.value || '').trim();
    testRunSelect.innerHTML = '';
    if (!testRunsCache.length) {
        const option = document.createElement('option');
        option.value = '';
        option.textContent = '(no parity runs)';
        testRunSelect.appendChild(option);
        renderTestRunPreview();
        return;
    }
    testRunsCache.forEach((run) => {
        const option = document.createElement('option');
        option.value = run.run_id;
        option.textContent = `${testRunStatusLabel(run)} | ${run.session_name} | ${run.generated_at || 'unknown time'}`;
        testRunSelect.appendChild(option);
    });
    if (previous && testRunsCache.some((run) => run.run_id === previous)) {
        testRunSelect.value = previous;
    }
    if (testRunBadges) {
        testRunBadges.innerHTML = testRunsCache.slice(0, 6).map((run) => `<span class="${testRunBadgeClass(run)}">${escapeHtml(testRunStatusLabel(run))} ${escapeHtml(run.session_name || run.run_id)}</span>`).join('');
    }
    renderTestRunPreview();
}

function renderTestSessionDefinitions() {
    if (!testSessionDefinitionSelect) return;
    const previous = (testSessionDefinitionSelect.value || '').trim();
    testSessionDefinitionSelect.innerHTML = '';
    if (!testSessionDefinitions.length) {
        const option = document.createElement('option');
        option.value = '';
        option.textContent = '(no saved test sessions)';
        testSessionDefinitionSelect.appendChild(option);
        return;
    }
    testSessionDefinitions.forEach((item) => {
        const option = document.createElement('option');
        option.value = item.file;
        const origin = String(item.origin || 'saved').trim();
        const rationale = origin === 'generated' ? summarizeGeneratedPriority(item) : '';
        option.textContent = `${item.name} (${item.message_count || 0} turns)${origin === 'generated' ? ' | generated' : ''}${rationale ? ' | ' + rationale : ''}`;
        if (rationale) {
            option.title = buildGeneratedPriorityTitle(item);
        }
        testSessionDefinitionSelect.appendChild(option);
    });
    if (previous && testSessionDefinitions.some((item) => item.file === previous)) {
        testSessionDefinitionSelect.value = previous;
    }
}

function realWorldTaskDefinitions() {
    return testSessionDefinitions.filter((item) => String(item && item.source ? item.source : '').trim() === 'real_world' || String(item && item.file ? item.file : '').includes('real_world/'));
}

function selectedRealWorldTask() {
    const selected = taskManagerSelect ? String(taskManagerSelect.value || '').trim() : '';
    return realWorldTaskDefinitions().find((item) => String(item.file || '').trim() === selected) || null;
}

function renderRealWorldTaskPreview() {
    if (!taskManagerPreview) return;
    const task = selectedRealWorldTask();
    if (!task) {
        taskManagerPreview.textContent = 'No real-world task selected.';
        return;
    }
    const lines = [
        `Name: ${task.name || task.file || 'task'}`,
        `File: ${task.file || 'n/a'}`,
        `Category: ${task.category || 'operator'}`,
        `Turns: ${task.message_count != null ? task.message_count : 'n/a'}`,
        `Origin: ${task.origin || 'saved'}`,
    ];
    if (task.task_id) lines.push(`Task ID: ${task.task_id}`);
    if (task.objective) lines.push(`Objective: ${task.objective}`);
    taskManagerPreview.textContent = lines.join('\n');
}

function renderRealWorldTasks() {
    if (!taskManagerSelect) return;
    const previous = String(taskManagerSelect.value || '').trim();
    const tasks = realWorldTaskDefinitions();
    taskManagerSelect.innerHTML = '';
    if (!tasks.length) {
        const option = document.createElement('option');
        option.value = '';
        option.textContent = '(no real-world tasks)';
        taskManagerSelect.appendChild(option);
        renderRealWorldTaskPreview();
        return;
    }
    tasks.forEach((item) => {
        const option = document.createElement('option');
        option.value = item.file;
        const category = String(item.category || 'operator').trim();
        option.textContent = `${item.name || item.file} | ${category} | ${item.message_count || 0} turns`;
        taskManagerSelect.appendChild(option);
    });
    if (previous && tasks.some((item) => item.file === previous)) {
        taskManagerSelect.value = previous;
    }
    renderRealWorldTaskPreview();
}

function workTreeStatusClass(status) {
    const low = String(status || '').trim().toLowerCase();
    if (low === 'active') return 'status-pill status-pill-good';
    if (low === 'ready') return 'status-pill status-pill-blue';
    if (low === 'blocked') return 'status-pill status-pill-warn';
    if (low === 'dropped') return 'status-pill status-pill-danger';
    return 'status-pill status-pill-neutral';
}

function workTreeStatusColor(status) {
    const low = String(status || '').trim().toLowerCase();
    if (low === 'active') return '#27c46b';
    if (low === 'ready') return '#53bdf8';
    if (low === 'blocked') return '#ffb347';
    if (low === 'dropped') return '#f05b57';
    if (low === 'archived') return '#7f8fa3';
    return '#c7d4e4';
}

function selectedWorkTree() {
    return workTreesCache.find((tree) => String(tree && tree.tree_id ? tree.tree_id : '') === selectedWorkTreeId) || null;
}

function selectedWorkTreeNode(tree) {
    if (!tree || !Array.isArray(tree.nodes)) return null;
    if (selectedWorkTreeNodeId) {
        const existing = tree.nodes.find((node) => String(node && node.id ? node.id : '') === selectedWorkTreeNodeId);
        if (existing) return existing;
    }
    const activeNode = tree.nodes.find((node) => String(node && node.status ? node.status : '').toLowerCase() === 'active');
    if (activeNode) return activeNode;
    return tree.nodes[0] || null;
}

function preferredWorkTreeId(trees) {
    const safeTrees = Array.isArray(trees) ? trees.filter((tree) => tree && typeof tree === 'object') : [];
    if (selectedWorkTreeId && safeTrees.some((tree) => String(tree.tree_id || '') === selectedWorkTreeId)) {
        return selectedWorkTreeId;
    }
    const active = safeTrees.find((tree) => String(tree.active_branch_id || '').trim());
    if (active) return String(active.tree_id || '');
    const rich = safeTrees.find((tree) => Array.isArray(tree.nodes) && tree.nodes.length);
    if (rich) return String(rich.tree_id || '');
    return safeTrees.length ? String(safeTrees[0].tree_id || '') : '';
}

function formatWorkTreeLabel(tree) {
    const title = String(tree && tree.title ? tree.title : 'tree').trim() || 'tree';
    const status = String(tree && tree.status ? tree.status : 'unknown').trim().toLowerCase();
    const counts = tree && tree.counts && typeof tree.counts === 'object' ? tree.counts : {};
    const branchCounts = counts && counts.branches && typeof counts.branches === 'object' ? counts.branches : {};
    const branchTotal = Object.values(branchCounts).reduce((sum, value) => sum + Number(value || 0), 0);
    const openTasks = Number(counts.open_tasks || 0);
    return `${title} | tree ${status} | ${branchTotal} total branches | ${openTasks} open tasks`;
}

function renderWorkTreeSelect() {
    if (!workTreeSelect) return;
    const previous = String(workTreeSelect.value || '').trim();
    workTreeSelect.innerHTML = '';
    if (!workTreesCache.length) {
        const option = document.createElement('option');
        option.value = '';
        option.textContent = '(no scheduled trees)';
        workTreeSelect.appendChild(option);
        selectedWorkTreeId = '';
        return;
    }
    workTreesCache.forEach((tree) => {
        const option = document.createElement('option');
        option.value = String(tree.tree_id || '');
        option.textContent = formatWorkTreeLabel(tree);
        workTreeSelect.appendChild(option);
    });
    selectedWorkTreeId = preferredWorkTreeId(workTreesCache);
    if (previous && workTreesCache.some((tree) => String(tree.tree_id || '') === previous)) {
        selectedWorkTreeId = previous;
    }
    workTreeSelect.value = selectedWorkTreeId;
}

function renderWorkTreeViewButtons() {
    const buttons = [
        {id: 'btnWorkTreeViewAll', mode: 'all'},
        {id: 'btnWorkTreeViewActive', mode: 'active'},
        {id: 'btnWorkTreeViewBlocked', mode: 'blocked'},
    ];
    buttons.forEach((item) => {
        const button = document.getElementById(item.id);
        if (!button) return;
        const active = workTreeViewMode === item.mode;
        button.classList.toggle('active', active);
        button.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
}

function setWorkTreeViewMode(mode) {
    const normalized = String(mode || '').trim().toLowerCase();
    workTreeViewMode = ['all', 'active', 'blocked'].includes(normalized) ? normalized : 'all';
    renderWorkTreeViewButtons();
    renderSelectedWorkTreeView();
}

function workTreeNodeVisibleInMode(node) {
    const status = String(node && node.status ? node.status : '').trim().toLowerCase();
    if (workTreeViewMode === 'active') {
        return ['active', 'open', 'pending', 'ready'].includes(status);
    }
    if (workTreeViewMode === 'blocked') {
        return ['blocked', 'observing'].includes(status);
    }
    return true;
}

function renderWorkTreeAggregateSummary(payload) {
    const counts = payload && payload.counts && typeof payload.counts === 'object' ? payload.counts : {};
    const total = Number(counts.total || workTreesCache.length || 0);
    const active = Number(counts.active || 0);
    const branches = Number(counts.branches || 0);
    const openTasks = Number(counts.open_tasks || 0);
    const working = Number(counts.working || 0);
    const pending = Number(counts.pending || 0);
    const blocked = Number(counts.blocked || 0);
    const complete = Number(counts.complete || 0);
    if (workTreeGlobalCounts) {
        workTreeGlobalCounts.innerHTML = [
            '<span class="scheduled-tree-count-label">All Trees</span>',
            `<span class="scheduled-tree-count-pill">${total} trees</span>`,
            `<span class="scheduled-tree-count-pill is-active">${active} active trees</span>`,
            `<span class="scheduled-tree-count-pill">${branches} total branches</span>`,
            `<span class="scheduled-tree-count-pill">${openTasks} open tasks</span>`,
        ].join('');
    }
    if (workTreeLiveSummary) {
        workTreeLiveSummary.innerHTML = [
            '<span class="scheduled-tree-focus-label">Working now</span>',
            `<span class="${escapeHtml(workTreeStatusClass(active ? 'active' : 'complete'))}">${active ? 'active trees present' : 'no active trees'}</span>`,
            `<span class="scheduled-tree-focus-copy">working ${working} | pending ${pending} | blocked ${blocked} | complete ${complete}</span>`,
        ].join('');
    }
}

function renderSelectedWorkTreeSummary(tree) {
    if (!tree) {
        if (workTreeSelectedCounts) workTreeSelectedCounts.textContent = 'Selected Tree: none selected.';
        if (workTreeSelectedSummary) workTreeSelectedSummary.textContent = 'Selected tree focus: none selected.';
        return;
    }
    const counts = tree && tree.counts && typeof tree.counts === 'object' ? tree.counts : {};
    const branchCounts = counts && counts.branches && typeof counts.branches === 'object' ? counts.branches : {};
    const branchTotal = Object.values(branchCounts).reduce((sum, value) => sum + Number(value || 0), 0);
    const openTasks = Number(counts.open_tasks || 0);
    const nextStep = tree && tree.next_step && typeof tree.next_step === 'object' ? tree.next_step : {};
    const nextAction = String(nextStep.action || '').trim() || 'idle';
    const nextTool = String(nextStep.recommended_tool || '').trim() || 'n/a';
    const activeTitle = String(tree.active_branch_title || '').trim() || 'none';
    if (workTreeSelectedCounts) {
        workTreeSelectedCounts.innerHTML = [
            '<span class="scheduled-tree-count-label">Selected Tree</span>',
            `<span class="${escapeHtml(workTreeStatusClass(tree.status))}">${escapeHtml(String(tree.status || 'unknown').toUpperCase())}</span>`,
            `<span class="scheduled-tree-count-pill">${branchTotal} total branches</span>`,
            `<span class="scheduled-tree-count-pill">${openTasks} open tasks</span>`,
            `<span class="scheduled-tree-count-pill">${Number(branchCounts.active || 0)} working branches</span>`,
            `<span class="scheduled-tree-count-pill">${Number(branchCounts.ready || 0)} ready branches</span>`,
        ].join('');
    }
    if (workTreeSelectedSummary) {
        workTreeSelectedSummary.innerHTML = [
            '<span class="scheduled-tree-focus-label">Selected tree focus</span>',
            `<span class="scheduled-tree-focus-copy">${escapeHtml(String(tree.title || tree.tree_id || 'tree'))}</span>`,
            `<span class="scheduled-tree-focus-copy">active branch: ${escapeHtml(activeTitle)}</span>`,
            `<span class="scheduled-tree-focus-copy">next: ${escapeHtml(nextAction)} | tool: ${escapeHtml(nextTool)}</span>`,
        ].join('');
    }
}

let _inspectorBranchId = null;
let _inspectorBranchStatus = null;

function workTreeSolutionProgress(currentTask, node) {
    // One unit: solution progress. Prefer the richest honest payload
    // (live measure with markers/effort) over a compact/stale percent stamp.
    const candidates = [];
    if (node && typeof node === 'object') {
        if (node.solution_progress && typeof node.solution_progress === 'object') {
            candidates.push(node.solution_progress);
        }
        if (node.progress && typeof node.progress === 'object') {
            candidates.push(node.progress);
        }
    }
    if (currentTask && typeof currentTask === 'object') {
        if (currentTask.progress && typeof currentTask.progress === 'object') {
            candidates.push(currentTask.progress);
        }
        const meta = currentTask.meta && typeof currentTask.meta === 'object' ? currentTask.meta : null;
        if (meta && meta.progress && typeof meta.progress === 'object') {
            candidates.push(meta.progress);
        }
    }
    if (!candidates.length) return null;
    const hasOpen = node && Number(node.tasks_open || 0) > 0;
    const score = (row) => {
        if (!row || typeof row !== 'object') return -999;
        const markers = Array.isArray(row.markers) ? row.markers.length : 0;
        const effort = Array.isArray(row.effort) ? row.effort.length : 0;
        const effortCount = Number(row.effort_count);
        const effortN = Number.isFinite(effortCount) ? effortCount : effort;
        let pct = Number(row.percent);
        if (!Number.isFinite(pct)) pct = 0;
        const motion = String(row.motion || '').toLowerCase();
        const status = String(row.solution_status || '').toLowerCase();
        // Penalize false complete on open nodes.
        let honesty = 0;
        if (hasOpen && (motion === 'done' || pct >= 100 || status === 'complete' || status === 'done')) {
            honesty -= 500;
        }
        // Prefer payloads that can fill "Completed so far".
        return honesty + markers * 10 + effortN * 5 + (effort > 0 ? 20 : 0) + Math.min(pct, 99) * 0.01;
    };
    let best = candidates[0];
    let bestScore = score(best);
    for (let i = 1; i < candidates.length; i += 1) {
        const s = score(candidates[i]);
        if (s > bestScore) {
            best = candidates[i];
            bestScore = s;
        }
    }
    return best;
}

function renderWorkTreeProgressPanel(progress) {
    if (!workTreeProgressPanel) return;
    if (!progress || typeof progress !== 'object') {
        workTreeProgressPanel.classList.add('d-none');
        workTreeProgressPanel.innerHTML = '';
        return;
    }
    const pct = Number(progress.percent);
    let safePct = Number.isFinite(pct) ? Math.max(0, Math.min(100, Math.round(pct))) : 0;
    let motion = String(progress.motion || 'unknown').trim().toLowerCase() || 'unknown';
    const markers = Array.isArray(progress.markers) ? progress.markers : [];
    const effort = Array.isArray(progress.effort) ? progress.effort : [];
    const effortCount = Number(progress.effort_count);
    const effortN = Number.isFinite(effortCount) ? effortCount : effort.length;
    // Never paint "100% done" when Completed so far is empty — that is a cache lie.
    const closedWithoutEffort = Boolean(progress.closed_without_effort) || (safePct >= 100 && effortN <= 0);
    if (closedWithoutEffort && effortN <= 0) {
        safePct = Math.min(safePct, 0);
        if (motion === 'done') {
            // keep motion done if finding closed, but percent is honest zero
        }
    }
    const markerItems = markers.length
        ? markers.map((marker) => {
            const counts = Boolean(marker && (marker.counts != null ? marker.counts : marker.achieved));
            const observed = Boolean(marker && marker.observed);
            const verified = Boolean(marker && marker.verified);
            const contradicted = Boolean(marker && marker.contradicted);
            const conf = marker && marker.confidence != null ? Number(marker.confidence) : null;
            const confText = conf != null && Number.isFinite(conf) ? ` conf ${Math.round(conf * 100)}%` : '';
            let mark = '○';
            let cls = 'is-pending';
            if (contradicted) {
                mark = '✗';
                cls = 'is-pending';
            } else if (counts && verified) {
                mark = '✓';
                cls = 'is-done';
            } else if (counts && observed) {
                mark = '◐';
                cls = 'is-done';
            } else if (observed && !counts) {
                mark = '◌';
                cls = 'is-pending';
            }
            const label = escapeHtml(String((marker && marker.label) || (marker && marker.id) || 'marker'));
            const note = escapeHtml(String((marker && marker.note) || '').trim());
            const quality = escapeHtml(String((marker && marker.quality) || '').trim());
            const extra = [quality, confText.trim()].filter(Boolean).join(' · ');
            return `<li class="${cls}">${mark} ${label}${extra ? ` <span class="text-muted">(${extra})</span>` : ''}${note ? ` <span class="text-muted">— ${note}</span>` : ''}</li>`;
        }).join('')
        : '<li class="is-pending">No solution markers for this family yet.</li>';
    const effortItems = effort.length
        ? effort.map((row) => {
            const when = escapeHtml(String((row && row.created_at) || '').trim() || 'n/a');
            const tool = escapeHtml(String((row && row.tool_name) || 'tool').trim());
            const summary = escapeHtml(String((row && row.summary) || '').trim().replace(/\s+/g, ' ').slice(0, 140));
            return `<li><strong>${when}</strong> · ${tool}${summary ? ` — ${summary}` : ''}</li>`;
        }).join('')
        : (closedWithoutEffort
            ? '<li class="is-pending">Finding closed without recorded tool effort — nothing to list as completed so far.</li>'
            : `<li class="is-pending">No evidence yet.${progress.expected_tool ? ` Next expected tool: <code>${escapeHtml(String(progress.expected_tool))}</code>` : ''}</li>`);
    const formatAge = (sec) => {
        const n = Number(sec);
        if (!Number.isFinite(n) || n < 0) return '';
        if (n < 60) return `${Math.round(n)}s`;
        if (n < 3600) return `${Math.round(n / 60)}m`;
        if (n < 86400) return `${Math.round(n / 3600)}h`;
        return `${Math.round(n / 86400)}d`;
    };
    const formatWhen = (raw, ageSec) => {
        const text = String(raw || '').trim();
        if (!text) return '—';
        const age = formatAge(ageSec);
        return age ? `${text} (${age} ago)` : text;
    };
    const workStartState = String(progress.work_start_state || '').trim().toLowerCase();
    const workStartedLine = workStartState === 'not_started' || !String(progress.work_started_at || '').trim()
        ? 'not started (no tool evidence yet)'
        : formatWhen(progress.work_started_at, progress.work_started_age_sec);
    workTreeProgressPanel.classList.remove('d-none');
    workTreeProgressPanel.innerHTML = [
        '<div class="work-tree-progress-head">',
        `<div class="work-tree-progress-pct-lg">${safePct}%</div>`,
        `<span class="work-tree-progress-motion is-${escapeHtml(motion)}">${escapeHtml(motion.replace(/_/g, ' '))}</span>`,
        `<span class="section-footnote">${escapeHtml(String(
            (closedWithoutEffort && !String(progress.operator_summary || '').includes('without recorded'))
                ? `${safePct}% · closed without recorded tool effort`
                : (progress.operator_summary || '')
        ))}</span>`,
        '</div>',
        `<div class="work-tree-progress-intent"><span class="work-tree-progress-label">Doing</span>${escapeHtml(String(progress.doing || progress.task_title || 'n/a'))}</div>`,
        `<div class="work-tree-progress-intent"><span class="work-tree-progress-label">Intent</span>${escapeHtml(String(progress.intent || 'n/a'))}</div>`,
        `<div class="work-tree-progress-solution"><span class="work-tree-progress-label">Solution</span>${escapeHtml(String(progress.solution || 'n/a'))}</div>`,
        '<div class="work-tree-progress-section-title">Timeline</div>',
        `<div class="work-tree-progress-intent"><span class="work-tree-progress-label">On radar</span>${escapeHtml(formatWhen(progress.surfaced_at, progress.surfaced_age_sec))}</div>`,
        `<div class="work-tree-progress-intent"><span class="work-tree-progress-label">Work started</span>${escapeHtml(workStartedLine)}</div>`,
        `<div class="work-tree-progress-intent"><span class="work-tree-progress-label">This step opened</span>${escapeHtml(formatWhen(progress.current_step_opened_at, progress.current_step_age_sec))}</div>`,
        `<div class="work-tree-progress-intent"><span class="work-tree-progress-label">Last seen</span>${escapeHtml(formatWhen(progress.last_seen_at, null))}</div>`,
        `<div class="section-footnote">Family: ${escapeHtml(String(progress.family_key || 'n/a'))} · ladder: ${escapeHtml(String(progress.ladder_source || 'n/a'))}</div>`,
        '<div class="work-tree-progress-section-title">Solution markers (partial truths)</div>',
        `<ul class="work-tree-progress-markers">${markerItems}</ul>`,
        '<div class="work-tree-progress-section-title">Completed so far (effort)</div>',
        `<ul class="work-tree-progress-effort">${effortItems}</ul>`,
    ].join('');
}

function renderWorkTreeInspector(tree, node) {
    if (!workTreeBranchInfo) return;
    if (workTreeActionFeedback) workTreeActionFeedback.textContent = '';
    if (!tree) {
        workTreeBranchInfo.textContent = 'Branch inspection pending.';
        renderWorkTreeProgressPanel(null);
        _inspectorBranchId = null;
        _inspectorBranchStatus = null;
        if (workTreeBranchActions) workTreeBranchActions.style.display = 'none';
        return;
    }
    const nextStep = tree && tree.next_step && typeof tree.next_step === 'object' ? tree.next_step : {};
    if (!node) {
        workTreeBranchInfo.textContent = [
            `Tree: ${tree.title || tree.tree_id || 'tree'}`,
            `Status: ${tree.status || 'unknown'}`,
            `Active branch: ${tree.active_branch_title || 'none'}`,
            `Next step: ${nextStep.action || 'idle'} | tool=${nextStep.recommended_tool || 'n/a'}`,
            '',
            'This tree has no persisted branch history to inspect.',
        ].join('\n');
        renderWorkTreeProgressPanel(null);
        _inspectorBranchId = null;
        _inspectorBranchStatus = null;
        if (workTreeBranchActions) workTreeBranchActions.style.display = 'none';
        return;
    }
    const currentTask = node && node.current_task && typeof node.current_task === 'object' ? node.current_task : {};
    const progress = workTreeSolutionProgress(currentTask, node);
    _inspectorBranchId = String(node.id || node.branch_id || '');
    _inspectorBranchStatus = String(node.status || '').toLowerCase();
    renderWorkTreeProgressPanel(progress);
    workTreeBranchInfo.textContent = [
        `Tree: ${tree.title || tree.tree_id || 'tree'}`,
        `Branch: ${node.title || node.id || 'branch'}`,
        `Status: ${node.status || 'unknown'}`,
        `Depth: ${node.depth != null ? node.depth : 'n/a'}`,
        `Tasks: ${node.tasks_open != null ? node.tasks_open : 'n/a'} open / ${node.tasks_total != null ? node.tasks_total : 'n/a'} total`,
        `Preferred tool: ${node.preferred_tool || 'n/a'}`,
        `Current task: ${currentTask.title || 'none'}`,
        `Next step: ${nextStep.action || 'idle'} | tool=${nextStep.recommended_tool || 'n/a'}`,
        '',
        'Notes:',
        String(node.notes || '').trim() || 'No branch notes recorded.',
    ].join('\n');
    if (workTreeBranchActions) {
        const actionable = ['ready', 'open', 'pending', 'active'].includes(_inspectorBranchStatus);
        const blocked = ['blocked', 'observing'].includes(_inspectorBranchStatus);
        const taskMeta = currentTask.meta && typeof currentTask.meta === 'object' ? currentTask.meta : {};
        const blockedReason = String(taskMeta.blocked_reason || '').trim();
        const sourceType = String(node.source_type || '').trim().toLowerCase();
        const recommendedTool = String(nextStep.recommended_tool || node.preferred_tool || '').trim().toLowerCase();
        const outboxOpen = operatorOutboxOpenCount(latestStatus || {});
        const showRecovery = blocked || (sourceType === 'operator_control' && outboxOpen > 0);
        workTreeBranchActions.style.display = (actionable || showRecovery) ? '' : 'none';
        if (btnWorkTreeRunNext) btnWorkTreeRunNext.style.display = actionable ? '' : 'none';
        if (btnWorkTreeOpenOperatorDeck) btnWorkTreeOpenOperatorDeck.style.display = showRecovery ? '' : 'none';
        if (btnWorkTreeDismissOutbox) btnWorkTreeDismissOutbox.style.display = (showRecovery && outboxOpen > 0) ? '' : 'none';
        if (btnWorkTreeRunQueueNext) {
            const queueRecovery = recommendedTool === 'generated_queue_run' || blockedReason.includes('generated_queue');
            btnWorkTreeRunQueueNext.style.display = (showRecovery && queueRecovery) ? '' : 'none';
        }
    }
}

function renderTreeSvg(tree) {
    if (!workTreeSvg || !workTreeEmptyState) return;
    const visibleNodes = Array.isArray(tree && tree.nodes)
        ? tree.nodes.filter((node) => node && typeof node === 'object' && workTreeNodeVisibleInMode(node))
        : [];
    const fallbackNodes = Array.isArray(tree && tree.nodes) ? tree.nodes.filter((node) => node && typeof node === 'object') : [];
    const nodes = visibleNodes.length ? visibleNodes : fallbackNodes;
    if (!tree || !nodes.length) {
        workTreeSvg.innerHTML = '';
        workTreeSvg.setAttribute('viewBox', '0 0 960 560');
        workTreeEmptyState.textContent = tree ? `No branches match the ${workTreeViewMode} view for this tree.` : 'Work Tree map pending.';
        workTreeEmptyState.classList.remove('is-hidden');
        return;
    }

    const byDepth = new Map();
    nodes.forEach((node) => {
        const depth = Number(node.depth || 0);
        if (!byDepth.has(depth)) byDepth.set(depth, []);
        byDepth.get(depth).push(node);
    });
    const depths = Array.from(byDepth.keys()).sort((left, right) => left - right);
    depths.forEach((depth) => {
        byDepth.get(depth).sort((left, right) => String(left.title || left.id || '').localeCompare(String(right.title || right.id || '')));
    });

    const maxDepth = depths.length ? Math.max(...depths) : 0;
    const maxPerDepth = Math.max(...depths.map((depth) => byDepth.get(depth).length), 1);
    const width = Math.max(960, 240 + (maxDepth + 1) * 220);
    const height = Math.max(560, 180 + maxPerDepth * 88);
    const positions = new Map();
    depths.forEach((depth) => {
        const group = byDepth.get(depth) || [];
        const span = Math.max(1, group.length - 1);
        group.forEach((node, index) => {
            const x = 100 + depth * 220;
            const y = group.length === 1 ? height / 2 : 80 + ((height - 160) * index) / span;
            positions.set(String(node.id || ''), {x, y});
        });
    });

    const nodeMap = new Map(nodes.map((node) => [String(node.id || ''), node]));
    const dependencyEdges = Array.isArray(tree && tree.dependency_edges) ? tree.dependency_edges.filter((edge) => edge && typeof edge === 'object') : [];
    const parentLines = nodes
        .filter((node) => String(node.parent_id || '').trim() && positions.has(String(node.parent_id || '')) && positions.has(String(node.id || '')))
        .map((node) => {
            const source = positions.get(String(node.parent_id || ''));
            const target = positions.get(String(node.id || ''));
            return `<line class="scheduled-tree-edge" x1="${source.x}" y1="${source.y}" x2="${target.x}" y2="${target.y}"></line>`;
        })
        .join('');
    const dependencyLines = dependencyEdges
        .filter((edge) => positions.has(String(edge.from || '')) && positions.has(String(edge.to || '')))
        .map((edge) => {
            const source = positions.get(String(edge.from || ''));
            const target = positions.get(String(edge.to || ''));
            return `<line class="scheduled-tree-edge scheduled-tree-edge-dependency" x1="${source.x}" y1="${source.y}" x2="${target.x}" y2="${target.y}"></line>`;
        })
        .join('');

    const nodeGroups = nodes.map((node) => {
        const id = String(node.id || '');
        const pos = positions.get(id);
        const color = workTreeStatusColor(node.status);
        const selected = id === selectedWorkTreeNodeId;
        const currentTask = node && node.current_task && typeof node.current_task === 'object' ? node.current_task : {};
        const progress = workTreeSolutionProgress(currentTask, node);
        const pctRaw = progress ? Number(progress.percent) : NaN;
        const hasProgress = Number.isFinite(pctRaw);
        const pct = hasProgress ? Math.max(0, Math.min(100, Math.round(pctRaw))) : null;
        const motion = progress ? String(progress.motion || '').trim().toLowerCase() : '';
        const taskTitle = String(currentTask.title || '').trim();
        const label = String(node.title || id || 'branch');
        const tool = String(node.preferred_tool || '').trim();
        const ringR = 22;
        const ringC = 2 * Math.PI * ringR;
        const ringOffset = hasProgress ? ringC * (1 - (pct / 100)) : ringC;
        const pctClass = motion === 'blocked'
            ? 'is-blocked'
            : (motion === 'done' || pct === 100)
                ? 'is-done'
                : (motion === 'not_started' || pct === 0)
                    ? 'is-idle'
                    : 'is-moving';
        return [
            `<g class="scheduled-tree-node${selected ? ' is-selected' : ''}${hasProgress ? ' has-progress' : ''}" data-branch-id="${escapeHtml(id)}" tabindex="0">`,
            `<circle class="scheduled-tree-node-hit" cx="${pos.x}" cy="${pos.y}" r="34"></circle>`,
            hasProgress
                ? [
                    `<circle class="scheduled-tree-progress-track" cx="${pos.x}" cy="${pos.y}" r="${ringR}"></circle>`,
                    `<circle class="scheduled-tree-progress-ring ${pctClass}" cx="${pos.x}" cy="${pos.y}" r="${ringR}" stroke="${color}" stroke-dasharray="${ringC.toFixed(2)}" stroke-dashoffset="${ringOffset.toFixed(2)}" transform="rotate(-90 ${pos.x} ${pos.y})"></circle>`,
                    `<circle class="scheduled-tree-node-core" cx="${pos.x}" cy="${pos.y}" r="16" fill="${color}"></circle>`,
                    `<text class="scheduled-tree-progress-pct" x="${pos.x}" y="${pos.y + 4}">${pct}%</text>`,
                ].join('')
                : `<circle class="scheduled-tree-node-core" cx="${pos.x}" cy="${pos.y}" r="18" fill="${color}"></circle>`,
            `<text class="scheduled-tree-node-label" x="${pos.x + 30}" y="${pos.y - 8}">${escapeHtml(label)}</text>`,
            `<text class="scheduled-tree-node-meta" x="${pos.x + 30}" y="${pos.y + 12}">${escapeHtml(String(node.status || 'unknown').toUpperCase())}${tool ? ` | ${escapeHtml(tool)}` : ''}${hasProgress ? ` | ${pct}%` : ''}</text>`,
            taskTitle ? `<text class="scheduled-tree-node-task" x="${pos.x + 30}" y="${pos.y + 30}">${escapeHtml(taskTitle)}</text>` : '',
            '</g>',
        ].join('');
    }).join('');

    workTreeSvg.setAttribute('viewBox', `0 0 ${width} ${height}`);
    workTreeSvg.innerHTML = [
        '<defs>',
        '<marker id="scheduledTreeArrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto" markerUnits="strokeWidth">',
        '<path d="M0,0 L0,6 L9,3 z" fill="#4e647c"></path>',
        '</marker>',
        '<marker id="scheduledTreeDependencyArrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto" markerUnits="strokeWidth">',
        '<path d="M0,0 L0,6 L9,3 z" fill="#ffb347"></path>',
        '</marker>',
        '</defs>',
        parentLines.replaceAll('scheduled-tree-edge"', 'scheduled-tree-edge" marker-end="url(#scheduledTreeArrow)"'),
        dependencyLines.replaceAll('scheduled-tree-edge scheduled-tree-edge-dependency"', 'scheduled-tree-edge scheduled-tree-edge-dependency" marker-end="url(#scheduledTreeDependencyArrow)"'),
        nodeGroups,
    ].join('');
    workTreeEmptyState.classList.add('is-hidden');

    Array.from(workTreeSvg.querySelectorAll('[data-branch-id]')).forEach((element) => {
        element.addEventListener('click', () => {
            selectedWorkTreeNodeId = String(element.getAttribute('data-branch-id') || '').trim();
            renderSelectedWorkTreeView();
        });
        element.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                selectedWorkTreeNodeId = String(element.getAttribute('data-branch-id') || '').trim();
                renderSelectedWorkTreeView();
            }
        });
    });
}

function renderSelectedWorkTreeView() {
    const tree = selectedWorkTree();
    renderWorkTreeViewButtons();
    renderSelectedWorkTreeSummary(tree);
    if (!tree || !Array.isArray(tree.nodes) || !tree.nodes.length) {
        selectedWorkTreeNodeId = '';
        renderTreeSvg(tree);
        renderWorkTreeInspector(tree, null);
        return;
    }
    const visibleNodes = tree.nodes.filter((node) => node && typeof node === 'object' && workTreeNodeVisibleInMode(node));
    const treeForSelection = visibleNodes.length ? {...tree, nodes: visibleNodes} : tree;
    const node = selectedWorkTreeNode(treeForSelection);
    selectedWorkTreeNodeId = node ? String(node.id || '') : '';
    renderTreeSvg(treeForSelection);
    renderWorkTreeInspector(treeForSelection, node);
}

function renderWorkTrees(payload) {
    workTreesCache = Array.isArray(payload && payload.trees) ? payload.trees.filter((tree) => tree && typeof tree === 'object') : [];
    renderWorkTreeSelect();
    renderWorkTreeAggregateSummary(payload);
    renderSelectedWorkTreeView();
}

function renderOperatorMacros(status) {
    if (!operatorMacroSelect) return;
    const previous = String(operatorMacroSelect.value || '').trim();
    const macros = Array.isArray(status && status.operator_macros) ? status.operator_macros : [];
    operatorMacroSelect.innerHTML = '';
    const empty = document.createElement('option');
    empty.value = '';
    empty.textContent = macros.length ? '(select operator macro)' : '(no operator macros)';
    operatorMacroSelect.appendChild(empty);
    macros.forEach((macro) => {
        const option = document.createElement('option');
        option.value = String(macro.macro_id || '');
        const placeholders = Array.isArray(macro.placeholders) ? macro.placeholders : [];
        option.textContent = String(macro.label || macro.macro_id || 'macro') + (placeholders.length ? ` (${placeholders.length} fields)` : '');
        operatorMacroSelect.appendChild(option);
    });
    if (previous && macros.some((macro) => String(macro.macro_id || '') === previous)) {
        operatorMacroSelect.value = previous;
    }
}

function renderBackendCommands(status, commandsOverride = null) {
    if (!backendCommandSelect) return;
    const previous = String(backendCommandSelect.value || '').trim();
    const commands = Array.isArray(commandsOverride)
        ? commandsOverride
        : (Array.isArray(status && status.backend_commands) ? status.backend_commands : []);
    backendCommandSelect.innerHTML = '';
    const empty = document.createElement('option');
    empty.value = '';
    empty.textContent = commands.length ? '(select backend command)' : '(no backend commands)';
    backendCommandSelect.appendChild(empty);
    commands.forEach((command) => {
        const option = document.createElement('option');
        const commandId = String(command && command.command_id ? command.command_id : '').trim();
        const label = String(command && command.label ? command.label : commandId).trim();
        option.value = commandId;
        option.textContent = label;
        const details = [
            String(command && command.description ? command.description : '').trim(),
            `kind=${String(command && command.kind ? command.kind : '').trim()}`,
            `entry=${String(command && command.entry ? command.entry : '').trim()}`,
            `dynamic_args=${Boolean(command && command.allow_dynamic_args)}`,
        ].filter(Boolean);
        option.title = details.join(' | ');
        backendCommandSelect.appendChild(option);
    });
    if (previous && commands.some((row) => String(row.command_id || '') === previous)) {
        backendCommandSelect.value = previous;
    }
    if (backendCommandOutput && !String(backendCommandOutput.textContent || '').trim()) {
        backendCommandOutput.textContent = 'Command deck idle.';
    }
}

function selectedOperatorMacro() {
    const macroId = operatorMacroSelect ? String(operatorMacroSelect.value || '').trim() : '';
    const macros = Array.isArray(latestStatus && latestStatus.operator_macros) ? latestStatus.operator_macros : [];
    return macros.find((item) => String(item.macro_id || '') === macroId) || null;
}

function renderGovernance(policy, status) {
    const memory = policy && policy.memory && typeof policy.memory === 'object' ? policy.memory : {};
    const web = policy && policy.web && typeof policy.web === 'object' ? policy.web : {};
    const serverSide = policy && policy.server_side && typeof policy.server_side === 'object' ? policy.server_side : {};
    const chatAuth = policy && policy.chat_auth && typeof policy.chat_auth === 'object' ? policy.chat_auth : {};
    const users = Array.isArray(chatAuth.users) ? chatAuth.users : [];
    const scope = String(memory.scope || (status && status.memory_scope) || 'private').trim().toLowerCase();
    const provider = String(web.search_provider || (status && status.search_provider) || 'html').trim().toLowerCase();
    const endpoint = String(web.search_api_endpoint || (status && status.search_api_endpoint) || '').trim();
    const serverSideMode = String(serverSide.mode || 'native').trim().toLowerCase();
    const serverSideFrontdoor = String(serverSide.frontdoor || 'direct').trim().toLowerCase();
    const serverSideBaseUrl = String(serverSide.frontdoor_base_url || '').trim();
    const serverSideDockerEnabled = Boolean(serverSide.docker_enabled);
    const providerTelemetry = status && status.provider_telemetry && typeof status.provider_telemetry === 'object' ? status.provider_telemetry : {};
    const priority = Array.isArray(web.search_provider_priority) ? web.search_provider_priority : (Array.isArray(status && status.search_provider_priority) ? status.search_provider_priority : []);

    if (memoryScopeSelect && ['private', 'shared', 'hybrid'].includes(scope)) memoryScopeSelect.value = scope;
    if (serverSideModeSelect && ['native', 'proxy'].includes(serverSideMode)) serverSideModeSelect.value = serverSideMode;
    if (serverSideFrontdoorSelect && ['direct', 'apache', 'uniserver'].includes(serverSideFrontdoor)) serverSideFrontdoorSelect.value = serverSideFrontdoor;
    if (serverSideBaseUrlInput) serverSideBaseUrlInput.value = serverSideBaseUrl;
    if (serverSideDockerSelect) serverSideDockerSelect.value = serverSideDockerEnabled ? 'true' : 'false';
    const providerSelect = document.getElementById('searchProvider');
    if (providerSelect && ['html', 'searxng', 'brave'].includes(provider)) providerSelect.value = provider;
    if (searchEndpointInput) searchEndpointInput.value = endpoint;
    if (searchProviderPriorityInput) searchProviderPriorityInput.value = priority.join(', ');
    if (memoryScopeBox) {
        const memoryHealth = memoryHealthDetails(status);
        memoryScopeBox.textContent = [
            `Current scope: ${scope}`,
            `Memory enabled: ${Boolean(memory.enabled)}`,
            `Mode: ${String(memory.mode || '')}`,
            `Top K: ${String(memory.top_k || '')}`,
            `Health: ${memoryHealth.status}`,
            `Rows: db ${memoryHealth.dbTotal} | scope ${memoryHealth.scopedTotal}`,
            `Events: ${memoryHealth.eventLogText}`,
            `Watch: ${memoryHealth.issueText || 'No amnesia signals'}`,
        ].join('\n');
    }
    if (searchEndpointBox) {
        const hitLines = Object.entries(providerTelemetry.hits_last_window || {}).map(([name, count]) => `${name}=${count}`);
        const providerHit = String(providerTelemetry.last_provider_used || status.last_provider_hit || '').trim();
        const providerNote = String(status && status.last_provider_note || '').trim();
        searchEndpointBox.textContent = [
            `Provider: ${provider}`,
            `Endpoint: ${endpoint || '(not set)'}`,
            `Web enabled: ${Boolean(web.enabled)}`,
            `Priority: ${priority.length ? priority.join(', ') : '(default)'}`,
            `Probe ok: ${status && status.searxng_ok != null ? Boolean(status.searxng_ok) : 'n/a'}`,
            `Probe note: ${String((status && status.searxng_note) || 'n/a')}`,
            `Last provider hit: ${providerHit || 'no provider hit recorded'}`,
            `Last provider note: ${providerNote || 'n/a'}`,
            `Last provider query: ${String(providerTelemetry.last_provider_query || 'n/a')}`,
            `StackExchange site: ${String(providerTelemetry.stackexchange_site || 'stackoverflow')}`,
            `Hits last window: ${hitLines.length ? hitLines.join(', ') : 'n/a'}`,
        ].join('\n');
    }
    if (serverSideBox) {
        serverSideBox.textContent = [
            `Mode: ${serverSideMode}`,
            `Frontdoor: ${serverSideFrontdoor}`,
            `Frontdoor base URL: ${serverSideBaseUrl || '(not set)'}`,
            `Docker enabled: ${serverSideDockerEnabled}`,
        ].join('\n');
    }
    if (chatUserSelect) {
        const current = (chatUserSelect.value || '').trim();
        chatUserSelect.innerHTML = '';
        const empty = document.createElement('option');
        empty.value = '';
        empty.textContent = users.length ? '(select chat user)' : '(no chat users)';
        chatUserSelect.appendChild(empty);
        users.forEach((user) => {
            const option = document.createElement('option');
            option.value = user;
            option.textContent = user;
            chatUserSelect.appendChild(option);
        });
        if (current && users.includes(current)) chatUserSelect.value = current;
    }
    if (chatAuthBox) {
        chatAuthBox.textContent = [
            `Login enabled: ${Boolean(chatAuth.enabled)}`,
            `Source: ${String(chatAuth.source || (status && status.chat_auth_source) || 'disabled')}`,
            `Users: ${Number(chatAuth.count || users.length || 0)}`,
            `Managed file: ${String(chatAuth.managed_path || '')}`,
            '',
            'Usernames:',
            users.length ? users.join('\n') : '(none)',
        ].join('\n');
    }
}

function renderTemporalGovernance(status) {
    if (!temporalStatusGrid && !temporalStatusBox) return;
    if (!status || typeof status !== 'object') {
        if (temporalStatusGrid) temporalStatusGrid.textContent = 'Temporal status pending.';
        if (temporalStatusBox) temporalStatusBox.textContent = 'Temporal telemetry pending.';
        return;
    }
    const maintenance = status.autonomy_maintenance && typeof status.autonomy_maintenance === 'object'
        ? status.autonomy_maintenance
        : {};
    const feed = maintenance.last_temporal_feed && typeof maintenance.last_temporal_feed === 'object'
        ? maintenance.last_temporal_feed
        : {};
    const surfacedPressures = Array.isArray(feed.surfaced_pressures) ? feed.surfaced_pressures : [];
    const feedErrors = Array.isArray(feed.errors) ? feed.errors : [];
    const eventCount = Number(status.temporal_feed_event_count != null ? status.temporal_feed_event_count : feed.event_count || 0);
    const surfacedCount = Number(status.temporal_feed_surfaced_count != null ? status.temporal_feed_surfaced_count : feed.surfaced_count || 0);
    const pressureCount = Number(status.temporal_pressure_count != null ? status.temporal_pressure_count : 0);
    const sourcePaths = Array.isArray(feed.source_paths) ? feed.source_paths : [];
    const samplePressure = surfacedPressures[0] && typeof surfacedPressures[0] === 'object' ? surfacedPressures[0] : null;
    const sampleEvent = samplePressure && samplePressure.event && typeof samplePressure.event === 'object' ? samplePressure.event : {};
    const sampleTitle = String(sampleEvent.title || '').trim();
    const sampleAction = String(samplePressure && samplePressure.recommended_action ? samplePressure.recommended_action : '').trim();
    const sampleScore = Number(samplePressure && samplePressure.final_score != null ? samplePressure.final_score : NaN);
    const feedStatus = String(status.temporal_feed_status || feed.status || 'unknown').trim();
    const enabledText = String(status.temporal_enabled === true ? 'enabled' : 'disabled');
    const lastRunAt = String(status.temporal_feed_last_run_at || feed.ran_at || '').trim();

    renderInspectorList(temporalStatusGrid, [
        {label: 'Temporal', value: `${enabledText} | feed ${feedStatus}`},
        {label: 'Cadence', value: `${Number(feed.interval_sec || 0)}s | next cap ${Number(feed.max_surface_events || 0)} events`},
        {label: 'Feed Counts', value: `events ${Number.isFinite(eventCount) ? eventCount : 0} | surfaced ${Number.isFinite(surfacedCount) ? surfacedCount : 0} | pressure ${Number.isFinite(pressureCount) ? pressureCount : 0}`},
        {label: 'Last Run', value: lastRunAt || 'n/a'},
        {label: 'Source Paths', value: sourcePaths.length ? sourcePaths.join('\n') : '(none)'},
        {label: 'Top Surfaced Event', value: sampleTitle ? `${sampleTitle}${sampleAction ? ` | action=${sampleAction}` : ''}${Number.isFinite(sampleScore) ? ` | score=${sampleScore.toFixed(1)}` : ''}` : 'No surfaced temporal events'},
        {label: 'Feed Errors', value: feedErrors.length ? feedErrors.map((entry) => JSON.stringify(entry)).join('\n') : 'No feed errors'},
    ]);

    if (temporalStatusBox) {
        const sampleLines = surfacedPressures.slice(0, 3).map((entry, index) => {
            const event = entry && entry.event && typeof entry.event === 'object' ? entry.event : {};
            const title = String(event.title || `event_${index + 1}`).trim();
            const explanation = String(entry && entry.explanation ? entry.explanation : '').trim();
            const action = String(entry && entry.recommended_action ? entry.recommended_action : '').trim();
            const path = String(entry && entry.source_path ? entry.source_path : '').trim();
            const score = Number(entry && entry.final_score != null ? entry.final_score : NaN);
            return [
                `${index + 1}. ${title}`,
                explanation ? `   explain: ${explanation}` : '',
                action ? `   action: ${action}` : '',
                Number.isFinite(score) ? `   score: ${score.toFixed(1)}` : '',
                path ? `   source: ${path}` : '',
            ].filter(Boolean).join('\n');
        });
        temporalStatusBox.textContent = [
            `Temporal enabled: ${status.temporal_enabled === true}`,
            `Feed status: ${feedStatus}`,
            `Last run: ${lastRunAt || 'n/a'}`,
            `Errors: ${feedErrors.length}`,
            '',
            'Surfaced events:',
            sampleLines.length ? sampleLines.join('\n\n') : '(none)',
        ].join('\n');
    }
}

// ---------------------------------------------------------------------------
// Temporal event management
// ---------------------------------------------------------------------------

let _temporalEvents = [];

function _temporalFmt(isoStr) {
    if (!isoStr) return '';
    // Convert ICS compact form or ISO to datetime-local value (YYYY-MM-DDTHH:mm)
    const s = String(isoStr).trim();
    // Compact ICS: YYYYMMDDTHHmmssZ
    const compactMatch = s.match(/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})/);
    if (compactMatch) {
        return `${compactMatch[1]}-${compactMatch[2]}-${compactMatch[3]}T${compactMatch[4]}:${compactMatch[5]}`;
    }
    // ISO: return first 16 chars
    return s.substring(0, 16);
}

function renderTemporalEventList(events) {
    const list = document.getElementById('temporalEventList');
    if (!list) return;
    if (!Array.isArray(events) || !events.length) {
        list.textContent = 'No calendar events. Add one below.';
        return;
    }
    list.innerHTML = '';
    events.forEach((ev) => {
        const uid = String(ev.uid || ev.metadata && ev.metadata.uid || '').trim();
        const title = String(ev.title || 'Untitled').trim();
        const start = String(ev.start || '').trim();
        const confidence = String(ev.confidence || '').trim();
        const importance = Number(ev.importance || 0).toFixed(2);
        const depRisk = Number(ev.dependency_risk || 0).toFixed(2);

        const row = document.createElement('div');
        row.className = 'inspector-row';
        row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:4px 0;border-bottom:1px solid var(--border-subtle,#333);';
        row.innerHTML = `
            <span style="flex:2;font-size:.8rem;font-weight:500;">${escapeHtml(title)}</span>
            <span style="flex:1;font-size:.75rem;color:var(--text-muted);">${escapeHtml(start.substring(0, 16))}</span>
            <span style="flex:1;font-size:.75rem;color:var(--text-muted);">${escapeHtml(confidence)}</span>
            <span style="flex:1;font-size:.75rem;color:var(--text-muted);">imp:${importance} risk:${depRisk}</span>
            <button class="btn btn-sm btn-operator-alt" data-uid="${escapeHtml(uid)}" data-action="edit-temporal-event" style="padding:1px 8px;font-size:.75rem;">Edit</button>
            <button class="btn btn-sm" data-uid="${escapeHtml(uid)}" data-action="delete-temporal-event" style="padding:1px 8px;font-size:.75rem;background:var(--danger-muted,#5a1a1a);color:var(--danger,#f38ba8);">Delete</button>
        `;
        list.appendChild(row);
    });
}

async function loadTemporalEvents() {
    try {
        const data = await postAction('temporal_events_list', {});
        if (data && Array.isArray(data.events)) {
            _temporalEvents = data.events;
            renderTemporalEventList(_temporalEvents);
        }
    } catch (_) {
        // silently fail — non-critical
    }
}

function clearTemporalForm() {
    const uid = document.getElementById('temporalEventUid');
    const title = document.getElementById('temporalEventTitle');
    const start = document.getElementById('temporalEventStart');
    const end = document.getElementById('temporalEventEnd');
    const conf = document.getElementById('temporalEventConfidence');
    const rrule = document.getElementById('temporalEventRrule');
    const imp = document.getElementById('temporalEventImportance');
    const dep = document.getElementById('temporalEventDepRisk');
    const stale = document.getElementById('temporalEventStale');
    const opctx = document.getElementById('temporalEventOpCtx');
    const heading = document.getElementById('temporalFormHeading');
    const fb = document.getElementById('temporalFormFeedback');
    if (uid) uid.value = '';
    if (title) title.value = '';
    if (start) start.value = '';
    if (end) end.value = '';
    if (conf) conf.value = 'CONFIRMED';
    if (rrule) rrule.value = '';
    if (imp) imp.value = '0';
    if (dep) dep.value = '0';
    if (stale) stale.value = '0';
    if (opctx) opctx.value = '0';
    if (heading) heading.textContent = 'Add Event';
    if (fb) fb.textContent = '';
}

function populateTemporalForm(ev) {
    const uid = document.getElementById('temporalEventUid');
    const title = document.getElementById('temporalEventTitle');
    const start = document.getElementById('temporalEventStart');
    const end = document.getElementById('temporalEventEnd');
    const conf = document.getElementById('temporalEventConfidence');
    const rrule = document.getElementById('temporalEventRrule');
    const imp = document.getElementById('temporalEventImportance');
    const dep = document.getElementById('temporalEventDepRisk');
    const stale = document.getElementById('temporalEventStale');
    const opctx = document.getElementById('temporalEventOpCtx');
    const heading = document.getElementById('temporalFormHeading');
    if (uid) uid.value = String(ev.uid || ev.metadata && ev.metadata.uid || '');
    if (title) title.value = String(ev.title || '');
    if (start) start.value = _temporalFmt(ev.start);
    if (end) end.value = _temporalFmt(ev.end);
    if (conf) conf.value = String(ev.confidence || 'CONFIRMED').toUpperCase();
    if (rrule) rrule.value = String(ev.metadata && ev.metadata.rrule || '');
    if (imp) imp.value = Number(ev.importance || 0).toFixed(2);
    if (dep) dep.value = Number(ev.dependency_risk || 0).toFixed(2);
    if (stale) stale.value = Number(ev.stale_evidence || 0).toFixed(2);
    if (opctx) opctx.value = Number(ev.operator_context || 0).toFixed(2);
    if (heading) heading.textContent = 'Edit Event';
}

function wireTemporalEventManagement() {
    const saveBtn = document.getElementById('btnTemporalSave');
    const clearBtn = document.getElementById('btnTemporalClear');
    const list = document.getElementById('temporalEventList');

    if (saveBtn) {
        saveBtn.addEventListener('click', () => {
            const uid = String(document.getElementById('temporalEventUid').value || '').trim();
            const title = String(document.getElementById('temporalEventTitle').value || '').trim();
            const start = String(document.getElementById('temporalEventStart').value || '').trim();
            const end = String(document.getElementById('temporalEventEnd').value || '').trim();
            const confidence = String(document.getElementById('temporalEventConfidence').value || 'CONFIRMED');
            const rrule = String(document.getElementById('temporalEventRrule').value || '').trim();
            const importance = parseFloat(document.getElementById('temporalEventImportance').value || '0') || 0;
            const dependency_risk = parseFloat(document.getElementById('temporalEventDepRisk').value || '0') || 0;
            const stale_evidence = parseFloat(document.getElementById('temporalEventStale').value || '0') || 0;
            const operator_context = parseFloat(document.getElementById('temporalEventOpCtx').value || '0') || 0;
            const fb = document.getElementById('temporalFormFeedback');

            if (!title) {
                if (fb) fb.textContent = 'Title is required.';
                return;
            }

            const event = {
                uid: uid || undefined,
                title,
                start,
                end,
                confidence,
                importance,
                dependency_risk,
                stale_evidence,
                operator_context,
                metadata: rrule ? {rrule} : {},
            };

            if (fb) fb.textContent = 'Saving…';
            postAction('temporal_event_save', {event}).then((data) => {
                if (fb) fb.textContent = `Saved (uid: ${data && data.uid || 'ok'})`;
                clearTemporalForm();
                loadTemporalEvents();
            }).catch(() => {
                if (fb) fb.textContent = 'Save failed.';
            });
        });
    }

    if (clearBtn) {
        clearBtn.addEventListener('click', clearTemporalForm);
    }

    if (list) {
        list.addEventListener('click', (e) => {
            const btn = e.target.closest('[data-action]');
            if (!btn) return;
            const uid = String(btn.dataset.uid || '').trim();
            const action = String(btn.dataset.action || '').trim();

            if (action === 'edit-temporal-event') {
                const ev = _temporalEvents.find((x) => String(x.uid || x.metadata && x.metadata.uid || '') === uid);
                if (ev) populateTemporalForm(ev);
                return;
            }

            if (action === 'delete-temporal-event') {
                if (!uid) return;
                postAction('temporal_event_delete', {uid}).then(() => {
                    loadTemporalEvents();
                }).catch(() => {});
            }
        });
    }
}

function setHealthBadge(score, ratio, alerts) {
    if (!healthBadge) return;
    const numericScore = Number(score || 0);
    const alertList = Array.isArray(alerts) ? alerts : [];
    const pct = Math.max(0, Math.min(100, Math.round(Number(ratio || 0) * 100)));
    const toneClass = numericScore >= 90 && !alertList.length
        ? 'health-status-tile-good'
        : (numericScore < 70 || alertList.length ? 'health-status-tile-danger' : 'health-status-tile-warn');
    healthBadge.className = `health-status-tile ${toneClass}`;
    healthBadge.innerHTML = [
        '<span class="health-status-icon-wrap" aria-hidden="true">',
        '<i class="bi bi-heart-pulse-fill health-status-icon"></i>',
        '</span>',
        '<span class="health-status-copy">',
        '<span class="health-status-label">Health</span>',
        `<span class="health-status-value">${numericScore}/100</span>`,
        `<span class="health-status-label">${pct}% pass</span>`,
        '</span>',
    ].join('');
    healthBadge.title = alertList.length ? ('Alerts: ' + alertList.join('; ')) : 'No active alerts';
}

function drawMetrics(points) {
    renderTelemetryGraph({points}, latestStatus);
}

async function getJson(url) {
    const response = await fetch(url, {headers: controlHeaders(), cache: 'no-store'});
    const payload = await response.json();
    if (!response.ok || !payload.ok) throw new Error(payload.error || payload.message || ('HTTP ' + response.status));
    return payload;
}

async function postAction(action, body = {}) {
    const response = await fetch('/api/control/action', {
        method: 'POST',
        headers: controlHeaders(),
        body: JSON.stringify({action, ...body})
    });
    const payload = await response.json();
    if (!response.ok || !payload.ok) throw new Error(payload.error || payload.message || ('HTTP ' + response.status));
    return payload;
}

async function fetchWorkTrees() {
    try {
        return await getJson('/api/control/work-trees');
    } catch (_e1) {
        // First retry with fixed 250ms delay
        await new Promise((resolve) => window.setTimeout(resolve, 250));
        try {
            return await getJson('/api/control/work-trees');
        } catch (_e2) {
            // Second retry with jitter (250-500ms random)
            const jitterMs = 250 + Math.random() * 250;
            await new Promise((resolve) => window.setTimeout(resolve, jitterMs));
            return getJson('/api/control/work-trees');
        }
    }
}

async function fetchPipelines() {
    const query = selectedPipelineId ? `?pipeline_id=${encodeURIComponent(selectedPipelineId)}` : '';
    return getJson(`/api/control/pipelines${query}`);
}

async function fetchBackendCommandsDeck() {
    try {
        const payload = await postAction('backend_command_list');
        return Array.isArray(payload.commands) ? payload.commands : [];
    } catch (_error) {
        return null;
    }
}

const REFRESH_INTERVAL_MS = 30000;
const REFRESH_BACKOFF_MAX_MS = 120000;
const FULL_STATUS_BACKGROUND_REFRESH_MS = 180000;
// Backpack deck is operator-driven; do not re-hit list/status every control poll.
const BACKPACK_HYDRATE_INTERVAL_MS = 120000;
let refreshBackoffMs = REFRESH_INTERVAL_MS;
let refreshTimerHandle = null;
let lastFullStatusHydratedAt = Date.now();
let lastBackpackHydratedAt = 0;
let backpackHydrateForced = false;

function currentMainViewName() {
    const visible = mainViews.find((view) => !view.classList.contains('d-none'));
    return visibleViewName(visible ? visible.getAttribute('data-view') : 'overview');
}

function shouldHydrateFullStatus(viewName) {
    const view = visibleViewName(viewName);
    if (view === 'operations' || view === 'logs' || view === 'health') return true;
    return Date.now() - lastFullStatusHydratedAt > FULL_STATUS_BACKGROUND_REFRESH_MS;
}

function shouldHydrateSessions(viewName) {
    return visibleViewName(viewName) === 'sessions';
}

function shouldHydrateWorkTrees(viewName) {
    return visibleViewName(viewName) === 'scheduled-tree';
}

function shouldHydratePipelines(viewName) {
    return visibleViewName(viewName) === 'pipelines';
}

function shouldHydrateBackpacks(viewName) {
    if (visibleViewName(viewName) !== 'backpacks') return false;
    if (backpackHydrateForced) return true;
    return (Date.now() - lastBackpackHydratedAt) >= BACKPACK_HYDRATE_INTERVAL_MS;
}

function forceBackpackHydrate() {
    backpackHydrateForced = true;
    lastBackpackHydratedAt = 0;
}

function selectedBackpack() {
    return backpacksCache.find((item) => String(item && item.backpack_id ? item.backpack_id : '') === selectedBackpackId) || null;
}

function setBackpackBusy(busy, message, activeButtonId) {
    const text = message || 'Working…';
    if (backpackBusyText) {
        backpackBusyText.textContent = text;
    }
    if (backpackBusyBar) {
        backpackBusyBar.classList.toggle('d-none', !busy);
        backpackBusyBar.classList.toggle('is-busy', Boolean(busy));
        // Force visible even if Bootstrap d-none is overridden
        backpackBusyBar.style.display = busy ? 'flex' : '';
        if (busy) {
            backpackBusyBar.setAttribute('aria-busy', 'true');
            try {
                backpackBusyBar.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
            } catch (_e) {
                /* ignore */
            }
        } else {
            backpackBusyBar.removeAttribute('aria-busy');
        }
    }
    // Feedback bar so something always changes even if busy bar is off-screen
    if (busy) {
        setAction(text);
    }
    const ids = [
        'btnBackpacksRefresh', 'btnBackpackEnable', 'btnBackpackDisable',
        'btnBackpackSaveSettings', 'btnBackpackInstall', 'btnBackpackProbeLea',
        'btnBackpackReportHealth', 'btnBackpackReportSchools', 'btnBackpackRefreshSchools',
    ];
    ids.forEach((id) => {
        const el = document.getElementById(id);
        if (!el) return;
        el.disabled = Boolean(busy);
        if (!el.dataset.idleLabel) {
            el.dataset.idleLabel = String(el.textContent || '').trim();
        }
        if (busy && activeButtonId && id === activeButtonId) {
            el.textContent = 'Working…';
            el.classList.add('backpack-btn-busy');
        } else if (!busy) {
            if (el.dataset.idleLabel) el.textContent = el.dataset.idleLabel;
            el.classList.remove('backpack-btn-busy');
        }
    });
    if (backpackSelect) backpackSelect.disabled = Boolean(busy);
}

/** Let the browser paint the spinner before a long await (fetch/TEA). */
function paintBackpackBusy() {
    return new Promise((resolve) => {
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                window.setTimeout(resolve, 0);
            });
        });
    });
}

function sleepMs(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
}

async function withBackpackBusy(message, activeButtonId, workFn, options = {}) {
    // Minimum visible busy time so fast/failed actions still show feedback
    const minMs = Number(options.minMs);
    const holdMs = Number.isFinite(minMs) ? Math.max(0, minMs) : 900;
    const started = Date.now();
    setBackpackBusy(true, message, activeButtonId);
    await paintBackpackBusy();
    try {
        return await workFn();
    } finally {
        const elapsed = Date.now() - started;
        if (elapsed < holdMs) {
            await sleepMs(holdMs - elapsed);
        }
        setBackpackBusy(false);
    }
}

function showBackpackDetail(show) {
    if (backpackEmptyState) backpackEmptyState.classList.toggle('d-none', Boolean(show));
    if (backpackDetailBody) backpackDetailBody.classList.toggle('d-none', !show);
}

function renderBackpackCards() {
    if (!backpackCards) return;
    if (!backpacksCache.length) {
        backpackCards.textContent = 'No backpacks discovered under backpacks/. Nova core can run without any.';
        return;
    }
    backpackCards.innerHTML = backpacksCache.map((bp) => {
        const id = String(bp.backpack_id || '').trim();
        const active = id === selectedBackpackId ? ' active' : '';
        const installed = bp.installed ? 'installed' : 'not installed';
        const onOff = bp.enabled === false ? 'off' : 'on';
        const name = bp.display_name || id;
        return `<button type="button" class="pipeline-card-button${active}" data-backpack-id="${id}">
            <div class="pipeline-card-title">${name}</div>
            <div class="pipeline-card-meta">${id} · ${installed} · ${onOff} · v${bp.version || '?'}</div>
        </button>`;
    }).join('');
    backpackCards.querySelectorAll('[data-backpack-id]').forEach((btn) => {
        btn.addEventListener('click', async () => {
            selectedBackpackId = String(btn.getAttribute('data-backpack-id') || '').trim();
            await loadBackpacks({ keepFormSecrets: true });
        });
    });
}

function renderBackpackSelect() {
    if (!backpackSelect) return;
    const previous = selectedBackpackId;
    backpackSelect.innerHTML = '';
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.textContent = '— Select a backpack —';
    backpackSelect.appendChild(placeholder);
    if (!backpacksCache.length) {
        return;
    }
    backpacksCache.forEach((bp) => {
        const option = document.createElement('option');
        option.value = String(bp.backpack_id || '').trim();
        const onOff = bp.enabled === false ? 'off' : 'on';
        option.textContent = `${bp.display_name || bp.backpack_id} (${onOff})`;
        backpackSelect.appendChild(option);
    });
    if (previous && backpacksCache.some((item) => String(item.backpack_id || '') === previous)) {
        backpackSelect.value = previous;
        selectedBackpackId = previous;
    } else {
        selectedBackpackId = '';
        backpackSelect.value = '';
    }
}

function fillBackpackForm(detail) {
    const pub = (detail && detail.settings_public && typeof detail.settings_public === 'object')
        ? detail.settings_public
        : {};
    if (bpFieldConnectionId) bpFieldConnectionId.value = String(pub.connection_id || 'district-main');
    if (bpFieldBaseUrl) bpFieldBaseUrl.value = String(pub.base_url || '');
    if (bpFieldClientId) bpFieldClientId.value = String(pub.client_id || '');
    // Never re-fill secret from server (we never return it).
    if (bpFieldClientSecret && !String(bpFieldClientSecret.value || '').trim()) {
        bpFieldClientSecret.placeholder = detail && detail.has_client_secret_on_disk
            ? 'Saved on this machine — leave blank to keep'
            : 'Required for first install';
    }
    if (bpFieldLea) bpFieldLea.value = String(pub.district_lea_id || '');
    if (bpFieldScope) bpFieldScope.value = String(pub.scope_mode || 'single_lea');
    if (bpFieldAllowedLeas) bpFieldAllowedLeas.value = String(pub.allowed_lea_ids || '');
    if (bpFieldAccessTier) bpFieldAccessTier.value = String(pub.credential_access_tier || 'read');
    if (backpackProbeLea && !String(backpackProbeLea.value || '').trim() && pub.district_lea_id) {
        backpackProbeLea.value = String(pub.district_lea_id);
    }
}

function renderBackpackDetail(payload) {
    const detail = payload && payload.detail && typeof payload.detail === 'object' ? payload.detail : {};
    backpackDetailCache = detail;
    if (backpackModelNote && payload && payload.model) {
        backpackModelNote.textContent = String(payload.model.note || 'Nova first. Backpacks later. Choose a backpack to configure it.');
    }
    const hasSelection = Boolean(selectedBackpackId);
    showBackpackDetail(hasSelection);
    if (!hasSelection) {
        if (backpackStatusGrid) backpackStatusGrid.innerHTML = '';
        if (backpackGrantsBox) backpackGrantsBox.textContent = '';
        return;
    }
    const enabled = detail.enabled !== false;
    if (backpackEnabledBadge) {
        backpackEnabledBadge.textContent = enabled ? 'ON' : 'OFF';
        backpackEnabledBadge.className = enabled
            ? 'status-pill status-pill-ok'
            : 'status-pill status-pill-warn';
    }
    if (backpackStatusGrid) {
        const status = detail.status || {};
        const health = detail.connection_health || {};
        const teach = detail.teach || {};
        const lines = [
            ['backpack', detail.backpack_id || selectedBackpackId || '—'],
            ['power', enabled ? 'on' : 'off'],
            ['installed', detail.installed ? 'yes' : 'no'],
            ['settings_on_disk', detail.settings_path ? 'yes' : 'no'],
            ['secret_on_disk', detail.has_client_secret_on_disk ? 'yes (not shown)' : 'no'],
            ['phase', (detail.checklist && detail.checklist.phase) || 'pipeline'],
            ['teach_rules', Array.isArray(teach.rules) ? String(teach.rules.length) : '0'],
            ['status_ok', status.ok === false ? 'false' : String(status.live_query_ready ?? status.ok ?? '—')],
            ['connection_id', health.connection_id || status.connection_id || '—'],
            ['district_lea_id', health.district_lea_id || status.district_lea_id || '—'],
            ['scope_mode', status.scope_mode || health.scope_mode || '—'],
            ['health', health.health || status.profile_health || '—'],
            ['blockers', Array.isArray(status.blockers) ? status.blockers.join(', ') : '—'],
            ['error', detail.error || health.error || status.error || ''],
        ];
        backpackStatusGrid.innerHTML = lines.map(([k, v]) =>
            `<div class="inspector-row"><span class="inspector-key">${k}</span><span class="inspector-val">${String(v || '')}</span></div>`
        ).join('');
    }
    if (backpackGrantsBox) {
        const grants = detail.grants || {};
        backpackGrantsBox.textContent = JSON.stringify(grants, null, 2);
    }
    fillBackpackForm(detail);
}

async function fetchBackpacks() {
    const query = selectedBackpackId
        ? `?backpack_id=${encodeURIComponent(selectedBackpackId)}`
        : '';
    return getJson(`/api/control/backpacks${query}`);
}

async function loadBackpacks(options = {}) {
    forceBackpackHydrate();
    const payload = await fetchBackpacks();
    backpacksCache = Array.isArray(payload && payload.backpacks)
        ? payload.backpacks.filter((item) => item && typeof item === 'object')
        : [];
    // Prefer explicit local selection; never force first backpack.
    const serverSelected = String(payload && payload.selected_backpack_id ? payload.selected_backpack_id : '').trim();
    if (selectedBackpackId) {
        // keep
    } else if (serverSelected) {
        selectedBackpackId = serverSelected;
    } else {
        selectedBackpackId = '';
    }
    if (backpackListSummary) {
        backpackListSummary.textContent = `${backpacksCache.length} backpack${backpacksCache.length === 1 ? '' : 's'} available. Select one to configure.`;
    }
    renderBackpackSelect();
    renderBackpackCards();
    renderBackpackDetail(payload);
    lastBackpackHydratedAt = Date.now();
    backpackHydrateForced = false;
    return payload;
}

function parseBackpackSettingsFromUi() {
    const connectionId = bpFieldConnectionId ? String(bpFieldConnectionId.value || '').trim() : '';
    const baseUrl = bpFieldBaseUrl ? String(bpFieldBaseUrl.value || '').trim() : '';
    const clientId = bpFieldClientId ? String(bpFieldClientId.value || '').trim() : '';
    const clientSecret = bpFieldClientSecret ? String(bpFieldClientSecret.value || '') : '';
    const lea = bpFieldLea ? String(bpFieldLea.value || '').trim() : '';
    const scope = bpFieldScope ? String(bpFieldScope.value || 'single_lea').trim() : 'single_lea';
    const allowed = bpFieldAllowedLeas ? String(bpFieldAllowedLeas.value || '').trim() : '';
    const tier = bpFieldAccessTier ? String(bpFieldAccessTier.value || 'read').trim() : 'read';
    if (!connectionId) throw new Error('Connection name is required.');
    if (!baseUrl) throw new Error('ODS base URL is required.');
    if (!clientId) throw new Error('Client ID is required.');
    // Secret required only on first install; later saves reuse on-disk secret if field left blank.
    const hasSecretOnDisk = Boolean(
        backpackDetailCache && backpackDetailCache.has_client_secret_on_disk
    );
    if (!clientSecret && !hasSecretOnDisk) {
        throw new Error('Client secret is required for first install (it is not shown back after save).');
    }
    if (scope === 'single_lea' && !lea) throw new Error('District LEA ID is required for single_lea scope.');
    if (scope === 'multi_lea' && !allowed && !lea) {
        throw new Error('Region mode needs allowed LEA IDs (or a primary LEA).');
    }
    const settings = {
        connection_id: connectionId,
        base_url: baseUrl,
        client_id: clientId,
        client_secret: clientSecret,
        scope_mode: scope,
        credential_access_tier: tier,
    };
    if (lea) settings.district_lea_id = lea;
    if (allowed) settings.allowed_lea_ids = allowed;
    return settings;
}

function renderBackpackReportTable(report) {
    if (!backpackReportTable) return;
    const columns = Array.isArray(report && report.columns) ? report.columns : [];
    const rows = Array.isArray(report && report.rows) ? report.rows : [];
    if (!columns.length || !rows.length) {
        backpackReportTable.classList.add('d-none');
        backpackReportTable.innerHTML = '';
        return;
    }
    const head = columns.map((c) => `<th>${String(c)}</th>`).join('');
    const body = rows.map((row) => {
        const cells = columns.map((c) => {
            const v = row && Object.prototype.hasOwnProperty.call(row, c) ? row[c] : '';
            return `<td>${String(v === null || v === undefined ? '' : v)}</td>`;
        }).join('');
        return `<tr>${cells}</tr>`;
    }).join('');
    backpackReportTable.innerHTML = `<table class="pipeline-query-table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
    backpackReportTable.classList.remove('d-none');
}

let backpackReportCooldownUntil = 0;

function backpackReportCooldownLeft() {
    return Math.max(0, Math.ceil((backpackReportCooldownUntil - Date.now()) / 1000));
}

async function runBackpackReport(intent, options = {}) {
    const backpackId = selectedBackpackId;
    if (!backpackId) throw new Error('Select a backpack first.');
    const forceRefresh = Boolean(options.forceRefresh);
    const left = backpackReportCooldownLeft();
    // Local extract reads skip TEA — only block live refresh during cooldown
    if (forceRefresh && left > 0) {
        const msg = `TEA cooldown: wait ${left}s before Refresh from ODS. Use Show schools (local) if you already have an extract.`;
        if (backpackReportSummary) {
            backpackReportSummary.textContent = msg;
            backpackReportSummary.classList.add('text-warning');
        }
        setAction(msg);
        return { report_ok: false, error: msg, rate_limited: true };
    }
    const lea = backpackProbeLea ? String(backpackProbeLea.value || '').trim() : '';
    // Display limit for table/UI. Refresh schools uses full_lea on the server
    // (dynamic district size) — this number does not cap how many schools are extracted.
    let limit = 50;
    if (backpackReportLimit) {
        const n = Number(backpackReportLimit.value);
        if (Number.isFinite(n) && n > 0) limit = Math.min(2000, Math.floor(n));
    }
    const payload = await postAction('backpack_report', {
        backpack_id: backpackId,
        intent,
        lea,
        limit,
        role: 'account_admin',
        force_refresh: forceRefresh,
        prefer_local: !forceRefresh,
    });
    const nested = payload && payload.report && typeof payload.report === 'object' ? payload.report : null;
    const body = nested || payload || {};
    const reportOk = payload.report_ok !== undefined
        ? Boolean(payload.report_ok)
        : (body.ok !== false && !body.error);
    const err = String(payload.error || body.error || '').trim();
    const summary = String(payload.summary || body.summary || payload.message || '').trim();
    const rateLimited = Boolean(payload.rate_limited || body.rate_limited);
    if (rateLimited || /rate limit/i.test(err)) {
        backpackReportCooldownUntil = Date.now() + 60000;
    }
    if (backpackReportSummary) {
        if (!reportOk || err) {
            backpackReportSummary.textContent = err || summary || 'Report failed.';
            backpackReportSummary.classList.add('text-warning');
        } else {
            let src = '';
            if (payload.from_extract || body.from_extract) {
                src = ' [local extract]';
            } else if (payload.extract_saved || body.extract_saved) {
                src = ' [live ODS → saved local extract]';
            } else if (payload.live_pull || body.live_pull) {
                src = ' [live ODS]';
            } else if (payload.from_cache || body.from_cache) {
                src = ' [local profile]';
            }
            backpackReportSummary.textContent = (summary || `Report ${intent} complete.`) + src;
            backpackReportSummary.classList.remove('text-warning');
        }
    }
    const tableBody = {
        columns: payload.columns || body.columns || [],
        rows: payload.rows || body.rows || [],
    };
    renderBackpackReportTable(tableBody);
    if (backpackActionResult) {
        backpackActionResult.textContent = JSON.stringify(payload, null, 2);
    }
    if (!reportOk || err) {
        setAction(err || payload.message || 'backpack_report_failed');
    } else {
        setAction(payload.message || summary || 'backpack_report_ok');
    }
    return payload;
}

function mergeStatusPayload(base, update) {
    if (!update || typeof update !== 'object') return base || null;
    return {...(base && typeof base === 'object' ? base : {}), ...update};
}

function renderStatusSpine(status, metrics) {
    if (!status) {
        renderSubconscious(null);
        renderOperatorOutbox(null);
        renderLiveTracking(null);
        renderTemporalGovernance(null);
        return;
    }
    renderOperatorOutbox(status);
    renderOverviewStallRecovery(status);
    renderReleaseStatus(status);
    renderRuntimeSummary(status);
    renderGuardRuntime(status);
    renderHealthSummary(status);
    renderHeroDeck(status);
    renderLiveTracking(status);
    renderOverviewFocus(status);
    renderCenterMissionBrief(status);
    renderTelemetrySummary(metrics, status);
    renderTelemetryPressure(metrics, status);
    if (runtimeNoteBar && status.runtime_process_note != null) {
        runtimeNoteBar.textContent = String(latestStatus.runtime_process_note || '');
    }
    if (status.health_score != null || status.self_check_pass_ratio != null || Array.isArray(status.alerts)) {
        setHealthBadge(status.health_score, status.self_check_pass_ratio, status.alerts || []);
    }
}

function renderFullStatusSections(status, backendCommands) {
    if (!status) return;
    renderMetricGrid(status);
    renderSubconscious(status);
    renderOperatorMacros(status);
    renderBackendCommands(status, backendCommands);
    renderTemporalGovernance(status);
    renderPlannerInspector(status);
    renderLedgerInspector(status);
    renderPatchReadiness(status);
    renderActionReadiness(status);
    renderRuntimeTimeline(status);
    renderRuntimeFailures(status);
    renderRuntimeArtifacts(status);
    renderArtifactDetail(currentArtifactDetail);
    renderRestartAnalytics(status);
}

function scheduleLiveRefresh() {
    if (refreshTimerHandle) {
        clearTimeout(refreshTimerHandle);
    }
    refreshTimerHandle = setTimeout(async () => {
        await refresh();
        scheduleLiveRefresh();
    }, refreshBackoffMs);
}

async function performRefresh() {
    try {
        const activeView = currentMainViewName();
        const fetchFullStatus = shouldHydrateFullStatus(activeView);
        const fetchSessions = shouldHydrateSessions(activeView);
        const fetchWorkTreeVisuals = shouldHydrateWorkTrees(activeView);
        const fetchPipelinesDeck = shouldHydratePipelines(activeView);
        const fetchBackpacksDeck = shouldHydrateBackpacks(activeView);
        const results = await Promise.allSettled([
            getJson('/api/control/status/surfaces'),
            getJson('/api/control/policy'),
            getJson('/api/control/metrics'),
            fetchFullStatus ? getJson('/api/control/status') : Promise.resolve(null),
            fetchSessions ? getJson('/api/control/sessions') : Promise.resolve(null),
            fetchSessions ? getJson('/api/control/test-sessions') : Promise.resolve(null),
            fetchWorkTreeVisuals ? fetchWorkTrees() : Promise.resolve(null),
            fetchPipelinesDeck ? fetchPipelines() : Promise.resolve(null),
            fetchBackendCommandsDeck(),
            fetchBackpacksDeck ? fetchBackpacks() : Promise.resolve(null)
        ]);
        const surfacesStatus = results[0].status === 'fulfilled' ? results[0].value : null;
        latestPolicy = results[1].status === 'fulfilled' ? results[1].value : null;
        const metrics = results[2].status === 'fulfilled' ? results[2].value : null;
        const fullStatus = results[3].status === 'fulfilled' ? results[3].value : null;
        const sessions = results[4].status === 'fulfilled' ? results[4].value : null;
        const testRuns = results[5].status === 'fulfilled' ? results[5].value : null;
        const workTrees = results[6].status === 'fulfilled' ? results[6].value : null;
        const pipelines = results[7].status === 'fulfilled' ? results[7].value : null;
        const backendCommands = results[8].status === 'fulfilled' ? results[8].value : null;
        const backpacksPayload = results[9].status === 'fulfilled' ? results[9].value : null;
        latestMetrics = metrics;
        latestStatus = mergeStatusPayload(latestStatus, surfacesStatus);
        if (fullStatus) {
            latestStatus = mergeStatusPayload(latestStatus, fullStatus);
            lastFullStatusHydratedAt = Date.now();
        }
        renderStatusSpine(latestStatus, latestMetrics);
        if (latestStatus) {
            if (fullStatus || fetchFullStatus) {
                renderFullStatusSections(latestStatus, backendCommands);
            } else if (backendCommands) {
                renderBackendCommands(latestStatus, backendCommands);
            }
        } else {
            if (backendCommands) renderBackendCommands(null, backendCommands);
        }
        if (latestPolicy) {
            if (policyBox) policyBox.textContent = JSON.stringify(latestPolicy, null, 2);
            renderGovernance(latestPolicy, latestStatus);
        }
        if (metrics) drawMetrics(metrics.points || []);
        if (sessions) {
            sessionsCache = Array.isArray(sessions.sessions) ? sessions.sessions : [];
            renderSessions();
        } else if (fetchSessions) {
            renderSessionPreview();
        }
        if (testRuns) {
            testRunsCache = Array.isArray(testRuns.reports) ? testRuns.reports : [];
            testSessionDefinitions = Array.isArray(testRuns.definitions) ? testRuns.definitions : [];
            renderTestRuns();
            renderTestSessionDefinitions();
            renderRealWorldTasks();
        } else if (fetchSessions) {
            renderTestRunPreview();
            renderRealWorldTaskPreview();
        }
        if (workTrees) {
            renderWorkTrees(workTrees);
        } else if (fetchWorkTreeVisuals) {
            renderWorkTrees({ok: false, trees: [], counts: {total: 0, active: 0}});
        }
        if (pipelines) {
            renderPipelines(pipelines);
        } else if (fetchPipelinesDeck) {
            renderPipelines({ok: false, pipelines: [], detail: {}});
        }
        if (backpacksPayload) {
            backpacksCache = Array.isArray(backpacksPayload.backpacks)
                ? backpacksPayload.backpacks.filter((item) => item && typeof item === 'object')
                : [];
            // Keep local selection only; do not auto-pick the only backpack.
            if (selectedBackpackId && !backpacksCache.some((b) => String(b.backpack_id || '') === selectedBackpackId)) {
                selectedBackpackId = '';
            }
            if (backpackListSummary) {
                backpackListSummary.textContent = `${backpacksCache.length} backpack${backpacksCache.length === 1 ? '' : 's'} available. Select one to configure.`;
            }
            renderBackpackSelect();
            renderBackpackCards();
            renderBackpackDetail(backpacksPayload);
            lastBackpackHydratedAt = Date.now();
            backpackHydrateForced = false;
        } else if (fetchBackpacksDeck) {
            if (backpackCards) backpackCards.textContent = 'Backpack feed unavailable.';
            showBackpackDetail(false);
        }
        decorateActionButtons(document);
            maybeAutoArmLiveTracking();
        const labels = ['surfaces', 'policy', 'metrics', 'status-full', 'sessions', 'test-sessions', 'work-trees', 'pipelines', 'backend-commands', 'backpacks'];
        const requested = [true, true, true, fetchFullStatus, fetchSessions, fetchSessions, fetchWorkTreeVisuals, fetchPipelinesDeck, true, fetchBackpacksDeck];
        const failed = results
            .map((result, index) => ({result, index}))
            .filter((entry) => requested[entry.index] && entry.result.status !== 'fulfilled')
            .map((entry) => labels[entry.index]);
        if (!latestStatus && !latestPolicy && !metrics && !sessions && !testRuns && !workTrees && !pipelines && !backendCommands) throw new Error('All control endpoints failed');
        refreshBackoffMs = REFRESH_INTERVAL_MS;
        setFeedback(failed.length ? 'Partial refresh (' + failed.join(', ') + ' failed) at ' + new Date().toLocaleTimeString() : 'Live status refreshed at ' + new Date().toLocaleTimeString(), failed.length ? 'warn' : 'muted');
    } catch (error) {
        refreshBackoffMs = Math.min(Math.max(refreshBackoffMs, REFRESH_INTERVAL_MS) * 2, REFRESH_BACKOFF_MAX_MS);
        setAction('Refresh failed: ' + error.message);
    }
}

async function refresh() {
    if (refreshInFlight) {
        refreshQueued = true;
        return refreshInFlight;
    }
    do {
        refreshQueued = false;
        refreshInFlight = performRefresh();
        try {
            await refreshInFlight;
        } finally {
            refreshInFlight = null;
        }
    } while (refreshQueued);
}

function bindClick(id, handler) {
    const element = document.getElementById(id);
    if (!element) return;
    element.addEventListener('click', async (event) => {
        try {
            event.preventDefault();
            await handler(event);
        } catch (error) {
            setAction(id + ' failed: ' + (error.message || error));
        }
    });
}

if (sessionSelect) sessionSelect.addEventListener('change', renderSessionPreview);
if (sessionFilterSelect) sessionFilterSelect.addEventListener('change', renderSessions);
if (testRunSelect) testRunSelect.addEventListener('change', renderTestRunPreview);
if (workTreeSelect) {
    workTreeSelect.addEventListener('change', () => {
        selectedWorkTreeId = String(workTreeSelect.value || '').trim();
        selectedWorkTreeNodeId = '';
        renderSelectedWorkTreeView();
    });
}
bindClick('btnWorkTreeViewAll', () => setWorkTreeViewMode('all'));
bindClick('btnWorkTreeViewActive', () => setWorkTreeViewMode('active'));
bindClick('btnWorkTreeViewBlocked', () => setWorkTreeViewMode('blocked'));
if (operatorOutboxSelect) operatorOutboxSelect.addEventListener('change', () => renderOperatorOutbox(latestStatus));
if (patchPreviewSelect) patchPreviewSelect.addEventListener('change', () => renderPatchActionReadiness(latestStatus));
if (chatUserSelect && chatUserNameInput) {
    chatUserSelect.addEventListener('change', () => {
        const user = (chatUserSelect.value || '').trim();
        if (user) chatUserNameInput.value = user;
    });
}
navButtons.forEach((button) => {
    button.addEventListener('click', () => {
        setActiveView(button.getAttribute('data-view-target') || 'overview');
        refresh();
    });
});
if (centerTabBar) {
    centerTabBar.addEventListener('click', (event) => {
        const button = resolveCenterTabButton(event.target);
        if (!button) {
            return;
        }
        event.preventDefault();
        setCenterTab(button.getAttribute('data-center-tab') || 'system-matrix');
    });
    centerTabBar.addEventListener('keydown', (event) => {
        const button = resolveCenterTabButton(event.target);
        if (!button) {
            return;
        }
        if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
            event.preventDefault();
            focusCenterTabByOffset(button, 1);
            return;
        }
        if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
            event.preventDefault();
            focusCenterTabByOffset(button, -1);
            return;
        }
        if (event.key === 'Home') {
            event.preventDefault();
            const firstButton = centerTabButtons[0];
            if (firstButton) {
                setCenterTab(firstButton.getAttribute('data-center-tab') || 'system-matrix');
                firstButton.focus();
            }
            return;
        }
        if (event.key === 'End') {
            event.preventDefault();
            const lastButton = centerTabButtons[centerTabButtons.length - 1];
            if (lastButton) {
                setCenterTab(lastButton.getAttribute('data-center-tab') || 'system-matrix');
                lastButton.focus();
            }
            return;
        }
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            setCenterTab(button.getAttribute('data-center-tab') || 'system-matrix');
        }
    });
}

if (telemetryGraphToolbar) {
    telemetryGraphToolbar.addEventListener('click', (event) => {
        const button = event.target && typeof event.target.closest === 'function' ? event.target.closest('[data-telemetry-graph]') : null;
        if (!button) {
            return;
        }
        event.preventDefault();
        setTelemetryGraphMode(button.getAttribute('data-telemetry-graph') || 'combined');
    });
    telemetryGraphToolbar.addEventListener('keydown', (event) => {
        const button = event.target && typeof event.target.closest === 'function' ? event.target.closest('[data-telemetry-graph]') : null;
        if (!button) {
            return;
        }
        const currentIndex = telemetryGraphButtons.indexOf(button);
        if (currentIndex < 0) {
            return;
        }
        if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
            event.preventDefault();
            const next = telemetryGraphButtons[(currentIndex + 1) % telemetryGraphButtons.length];
            if (next) {
                setTelemetryGraphMode(next.getAttribute('data-telemetry-graph') || 'combined');
                next.focus();
            }
            return;
        }
        if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
            event.preventDefault();
            const next = telemetryGraphButtons[(currentIndex - 1 + telemetryGraphButtons.length) % telemetryGraphButtons.length];
            if (next) {
                setTelemetryGraphMode(next.getAttribute('data-telemetry-graph') || 'combined');
                next.focus();
            }
            return;
        }
        if (event.key === 'Home') {
            event.preventDefault();
            const first = telemetryGraphButtons[0];
            if (first) {
                setTelemetryGraphMode(first.getAttribute('data-telemetry-graph') || 'combined');
                first.focus();
            }
            return;
        }
        if (event.key === 'End') {
            event.preventDefault();
            const last = telemetryGraphButtons[telemetryGraphButtons.length - 1];
            if (last) {
                setTelemetryGraphMode(last.getAttribute('data-telemetry-graph') || 'combined');
                last.focus();
            }
            return;
        }
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            setTelemetryGraphMode(button.getAttribute('data-telemetry-graph') || 'combined');
        }
    });
}

if (inspectorTabBar) {
    inspectorTabBar.addEventListener('click', (event) => {
        const button = resolveInspectorTabButton(event.target);
        if (!button) {
            return;
        }
        event.preventDefault();
        setInspectorTab(button.getAttribute('data-inspector-tab') || 'planner');
    });
    inspectorTabBar.addEventListener('keydown', (event) => {
        const button = resolveInspectorTabButton(event.target);
        if (!button) {
            return;
        }
        if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
            event.preventDefault();
            focusInspectorTabByOffset(button, 1);
            return;
        }
        if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
            event.preventDefault();
            focusInspectorTabByOffset(button, -1);
            return;
        }
        if (event.key === 'Home') {
            event.preventDefault();
            const firstButton = inspectorTabButtons[0];
            if (firstButton) {
                setInspectorTab(firstButton.getAttribute('data-inspector-tab') || 'planner');
                firstButton.focus();
            }
            return;
        }
        if (event.key === 'End') {
            event.preventDefault();
            const lastButton = inspectorTabButtons[inspectorTabButtons.length - 1];
            if (lastButton) {
                setInspectorTab(lastButton.getAttribute('data-inspector-tab') || 'planner');
                lastButton.focus();
            }
            return;
        }
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            setInspectorTab(button.getAttribute('data-inspector-tab') || 'planner');
        }
    });
}

layerTabShells.forEach((shell) => {
    const context = getLayerTabContext(shell);
    if (!context || !context.bar || !context.buttons.length) {
        return;
    }
    context.bar.addEventListener('click', (event) => {
        const button = resolveLayerTabButton(shell, event.target);
        if (!button) {
            return;
        }
        event.preventDefault();
        setLayerTab(shell, button.getAttribute('data-layer-tab') || '');
    });
    context.bar.addEventListener('keydown', (event) => {
        const button = resolveLayerTabButton(shell, event.target);
        if (!button) {
            return;
        }
        if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
            event.preventDefault();
            focusLayerTabByOffset(shell, button, 1);
            return;
        }
        if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
            event.preventDefault();
            focusLayerTabByOffset(shell, button, -1);
            return;
        }
        if (event.key === 'Home') {
            event.preventDefault();
            const firstButton = context.buttons[0];
            if (firstButton) {
                setLayerTab(shell, firstButton.getAttribute('data-layer-tab') || '');
                firstButton.focus();
            }
            return;
        }
        if (event.key === 'End') {
            event.preventDefault();
            const lastButton = context.buttons[context.buttons.length - 1];
            if (lastButton) {
                setLayerTab(shell, lastButton.getAttribute('data-layer-tab') || '');
                lastButton.focus();
            }
            return;
        }
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            setLayerTab(shell, button.getAttribute('data-layer-tab') || '');
        }
    });
    setLayerTab(shell, context.buttons[0].getAttribute('data-layer-tab') || '');
});

function syncShellToggleState() {
    const sidebarCollapsed = document.body.classList.contains('sidebar-collapsed');
    const inspectorCollapsed = document.body.classList.contains('inspector-collapsed');

    if (btnSidebarToggle) {
        btnSidebarToggle.setAttribute('aria-pressed', sidebarCollapsed ? 'true' : 'false');
        btnSidebarToggle.setAttribute('title', sidebarCollapsed ? 'Expand menu' : 'Collapse menu');
        btnSidebarToggle.setAttribute('aria-label', sidebarCollapsed ? 'Expand menu' : 'Collapse menu');
    }

    if (btnInspectorToggle) {
        btnInspectorToggle.setAttribute('aria-pressed', inspectorCollapsed ? 'true' : 'false');
        btnInspectorToggle.setAttribute('title', inspectorCollapsed ? 'Expand live inspector' : 'Collapse live inspector');
        btnInspectorToggle.setAttribute('aria-label', inspectorCollapsed ? 'Expand live inspector' : 'Collapse live inspector');
    }
}

bindClick('btnSidebarToggle', async () => {
    document.body.classList.toggle('sidebar-collapsed');
    syncShellToggleState();
    setFeedback(document.body.classList.contains('sidebar-collapsed') ? 'Menu collapsed.' : 'Menu expanded.', 'muted');
});

bindClick('btnInspectorToggle', async () => {
    document.body.classList.toggle('inspector-collapsed');
    syncShellToggleState();
    setFeedback(document.body.classList.contains('inspector-collapsed') ? 'Inspector collapsed.' : 'Inspector expanded.', 'muted');
});
bindClick('btnRefresh', refresh);
bindClick('btnPatchPreviewRefresh', async () => {
    const payload = await postAction('patch_preview_list');
    if (payload.patch) {
        latestStatus = {
            ...(latestStatus || {}),
            ...payload.patch,
            patch_previews: Array.isArray(payload.previews) ? payload.previews : [],
            patch_action_readiness: payload.patch_action_readiness || (latestStatus && latestStatus.patch_action_readiness ? latestStatus.patch_action_readiness : {}),
        };
    }
    renderPatchReadiness(latestStatus || {patch_previews: Array.isArray(payload.previews) ? payload.previews : []});
    setAction(`Patch preview queue refreshed (${Array.isArray(payload.previews) ? payload.previews.length : 0} previews).`);
});
bindClick('btnPatchPreviewShow', async () => {
    const preview = patchPreviewSelect ? (patchPreviewSelect.value || '').trim() : '';
    const payload = await postAction('patch_preview_show', {preview});
    if (patchPreviewBox) {
        patchPreviewBox.textContent = payload.text || `Preview loaded: ${preview}`;
    }
    renderPatchPreviewSummary(payload.text || '', preview);
    await refresh();
    setAction(payload.text || `Preview loaded: ${preview}`);
});
bindClick('btnPatchPreviewApprove', async () => {
    const preview = patchPreviewSelect ? (patchPreviewSelect.value || '').trim() : '';
    const note = patchPreviewNote ? patchPreviewNote.value.trim() : '';
    const payload = await postAction('patch_preview_approve', {preview, note});
    if (patchPreviewBox) {
        patchPreviewBox.textContent = `${payload.text || 'Approved.'}${preview ? `\nPreview: ${preview}` : ''}${note ? `\nNote: ${note}` : ''}`;
    }
    await refresh();
    setAction(`${payload.text || 'Approved.'}${preview ? `\nPreview: ${preview}` : ''}${note ? `\nNote: ${note}` : ''}`);
});
bindClick('btnPatchPreviewReject', async () => {
    const preview = patchPreviewSelect ? (patchPreviewSelect.value || '').trim() : '';
    const note = patchPreviewNote ? patchPreviewNote.value.trim() : '';
    const payload = await postAction('patch_preview_reject', {preview, note});
    if (patchPreviewBox) {
        patchPreviewBox.textContent = `${payload.text || 'Rejected.'}${preview ? `\nPreview: ${preview}` : ''}${note ? `\nNote: ${note}` : ''}`;
    }
    await refresh();
    setAction(`${payload.text || 'Rejected.'}${preview ? `\nPreview: ${preview}` : ''}${note ? `\nNote: ${note}` : ''}`);
});
bindClick('btnPatchPreviewApply', async () => {
    const preview = patchPreviewSelect ? (patchPreviewSelect.value || '').trim() : '';
    const targetLabel = preview || 'the selected preview';
    const confirmed = window.confirm(`Apply ${targetLabel} to the live workspace? This will run the normal patch governance path, including compile and behavioral validation.`);
    if (!confirmed) {
        setAction(`Patch apply canceled for ${targetLabel}.`);
        return;
    }
    const payload = await postAction('patch_preview_apply', {preview});
    if (patchPreviewBox) {
        patchPreviewBox.textContent = `${payload.text || 'Patch apply completed.'}${preview ? `\nPreview: ${preview}` : ''}${payload.zip ? `\nZip: ${payload.zip}` : ''}`;
    }
    await refresh();
    setAction(`${payload.text || 'Patch apply completed.'}${preview ? `\nPreview: ${preview}` : ''}${payload.zip ? `\nZip: ${payload.zip}` : ''}`);
});
bindClick('btnLogout', async () => {
    await fetch('/api/control/logout', {method: 'POST', headers: controlHeaders(), body: '{}'});
    window.location.href = '/control';
});
bindClick('btnSessionsRefresh', async () => {
    const payload = await getJson('/api/control/sessions');
    sessionsCache = Array.isArray(payload.sessions) ? payload.sessions : [];
    renderSessions();
    setAction('Session list refreshed.');
});
bindClick('btnTestRunsRefresh', async () => {
    const payload = await getJson('/api/control/test-sessions');
    testRunsCache = Array.isArray(payload.reports) ? payload.reports : [];
    testSessionDefinitions = Array.isArray(payload.definitions) ? payload.definitions : [];
    renderTestRuns();
    renderTestSessionDefinitions();
    renderRealWorldTasks();
    setAction('Parity test runs refreshed.');
});
bindClick('btnWorkTreeRefresh', async () => {
    await refresh();
    setAction('Scheduled Tree refreshed.');
});
bindClick('btnPipelinesRefresh', async () => {
    await loadPipelines();
    setAction('Data lanes refreshed.');
});
bindClick('btnBackpacksRefresh', async () => {
    await withBackpackBusy('Refreshing backpacks…', 'btnBackpacksRefresh', async () => {
        selectedBackpackId = '';
        if (bpFieldClientSecret) bpFieldClientSecret.value = '';
        await loadBackpacks();
        setAction('Backpacks refreshed. Select a backpack to continue.');
    });
});
if (backpackSelect) {
    backpackSelect.addEventListener('change', async () => {
        selectedBackpackId = String(backpackSelect.value || '').trim();
        if (bpFieldClientSecret) bpFieldClientSecret.value = '';
        await withBackpackBusy('Loading backpack…', null, async () => {
            await loadBackpacks();
        });
    });
}
bindClick('btnBackpackEnable', async () => {
    const backpackId = selectedBackpackId;
    if (!backpackId) return setAction('Select a backpack first.');
    await withBackpackBusy('Turning backpack on…', 'btnBackpackEnable', async () => {
        const payload = await postAction('backpack_set_enabled', { backpack_id: backpackId, enabled: true });
        if (backpackActionResult) backpackActionResult.textContent = JSON.stringify(payload, null, 2);
        await loadBackpacks();
        setAction(payload.message || 'backpack_enabled');
    });
});
bindClick('btnBackpackDisable', async () => {
    const backpackId = selectedBackpackId;
    if (!backpackId) return setAction('Select a backpack first.');
    await withBackpackBusy('Turning backpack off…', 'btnBackpackDisable', async () => {
        const payload = await postAction('backpack_set_enabled', { backpack_id: backpackId, enabled: false });
        if (backpackActionResult) backpackActionResult.textContent = JSON.stringify(payload, null, 2);
        await loadBackpacks();
        setAction(payload.message || 'backpack_disabled');
    });
});
bindClick('btnBackpackSaveSettings', async () => {
    const backpackId = selectedBackpackId || (backpackSelect ? backpackSelect.value : '');
    if (!backpackId) return setAction('Select a backpack first.');
    let settings;
    try {
        settings = parseBackpackSettingsFromUi();
    } catch (error) {
        return setAction(String(error && error.message ? error.message : error));
    }
    await withBackpackBusy('Saving settings…', 'btnBackpackSaveSettings', async () => {
        const payload = await postAction('backpack_settings_save', {
            backpack_id: backpackId,
            settings,
            skip_profile: true,
        });
        if (backpackActionResult) backpackActionResult.textContent = JSON.stringify(payload, null, 2);
        if (bpFieldClientSecret) bpFieldClientSecret.value = '';
        await loadBackpacks();
        setAction(payload.message || 'backpack_settings_saved');
    });
});
bindClick('btnBackpackInstall', async () => {
    const backpackId = selectedBackpackId || (backpackSelect ? backpackSelect.value : '');
    if (!backpackId) return setAction('Select a backpack first.');
    let settings;
    try {
        settings = parseBackpackSettingsFromUi();
    } catch (error) {
        return setAction(String(error && error.message ? error.message : error));
    }
    await withBackpackBusy('Installing and profiling ODS (can take a minute)…', 'btnBackpackInstall', async () => {
        const payload = await postAction('backpack_install', {
            backpack_id: backpackId,
            settings,
        });
        if (backpackActionResult) backpackActionResult.textContent = JSON.stringify(payload, null, 2);
        if (bpFieldClientSecret) bpFieldClientSecret.value = '';
        await loadBackpacks();
        setAction(payload.message || 'backpack_install_ok');
    });
});
bindClick('btnBackpackProbeLea', async () => {
    const backpackId = selectedBackpackId;
    if (!backpackId) return setAction('Select a backpack first.');
    const lea = backpackProbeLea ? String(backpackProbeLea.value || '').trim() : '';
    if (!lea) return setAction('Enter an LEA id to probe (e.g. 031901).');
    await withBackpackBusy('Probing LEA…', 'btnBackpackProbeLea', async () => {
        const payload = await postAction('backpack_probe_lea', {
            backpack_id: backpackId,
            lea,
            limit: 3,
            role: 'account_admin',
        });
        if (backpackActionResult) backpackActionResult.textContent = JSON.stringify(payload, null, 2);
        setAction(payload.message || 'backpack_probe_lea_ok');
    });
});
bindClick('btnBackpackReportHealth', async () => {
    if (!selectedBackpackId) return setAction('Select a backpack first.');
    await withBackpackBusy('Loading health (local profile)…', 'btnBackpackReportHealth', async () => {
        await runBackpackReport('health', { forceRefresh: false });
    });
});
bindClick('btnBackpackReportSchools', async () => {
    if (!selectedBackpackId) return setAction('Select a backpack first.');
    // Default: local extract only — does not hit TEA when extract exists.
    await withBackpackBusy(
        'Loading schools from local extract…',
        'btnBackpackReportSchools',
        async () => {
            await runBackpackReport('schools', { forceRefresh: false });
        },
        { minMs: 600 }
    );
});
bindClick('btnBackpackRefreshSchools', async () => {
    if (!selectedBackpackId) return setAction('Select a backpack first.');
    await withBackpackBusy(
        'Refreshing schools from TEA ODS (slow; may rate-limit)…',
        'btnBackpackRefreshSchools',
        async () => {
            await runBackpackReport('schools', { forceRefresh: true });
        },
        { minMs: 1200 }
    );
});
bindClick('btnPipelineCreate', async () => {
    const pipelineId = pipelineCreateId ? pipelineCreateId.value.trim() : '';
    const displayName = pipelineCreateName ? pipelineCreateName.value.trim() : '';
    if (!pipelineId) return setAction('Add a lane id before creating a data lane.');
    const payload = await postAction('pipeline_create', {pipeline_id: pipelineId, display_name: displayName});
    if (pipelineCreateId) pipelineCreateId.value = '';
    if (pipelineCreateName) pipelineCreateName.value = '';
    selectedPipelineId = String(payload.pipeline_id || pipelineId).trim();
    await loadPipelines(selectedPipelineId);
    setAction(payload.message || 'pipeline_created');
});
bindClick('btnPipelineStart', async () => {
    const pipelineId = pipelineSelect ? String(pipelineSelect.value || '').trim() : selectedPipelineId;
    if (!pipelineId) return setAction('Select a data lane to start.');
    const payload = await postAction('pipeline_start', {pipeline_id: pipelineId});
    await loadPipelines(pipelineId);
    setAction(payload.message || 'pipeline_started');
});
bindClick('btnPipelinePause', async () => {
    const pipelineId = pipelineSelect ? String(pipelineSelect.value || '').trim() : selectedPipelineId;
    if (!pipelineId) return setAction('Select a data lane to pause.');
    const payload = await postAction('pipeline_pause', {pipeline_id: pipelineId});
    await loadPipelines(pipelineId);
    setAction(payload.message || 'pipeline_paused');
});
bindClick('btnPipelineUpdate', async () => {
    const pipelineId = pipelineSelect ? String(pipelineSelect.value || '').trim() : selectedPipelineId;
    if (!pipelineId) return setAction('Select a data lane to update.');
    const payload = {
        pipeline_id: pipelineId,
        display_name: pipelineEditName ? pipelineEditName.value.trim() : '',
        description: pipelineEditDescription ? pipelineEditDescription.value.trim() : '',
        network_scope: pipelineEditScope ? pipelineEditScope.value.trim() : ''
    };
    const result = await postAction('pipeline_update', payload);
    await loadPipelines(pipelineId);
    setAction(result.message || 'pipeline_metadata_updated');
});
bindClick('btnPipelinePopulationSave', async () => {
    const pipelineId = pipelineSelect ? String(pipelineSelect.value || '').trim() : selectedPipelineId;
    if (!pipelineId) return setAction('Select a data lane before saving a population.');
    const payload = {
        pipeline_id: pipelineId,
        key: pipelinePopulationKey ? pipelinePopulationKey.value.trim() : '',
        label: pipelinePopulationLabel ? pipelinePopulationLabel.value.trim() : '',
        program_id: pipelinePopulationProgram ? pipelinePopulationProgram.value.trim() : '',
        field_number: pipelinePopulationField ? pipelinePopulationField.value.trim() : '',
        notes: pipelinePopulationNotes ? pipelinePopulationNotes.value.trim() : ''
    };
    if (!payload.key) return setAction('Add a population key before saving.');
    if (!payload.program_id || !payload.field_number) return setAction('Add PROGRAM_ID and FIELD_NUMBER before saving.');
    const result = await postAction('pipeline_population_upsert', payload);
    if (pipelinePopulationKey) pipelinePopulationKey.value = '';
    if (pipelinePopulationLabel) pipelinePopulationLabel.value = '';
    if (pipelinePopulationProgram) pipelinePopulationProgram.value = '';
    if (pipelinePopulationField) pipelinePopulationField.value = '';
    if (pipelinePopulationNotes) pipelinePopulationNotes.value = '';
    await loadPipelines(pipelineId);
    setAction(result.message || 'pipeline_population_saved');
});
bindClick('btnPipelineArchive', async () => {
    const pipelineId = pipelineSelect ? String(pipelineSelect.value || '').trim() : selectedPipelineId;
    if (!pipelineId) return setAction('Select a data lane to delete.');
    const confirmed = window.confirm(`Archive data lane ${pipelineId}? It will be removed from active lanes but kept under data_sources/_archived.`);
    if (!confirmed) return setAction('Data lane delete canceled.');
    const payload = await postAction('pipeline_archive', {pipeline_id: pipelineId});
    selectedPipelineId = '';
    await loadPipelines();
    setAction(payload.message || 'pipeline_archived');
});
bindClick('btnPipelineQueryPreview', async () => {
    await executePipelineQuery({live: false});
});
bindClick('btnPipelineQueryRun', async () => {
    await executePipelineQuery({live: true});
});
bindClick('btnEdfiQuickHealth', async () => {
    await executePipelineQuery({live: true, operation: 'connection_health', rowLimit: 1, params: {}, confirmLive: false});
});
bindClick('btnEdfiQuickSchools', async () => {
    await executePipelineQuery({live: true, operation: 'list_schools', rowLimit: 10, params: {offset: 0}, confirmLive: false});
});
bindClick('btnEdfiQuickStudents', async () => {
    await executePipelineQuery({live: true, operation: 'list_students', rowLimit: 10, params: {offset: 0}, confirmLive: false});
});
bindClick('btnEdfiQuickSync', async () => {
    await executePipelineQuery({live: true, operation: 'sync_status', rowLimit: 1, params: {}, confirmLive: false});
});
bindClick('btnEdfiQuickChanges', async () => {
    await executePipelineQuery({
        live: true,
        operation: 'changes_since',
        rowLimit: 10,
        params: {resource: 'ed-fi/schools', advance_cursor: true},
        confirmLive: false,
    });
});
bindClick('btnPipelineNoteSave', async () => {
    const pipelineId = pipelineSelect ? String(pipelineSelect.value || '').trim() : selectedPipelineId;
    const note = pipelineNoteInput ? pipelineNoteInput.value.trim() : '';
    const noteType = pipelineNoteType ? pipelineNoteType.value : 'operator_grounding';
    if (!pipelineId) return setAction('Select a pipeline before saving a note.');
    if (!note) return setAction('Add a pipeline note before saving.');
    const payload = await postAction('pipeline_note_append', {pipeline_id: pipelineId, note_type: noteType, note});
    if (pipelineNoteInput) pipelineNoteInput.value = '';
    await loadPipelines(pipelineId);
    setAction(payload.message || 'pipeline_note_recorded');
});
bindClick('btnWorkTreesRefresh', async () => {
    await refresh();
    setAction('Scheduled Tree refreshed.');
});
bindClick('btnOpenScheduledTreeFromSessions', async () => {
    setActiveView('scheduled-tree');
    await refresh();
    setAction('Scheduled Tree opened from Live Sessions.');
});
bindClick('btnOpenScheduledTreeFromParity', async () => {
    setActiveView('scheduled-tree');
    await refresh();
    setAction('Scheduled Tree opened from Parity Runs.');
});
bindClick('btnTestRunExecute', async () => {
    const sessionFile = testSessionDefinitionSelect ? (testSessionDefinitionSelect.value || '').trim() : '';
    if (!sessionFile) return setAction('Select a saved test session first.');
    setAction('Running parity test session: ' + sessionFile);
    const payload = await postAction('test_session_run', {session_file: sessionFile});
    testRunsCache = Array.isArray(payload.reports) ? payload.reports : testRunsCache;
    testSessionDefinitions = Array.isArray(payload.definitions) ? payload.definitions : testSessionDefinitions;
    renderTestRuns();
    renderTestSessionDefinitions();
    renderRealWorldTasks();
    if (payload.latest_report && testRunSelect && payload.latest_report.run_id) {
        testRunSelect.value = payload.latest_report.run_id;
        renderTestRunPreview();
    }
    const summary = String(payload.message || 'test_session_run completed');
    const output = String(payload.stdout || '').trim();
    setAction(output ? `${summary}\n\n${output}` : summary);
});
bindClick('btnGeneratedPackRun', async () => {
    const payload = await postAction('generated_pack_run', {limit: 12, mode: 'recent'});
    testRunsCache = Array.isArray(payload.reports) ? payload.reports : testRunsCache;
    testSessionDefinitions = Array.isArray(payload.definitions) ? payload.definitions : testSessionDefinitions;
    renderTestRuns();
    renderTestSessionDefinitions();
    renderRealWorldTasks();
    const results = Array.isArray(payload.results) ? payload.results : [];
    const summary = `${payload.message || 'generated_pack_run completed'}\n` + results.map((item) => `- ${item.file}: ${item.ok ? 'OK' : 'FAIL'}${item.message ? ' (' + item.message + ')' : ''}`).join('\n');
    setAction(summary.trim());
});
bindClick('btnGeneratedPriorityRun', async () => {
    const payload = await postAction('generated_pack_run', {limit: 8, mode: 'priority'});
    testRunsCache = Array.isArray(payload.reports) ? payload.reports : testRunsCache;
    testSessionDefinitions = Array.isArray(payload.definitions) ? payload.definitions : testSessionDefinitions;
    renderTestRuns();
    renderTestSessionDefinitions();
    renderRealWorldTasks();
    const results = Array.isArray(payload.results) ? payload.results : [];
    const summary = `${payload.message || 'generated priority run completed'}\n` + results.map((item) => `- ${item.file}: ${item.ok ? 'OK' : 'FAIL'}${item.message ? ' (' + item.message + ')' : ''}`).join('\n');
    setAction(summary.trim());
});
bindClick('btnWorkTreeRunNext', async () => {
    if (workTreeActionFeedback) workTreeActionFeedback.textContent = 'Running next step…';
    try {
        // Operator click: always override mission quiet/green hold. Without this,
        // the action only wrote a trigger that maintenance discarded on hold.
        const body = {
            operator_override: true,
            max_steps: 1,
            max_trees: 1,
        };
        if (_inspectorBranchId) {
            body.branch_id = _inspectorBranchId;
            body.target_branch_id = _inspectorBranchId;
        }
        // Prefer selected tree/task context when present on the inspector node.
        try {
            const tree = (workTreesCache || []).find((row) => String(row.tree_id || '') === String(selectedWorkTreeId || ''));
            const node = tree && Array.isArray(tree.nodes)
                ? tree.nodes.find((n) => String(n.id || n.branch_id || '') === String(_inspectorBranchId || ''))
                : null;
            const task = node && node.current_task && typeof node.current_task === 'object' ? node.current_task : null;
            if (task && task.task_id) {
                body.task_id = String(task.task_id);
                body.target_task_id = String(task.task_id);
            }
            if (tree && tree.tree_id) {
                body.target_tree_id = String(tree.tree_id);
            }
            const tool = String((node && node.preferred_tool) || '').trim();
            if (tool) body.recommended_tool = tool;
        } catch (_ctxErr) {
            // keep branch-only body
        }
        const payload = await postAction('active_work_tree_run_next', body);
        // Extra fields are merged onto the response body by the control API.
        const cycle = payload.cycle && typeof payload.cycle === 'object' ? payload.cycle : {};
        const executed = Number(payload.executed_count != null ? payload.executed_count : cycle.executed_count);
        const hist = Array.isArray(cycle.history) ? cycle.history : [];
        const last = hist.length ? hist[hist.length - 1] : null;
        let line = String(payload.message || 'Step finished.');
        if (Number.isFinite(executed)) {
            line += ` · executed=${executed}`;
        }
        if (last && last.action) {
            line += ` · last=${last.action}`;
            if (last.tool) line += `/${last.tool}`;
            if (last.task_title) line += ` · ${last.task_title}`;
            if (last.error) line += ` · error=${last.error}`;
        }
        if (payload.triggered && !payload.executed_now) {
            line += ' · queued for maintenance worker';
        }
        if (workTreeActionFeedback) workTreeActionFeedback.textContent = line;
        // Refresh tree so progress ring updates after a real step.
        try {
            const trees = await fetchWorkTrees();
            if (trees) renderWorkTrees(trees);
        } catch (_refreshErr) {
            // non-fatal
        }
    } catch (err) {
        if (workTreeActionFeedback) workTreeActionFeedback.textContent = 'Error: ' + (err.message || 'unknown');
    }
});
bindClick('btnPatchQueueRunNext', async () => {
    setAction('Triggering patch queue step…');
    const payload = await postAction('patch_queue_run_next', {});
    setAction(payload.message || 'patch_queue_step_dispatched');
});
bindClick('btnPulseStatus', async () => {
    setAction('Refreshing pulse status…');
    const payload = await postAction('pulse_status', {});
    setAction(payload.message || 'pulse_status_refreshed');
});
bindClick('btnGeneratedQueueRunNext', async () => {
    await runNextGeneratedQueueItem();
});
bindClick('btnGeneratedQueueRunNextOps', async () => {
    await runNextGeneratedQueueItem();
});
bindClick('btnGeneratedQueueInvestigate', async () => {
    await investigateNextGeneratedQueueItem();
});
bindClick('btnGeneratedQueueInvestigateOps', async () => {
    await investigateNextGeneratedQueueItem();
});
bindClick('btnMaintenanceWorkerStart', async () => {
    await startAutonomyMaintenanceWorker();
});
bindClick('btnMaintenanceWorkerStop', async () => {
    await stopAutonomyMaintenanceWorker();
});
bindClick('btnMaintenanceWorkerStartOps', async () => {
    await startAutonomyMaintenanceWorker();
});
bindClick('btnMaintenanceWorkerStopOps', async () => {
    await stopAutonomyMaintenanceWorker();
});
bindClick('btnTaskManagerRefresh', async () => {
    const payload = await getJson('/api/control/test-sessions');
    testRunsCache = Array.isArray(payload.reports) ? payload.reports : testRunsCache;
    testSessionDefinitions = Array.isArray(payload.definitions) ? payload.definitions : testSessionDefinitions;
    renderTestRuns();
    renderTestSessionDefinitions();
    renderRealWorldTasks();
    setAction('Real-world task library refreshed.');
});
bindClick('btnTaskManagerRun', async () => {
    const task = selectedRealWorldTask();
    if (!task) {
        setAction('Select a real-world task first.');
        return;
    }
    setAction('Running real-world task: ' + String(task.file || task.name || 'task'));
    const payload = await postAction('test_session_run', {session_file: String(task.file || '').trim()});
    testRunsCache = Array.isArray(payload.reports) ? payload.reports : testRunsCache;
    testSessionDefinitions = Array.isArray(payload.definitions) ? payload.definitions : testSessionDefinitions;
    renderTestRuns();
    renderTestSessionDefinitions();
    renderRealWorldTasks();
    if (payload.latest_report && testRunSelect && payload.latest_report.run_id) {
        testRunSelect.value = payload.latest_report.run_id;
        renderTestRunPreview();
    }
    const summary = String(payload.message || 'real-world task run completed');
    const output = String(payload.stdout || '').trim();
    setAction(output ? `${summary}\n\n${output}` : summary);
});
bindClick('btnTaskManagerCreate', async () => {
    const payload = await postAction('real_world_task_create', {
        name: taskManagerName ? taskManagerName.value.trim() : '',
        task_id: taskManagerTaskId ? taskManagerTaskId.value.trim() : '',
        category: taskManagerCategory ? taskManagerCategory.value : 'operator',
        objective: taskManagerObjective ? taskManagerObjective.value.trim() : '',
        prompt: taskManagerPrompt ? taskManagerPrompt.value.trim() : '',
        followup: taskManagerFollowup ? taskManagerFollowup.value.trim() : '',
        notes: taskManagerNotes ? taskManagerNotes.value.trim() : '',
    });
    testSessionDefinitions = Array.isArray(payload.definitions) ? payload.definitions : testSessionDefinitions;
    renderTestSessionDefinitions();
    renderRealWorldTasks();
    if (payload.task && payload.task.file && taskManagerSelect) {
        taskManagerSelect.value = payload.task.file;
        renderRealWorldTaskPreview();
    }
    if (taskManagerName) taskManagerName.value = '';
    if (taskManagerTaskId) taskManagerTaskId.value = '';
    if (taskManagerObjective) taskManagerObjective.value = '';
    if (taskManagerPrompt) taskManagerPrompt.value = '';
    if (taskManagerFollowup) taskManagerFollowup.value = '';
    if (taskManagerNotes) taskManagerNotes.value = '';
    setAction(payload.message || 'Real-world task created.');
});
bindClick('btnSessionOpen', async () => {
    const session = selectedSession();
    if (!session) return setAction('Select a session first.');
    window.open('/?sid=' + encodeURIComponent(session.session_id), '_blank');
});
bindClick('btnSessionCopy', async () => {
    const session = selectedSession();
    if (!session) return setAction('Select a session first.');
    try {
        await navigator.clipboard.writeText(session.session_id);
        setAction('Session ID copied: ' + session.session_id);
    } catch (_) {
        setAction('Unable to copy to clipboard. Session ID: ' + session.session_id);
    }
});
bindClick('btnTestRunCopy', async () => {
    const run = selectedTestRun();
    if (!run) return setAction('Select a test run first.');
    const value = String(run.report_path || '').trim();
    if (!value) return setAction('Selected test run has no report path.');
    try {
        await navigator.clipboard.writeText(value);
        setAction('Report path copied: ' + value);
    } catch (_) {
        setAction('Unable to copy to clipboard. Report path: ' + value);
    }
});
bindClick('btnSessionDelete', async () => {
    const session = selectedSession();
    if (!session) return setAction('Select a session first.');
    const payload = await postAction('session_delete', {session_id: session.session_id});
    sessionsCache = Array.isArray(payload.sessions) ? payload.sessions : sessionsCache.filter((item) => item.session_id !== session.session_id);
    renderSessions();
    setAction(payload.message || 'Session deleted.');
});
bindClick('btnOperatorSend', async () => {
    await sendOperatorPrompt();
});
bindClick('btnOperatorMacroApply', async () => {
    const macro = selectedOperatorMacro();
    if (!macro) {
        setAction('Select an operator macro first.');
        return;
    }
    const values = await resolveOperatorMacroValues(macro);
    if (values === null) return;
    if (operatorPromptInput) operatorPromptInput.value = renderOperatorMacroPrompt(macro, values);
    setAction('Operator macro loaded: ' + String(macro.label || macro.macro_id || 'macro'));
});
bindClick('btnOperatorMacroRun', async () => {
    const macro = selectedOperatorMacro();
    if (!macro) {
        setAction('Select an operator macro first.');
        return;
    }
    const values = await resolveOperatorMacroValues(macro);
    if (values === null) return;
    if (operatorPromptInput && !operatorPromptInput.value.trim()) {
        operatorPromptInput.value = renderOperatorMacroPrompt(macro, values);
    }
    await sendOperatorPrompt();
});
bindClick('btnOperatorNewSession', async () => {
    const newId = 'operator-' + Math.random().toString(16).slice(2, 10);
    focusOperatorSession(newId);
    renderOperatorReply({session_id: newId, user_id: 'operator', reply: 'New operator session is ready. Send a prompt to start the thread.', session: {turn_count: 0}});
    setAction('New operator session armed: ' + newId);
});
bindClick('btnOperatorInspect', async () => {
    const sid = operatorSessionIdInput ? operatorSessionIdInput.value.trim() : '';
    if (!sid) {
        setAction('Select an operator session to open its trace.');
        return;
    }
    await refresh();
    focusOperatorSession(sid);
    setActiveView('sessions');
    setAction('Operator session loaded in Sessions view: ' + sid);
});
bindClick('btnBackendCommandRefresh', async () => {
    const payload = await postAction('backend_command_list');
    const commands = Array.isArray(payload.commands) ? payload.commands : [];
    renderBackendCommands(latestStatus, commands);
    if (backendCommandOutput) {
        backendCommandOutput.textContent = commands.length
            ? `Loaded ${commands.length} backend commands from backend_command_deck.json.`
            : 'No backend commands are configured.';
    }
    setAction(payload.message || `backend command list refreshed (${commands.length})`);
});
bindClick('btnBackendCommandRun', async () => {
    const commandId = backendCommandSelect ? String(backendCommandSelect.value || '').trim() : '';
    if (!commandId) {
        setAction('Select a backend command first.');
        return;
    }
    const rawArgs = backendCommandArgs ? String(backendCommandArgs.value || '').trim() : '';
    const payload = await postAction('backend_command_run', {command_id: commandId, args: rawArgs});
    const commands = Array.isArray(payload.available_commands) ? payload.available_commands : null;
    if (commands) renderBackendCommands(latestStatus, commands);
    if (backendCommandOutput) {
        const output = String(payload.output || payload.stdout || payload.stderr || payload.message || '').trim();
        backendCommandOutput.textContent = output || `${commandId} completed with no output.`;
    }
    setAction(payload.message || `${commandId} completed.`);
    await refresh();
});
if (pipelineSelect) {
    pipelineSelect.addEventListener('change', async () => {
        selectedPipelineId = String(pipelineSelect.value || '').trim();
        await loadPipelines(selectedPipelineId);
        setAction(`Pipeline selected: ${selectedPipelineId || 'none'}`);
    });
}
if (pipelineCards) {
    pipelineCards.addEventListener('click', async (event) => {
        const button = event.target && event.target.closest ? event.target.closest('[data-pipeline-id]') : null;
        if (!button) return;
        selectedPipelineId = String(button.getAttribute('data-pipeline-id') || '').trim();
        if (pipelineSelect) pipelineSelect.value = selectedPipelineId;
        await loadPipelines(selectedPipelineId);
        setAction(`Pipeline selected: ${selectedPipelineId || 'none'}`);
    });
}
if (pipelineQueryOperation) {
    pipelineQueryOperation.addEventListener('change', () => {
        const operation = String(pipelineQueryOperation.value || '').trim();
        renderPipelineQueryParamFields(operation);
        const template = pipelineQueryCatalogCache[operation] || {};
        if (pipelineQueryDescription) {
            pipelineQueryDescription.textContent = String(template.description || 'Select an operation to see its governed description and parameters.');
        }
        if (pipelineQueryRowLimit && template.max_rows != null) {
            pipelineQueryRowLimit.max = String(Math.max(1, Number(template.max_rows) || 50));
            const current = Number(pipelineQueryRowLimit.value || 10);
            const cap = Number(template.max_rows) || 50;
            if (current > cap) pipelineQueryRowLimit.value = String(cap);
        }
    });
}
syncShellToggleState();
decorateActionButtons(document);
clearCenterTabs();
if (btnOperatorToggleAudio) {
    syncOperatorAudioButton();
    btnOperatorToggleAudio.addEventListener('click', () => {
        operatorVoiceOutputEnabled = !operatorVoiceOutputEnabled;
        localStorage.setItem('nova_operator_voice_output', operatorVoiceOutputEnabled ? 'on' : 'off');
        if (!operatorVoiceOutputEnabled && window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }
        syncOperatorAudioButton();
        setAction(operatorVoiceOutputEnabled ? 'Operator voice output enabled.' : 'Operator voice output disabled.');
    });
}
initOperatorSpeechRecognition();
syncOperatorMicButton();
if (btnOperatorMic && OperatorSpeechRecognitionCtor) {
    btnOperatorMic.addEventListener('click', () => {
        if (!operatorRecognition) {
            initOperatorSpeechRecognition();
        }
        if (!operatorRecognition) return;
        if (operatorRecognitionActive) {
            operatorRecognition.stop();
            return;
        }
        try {
            operatorRecognition.start();
        } catch (_) {
            operatorRecognitionActive = false;
            syncOperatorMicButton();
        }
    });
}
bindClick('btnGuardStatus', async () => { const payload = await postAction('guard_status'); renderGuardRuntime({guard: payload.guard || {}, core: latestStatus && latestStatus.core ? latestStatus.core : {}, webui: latestStatus && latestStatus.webui ? latestStatus.webui : {}, runtime_summary: {guard: payload.guard || {}, core: latestStatus && latestStatus.core ? latestStatus.core : {}, webui: latestStatus && latestStatus.webui ? latestStatus.webui : {}}}); setAction(payload.message || 'guard_status done'); await refresh(); });
bindClick('btnGuardStart', async () => { const payload = await postAction('guard_start'); renderGuardRuntime({guard: payload.guard || {}, core: latestStatus && latestStatus.core ? latestStatus.core : {}, webui: latestStatus && latestStatus.webui ? latestStatus.webui : {}, runtime_summary: {guard: payload.guard || {}, core: latestStatus && latestStatus.core ? latestStatus.core : {}, webui: latestStatus && latestStatus.webui ? latestStatus.webui : {}}}); setAction(payload.message || 'guard_start done'); await refresh(); });
bindClick('btnGuardStop', async () => { const payload = await postAction('guard_stop'); renderGuardRuntime({guard: payload.guard || {}, core: latestStatus && latestStatus.core ? latestStatus.core : {}, webui: latestStatus && latestStatus.webui ? latestStatus.webui : {}, runtime_summary: {guard: payload.guard || {}, core: latestStatus && latestStatus.core ? latestStatus.core : {}, webui: latestStatus && latestStatus.webui ? latestStatus.webui : {}}}); setAction(payload.message || 'guard_stop done'); await refresh(); });
bindClick('btnGuardRestart', async () => { const payload = await postAction('guard_restart'); setAction(payload.message || 'guard_restart done'); await refresh(); });
bindClick('btnCoreStart', async () => { const payload = await postAction('nova_start'); const core = payload.core || {}; const pid = core.pid ? (' pid=' + core.pid) : ''; setAction((payload.message || 'core_start done') + pid); await refresh(); });
bindClick('btnCoreStop', async () => { const payload = await postAction('core_stop'); setAction(payload.message || 'core_stop done'); await refresh(); });
bindClick('btnCoreRestart', async () => { const payload = await postAction('core_restart'); setAction(payload.message || 'core_restart done'); await refresh(); });
bindClick('btnWebuiRestart', async () => { const confirmed = window.confirm('Restart the Web UI now? The control page will disconnect briefly and should recover after the process comes back up.'); if (!confirmed) { setAction('Web UI restart canceled.'); return; } const payload = await postAction('webui_restart'); setAction(payload.message || 'webui_restart done'); });
document.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const button = target.closest('.runtime-badge-button');
    if (!button) return;
    showRuntimeInspect(
        button.getAttribute('data-runtime-target') || '',
        button.getAttribute('data-runtime-title') || 'Runtime Raw Fields',
        button.getAttribute('data-runtime-key') || '',
        button.getAttribute('data-runtime-group') || '',
    );
});
document.addEventListener('click', async (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;

    const focusButton = target.closest('.focus-jump-button');
    if (focusButton instanceof HTMLElement) {
        const viewTarget = String(focusButton.getAttribute('data-focus-view') || '').trim();
        const layerTabTarget = String(focusButton.getAttribute('data-focus-layer-tab') || '').trim();
        const workTreeModeTarget = String(focusButton.getAttribute('data-focus-work-tree-mode') || '').trim();
        const centerTarget = String(focusButton.getAttribute('data-focus-center-tab') || '').trim();
        const inspectorTarget = String(focusButton.getAttribute('data-focus-inspector-tab') || '').trim();
        setActiveView(viewTarget || 'overview');
        if (layerTabTarget) {
            const operationsShell = document.querySelector('.layer-tab-shell[data-layer-tabs="operations"]');
            if (operationsShell) setLayerTab(operationsShell, layerTabTarget);
        }
        if (workTreeModeTarget) {
            setWorkTreeViewMode(workTreeModeTarget);
            renderSelectedWorkTreeView();
        }
        if (centerTarget) {
            setCenterTab(centerTarget);
        }
        if (inspectorTarget) {
            setInspectorTab(inspectorTarget);
        }
        setAction(`Focus shifted${viewTarget ? ` to ${viewTarget}` : ''}${layerTabTarget ? ` / ${layerTabTarget}` : ''}${centerTarget ? ` with ${centerTarget}` : ''}${inspectorTarget ? ` and ${inspectorTarget} inspector` : ''}.`);
        return;
    }

    const inspectButton = target.closest('.artifact-inspect-button');
    if (inspectButton instanceof HTMLElement) {
        const artifact = String(inspectButton.getAttribute('data-artifact-name') || '').trim();
        if (!artifact) return;
        const payload = await postAction('runtime_artifact_show', {artifact, lines: 160});
        selectedArtifactName = artifact;
        currentArtifactDetail = payload.artifact || null;
        renderRuntimeArtifacts(latestStatus);
        renderArtifactDetail(currentArtifactDetail);
        setAction(`Loaded artifact detail: ${artifact}`);
        return;
    }

    const copyButton = target.closest('.artifact-copy-button');
    if (copyButton instanceof HTMLElement) {
        const path = String(copyButton.getAttribute('data-artifact-path') || '').trim();
        const artifact = String(copyButton.getAttribute('data-artifact-name') || '').trim() || 'artifact';
        if (!path) {
            setAction(`No path is available for ${artifact}.`);
            return;
        }
        try {
            await navigator.clipboard.writeText(path);
            setAction(`Artifact path copied: ${path}`);
        } catch (_) {
            setAction(`Unable to copy to clipboard. ${artifact} path: ${path}`);
        }
    }
});
bindClick('btnAllow', async () => { const payload = await postAction('policy_allow', {domain: (document.getElementById('domainInput').value || '').trim()}); setAction(payload.message || 'policy_allow done'); await refresh(); });
bindClick('btnRemove', async () => { const payload = await postAction('policy_remove', {domain: (document.getElementById('domainInput').value || '').trim()}); setAction(payload.message || 'policy_remove done'); await refresh(); });
bindClick('btnMode', async () => { const payload = await postAction('web_mode', {mode: document.getElementById('webMode').value}); setAction(payload.message || 'web_mode done'); await refresh(); });
bindClick('btnMemoryScope', async () => { const payload = await postAction('memory_scope_set', {scope: memoryScopeSelect ? memoryScopeSelect.value : 'private'}); setAction(payload.message || 'memory_scope_set done'); await refresh(); });
bindClick('btnServerSideApply', async () => { const payload = await postAction('server_side_settings', {mode: serverSideModeSelect ? serverSideModeSelect.value : '', frontdoor: serverSideFrontdoorSelect ? serverSideFrontdoorSelect.value : '', frontdoor_base_url: serverSideBaseUrlInput ? serverSideBaseUrlInput.value.trim() : '', docker_enabled: serverSideDockerSelect ? serverSideDockerSelect.value === 'true' : false}); setAction(payload.message || 'server_side_settings done'); await refresh(); });
bindClick('btnSearchProvider', async () => { const payload = await postAction('search_provider', {provider: document.getElementById('searchProvider').value}); setAction(payload.message || 'search_provider done'); await refresh(); });
bindClick('btnSearchToggle', async () => { const payload = await postAction('search_provider_toggle'); setAction(payload.message || 'search_provider_toggle done'); await refresh(); });
bindClick('btnSearchEndpoint', async () => { const payload = await postAction('search_endpoint_set', {endpoint: searchEndpointInput ? searchEndpointInput.value.trim() : ''}); setAction(payload.message || 'search_endpoint_set done'); await refresh(); });
bindClick('btnSearchPriority', async () => { const payload = await postAction('search_provider_priority_set', {priority: searchProviderPriorityInput ? searchProviderPriorityInput.value.trim() : ''}); setAction(payload.message || 'search_provider_priority_set done'); await refresh(); });
bindClick('btnSearchProbe', async () => { const payload = await postAction('search_endpoint_probe', {endpoint: searchEndpointInput ? searchEndpointInput.value.trim() : ''}); const probe = payload.probe || {}; const message = payload.message || 'search_endpoint_probe done'; if (searchEndpointBox) { const checked = Array.isArray(probe.checked_endpoints) ? probe.checked_endpoints.join(', ') : ''; const resolved = String(probe.resolved_endpoint || '').trim(); searchEndpointBox.textContent = [`Provider: ${String((latestPolicy && latestPolicy.web && latestPolicy.web.search_provider) || (latestStatus && latestStatus.search_provider) || 'html')}`, `Endpoint: ${String(probe.endpoint || (searchEndpointInput ? searchEndpointInput.value.trim() : '') || '(not set)')}`, `Web enabled: ${Boolean(latestPolicy && latestPolicy.web && latestPolicy.web.enabled)}`, `Probe ok: ${Boolean(probe.ok)}`, `Resolved endpoint: ${resolved || 'n/a'}`, `Probe note: ${String(probe.note || 'n/a')}`, `Checked endpoints: ${checked || 'n/a'}`].join('\n'); } setAction(message); await refresh(); });
bindClick('btnChatUserRefresh', async () => { await refresh(); setAction('Chat user list refreshed.'); });
bindClick('btnChatUserUpsert', async () => { const payload = await postAction('chat_user_upsert', {username: chatUserNameInput ? chatUserNameInput.value.trim() : '', password: chatUserPassInput ? chatUserPassInput.value : ''}); if (chatUserPassInput) chatUserPassInput.value = ''; setAction(payload.message || 'chat_user_upsert done'); await refresh(); });
bindClick('btnChatUserDelete', async () => { const username = (chatUserNameInput && chatUserNameInput.value.trim()) || (chatUserSelect && chatUserSelect.value.trim()) || ''; const payload = await postAction('chat_user_delete', {username}); if (chatUserNameInput) chatUserNameInput.value = ''; if (chatUserPassInput) chatUserPassInput.value = ''; setAction(payload.message || 'chat_user_delete done'); await refresh(); });
bindClick('btnAudit', async () => { const payload = await postAction('policy_audit'); setAction(payload.text || payload.message || 'policy_audit done'); });
bindClick('btnInspect', async () => { const payload = await postAction('inspect'); setAction(payload.report || payload.message || 'inspect done'); });
bindClick('btnNovaStart', async () => { const payload = await postAction('nova_start'); const core = payload.core || {}; const pid = core.pid ? (' pid=' + core.pid) : ''; const hb = Number.isFinite(Number(core.heartbeat_age_sec)) ? (' hb_age=' + Number(core.heartbeat_age_sec) + 's') : ''; setAction((payload.message || 'nova_start done') + (core.running ? ' (running)' : ' (starting)') + pid + hb); await refresh(); });
bindClick('btnSelfCheck', async () => { const payload = await postAction('self_check'); const checks = Array.isArray(payload.checks) ? payload.checks : []; const lines = [payload.summary || 'self_check completed']; checks.forEach((check) => lines.push(`- ${check.name}: ${check.ok ? 'OK' : 'FAIL'}${check.detail ? ' (' + check.detail + ')' : ''}`)); setAction(lines.join('\n')); await refresh(); });
bindClick('btnExportCaps', async () => { const payload = await postAction('export_capabilities'); const capabilities = payload.capabilities || {}; const fileName = payload.filename || 'capabilities_export.json'; const blob = new Blob([JSON.stringify(capabilities, null, 2)], {type: 'application/json'}); const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = fileName; document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url); setAction(`Capabilities exported (${Object.keys(capabilities).length}) to ${fileName}`); });
bindClick('btnExportLedger', async () => { const payload = await postAction('export_ledger_summary', {limit: 80}); const summary = payload.summary || {}; const fileName = payload.filename || 'action_ledger_summary.json'; const blob = new Blob([JSON.stringify(summary, null, 2)], {type: 'application/json'}); const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = fileName; document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url); setAction(`Action ledger summary exported to ${fileName}`); });
bindClick('btnExportBundle', async () => { const payload = await postAction('export_diagnostics_bundle'); const fileName = payload.filename || 'diagnostics_bundle.json'; const path = (payload.path || '').trim(); setAction(`Diagnostics bundle exported: ${fileName}${path ? ' @ ' + path : ''}`); });
bindClick('btnOut', async () => { const payload = await postAction('tail_log', {name: 'nova_http.out.log'}); setAction(payload.text || 'No output'); });
bindClick('btnErr', async () => { const payload = await postAction('tail_log', {name: 'nova_http.err.log'}); setAction(payload.text || 'No output'); });
bindClick('btnOperatorOutboxSeen', async () => { await setOperatorOutboxStatus('seen'); });
bindClick('btnOperatorOutboxAnswer', async () => { await respondOperatorOutbox(); });
bindClick('btnOperatorOutboxResolve', async () => { await respondOperatorOutbox('task_resolved'); });
bindClick('btnOperatorOutboxDismiss', async () => { await respondOperatorOutbox('dismissed'); });
bindClick('btnStallOpenOperatorDeck', () => { openOperatorDeck(); setAction('Opened Operations → Operator Deck.'); });
bindClick('btnStallDismissOutbox', async () => { await dismissOperatorOutboxNotice(); });
bindClick('btnStallRunQueueNext', async () => { await runNextGeneratedQueueItem(); });
bindClick('btnStallOpenScheduledTree', () => { openScheduledTreeBlockedView(); setAction('Opened Scheduled Tree blocked view.'); });
bindClick('btnWorkTreeOpenOperatorDeck', () => { openOperatorDeck(); setAction('Opened Operations → Operator Deck.'); });
bindClick('btnWorkTreeDismissOutbox', async () => { await dismissOperatorOutboxNotice(); });
bindClick('btnWorkTreeRunQueueNext', async () => { await runNextGeneratedQueueItem(); });
bindClick('btnLocationTrackStart', async () => { startLiveTracking(); });
bindClick('btnLocationTrackAutoArm', async () => { toggleLiveTrackingAutoArm(); });
bindClick('btnLocationTrackStop', async () => { stopLiveTracking(); });
bindClick('btnLocationTrackClear', async () => { await clearLiveTracking(); });

if (operatorPromptInput) {
    operatorPromptInput.addEventListener('keydown', async (event) => {
        if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
            event.preventDefault();
            await sendOperatorPrompt();
        }
    });
}

if (taskManagerSelect) {
    taskManagerSelect.addEventListener('change', () => {
        renderRealWorldTaskPreview();
    });
}

window.addEventListener('error', (event) => {
    const message = event && event.message ? event.message : 'Unknown script error';
    setFeedback('UI script error: ' + message, 'danger');
});
window.addEventListener('unhandledrejection', (event) => {
    const reason = event && event.reason ? String(event.reason) : 'Unhandled promise rejection';
    setFeedback('UI async error: ' + reason, 'danger');
});

function initialControlView() {
    try {
        const params = new URLSearchParams(window.location.search || '');
        const requested = String(params.get('view') || '').trim();
        if (requested && navButtons.some((button) => (button.getAttribute('data-view-target') || '') === requested)) {
            return requested;
        }
    } catch (_) {

        return 'overview';
    }
    return 'overview';
}

function focusTemporalPolicyAnchor() {
    const hash = String(window.location.hash || '').trim();
    if (hash !== '#temporalPolicyControls') {
        syncTemporalNavLinkActive();
        return;
    }
    setActiveView('operations');
    const operationsShell = document.querySelector('.layer-tab-shell[data-layer-tabs="operations"]');
    if (operationsShell) {
        setLayerTab(operationsShell, 'governance');
    }
    const temporalAnchor = document.getElementById('temporalPolicyControls');
    if (temporalAnchor) {
        window.requestAnimationFrame(() => {
            temporalAnchor.scrollIntoView({behavior: 'smooth', block: 'start'});
        });
    }
    syncTemporalNavLinkActive();
}

window.addEventListener('hashchange', () => {
    focusTemporalPolicyAnchor();
});

setFeedback('NYO System control linked. Fetching live status...', 'muted');
setActiveView(initialControlView());
focusTemporalPolicyAnchor();
setInspectorTab('planner');
renderLiveTracking(null);
wireTemporalEventManagement();
loadTemporalEvents();
refresh();
scheduleLiveRefresh();
